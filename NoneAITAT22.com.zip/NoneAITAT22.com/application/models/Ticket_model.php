<?php 
	Class Ticket_model extends CI_Model{

	//insert Or Add function 
	public function Insert_id_data_model($table,$data){
			$this->db->insert($table,$data);
			return $this->db->insert_id();
		}	


/****************************************************************************
*Daily Expense SEARCH MODEL METHOD..
*/		
		public function Get_data_Daily_report_by_search_key_model($table,$data){
			$this->db->select('*'); 
			$this->db->from($table); 
 
			$this->db->where('created_at', $data['created_at']);

			$result = $this->db->get();
			$result = $result->result();
			return $result;			
		}


/****************************************************************************
*Daily Expense SEARCH Catagory MODEL METHOD..
*/		
		public function Get_data_Dayily_Expense_search_key_model($table,$data){
			$this->db->select('*'); 
			$this->db->from($table); 
 
			$this->db->where('expense_date', $data['expense_date']);
			$this->db->where('expense_cat_id', $data['expense_cat_id']);

			$result = $this->db->get();
			$result = $result->result();
			return $result;			
		}


		public function Get_dataWeekly_Month_Date_search_key_model($table,$data){

			$this->db->select('*'); 
			$this->db->from($table); 
			if(!empty($data['fromdate'])){
				$this->db->where('created_at >=', $data['fromdate']);
				$this->db->where('created_at <=', $data['todate']);
			}			
			$result = $this->db->get();
			$result = $result->result();
			return $result;
		}


		public function Get_Flight_report_model($table,$data){
			$this->db->select('*'); 
			$this->db->from($table); 
			if(!empty($data['fromdate'])){
				$this->db->where('flight_date >=', $data['fromdate']);
				$this->db->where('flight_date <=', $data['todate']);
			}			
			$result = $this->db->get();
			$result = $result->result();
			return $result;
		}


//Passenger Info Data Id
		public function PassengerDataGetById($passenger_id){
			$this->db->select('*');
			$this->db->from('tb_passenger');
			$this->db->where('id',$passenger_id);
			$result = $this->db->get();
			$result = $result->row();
			return $result;
		}
		
	// update_ticketPassengerData
		public function update_ticketPassengerData($table,$data){
			$this->db->set('id',$data['id']);
			$this->db->set('first_name',$data['first_name']);
			$this->db->set('last_name',$data['last_name']);
			$this->db->set('passport_no',$data['passport_no']);
			$this->db->set('ticket_no',$data['ticket_no']);
			$this->db->set('a_ticket_pnr',$data['a_ticket_pnr']);
			$this->db->set('g_ticket_pnr',$data['g_ticket_pnr']);
			$this->db->set('d_of_issue',$data['d_of_issue']);
			$this->db->set('flight_name',$data['flight_name']);
			$this->db->set('flight_code',$data['flight_code']);
			$this->db->set('from_country',$data['from_country']);
			$this->db->set('to_country',$data['to_country']);
			$this->db->set('Depart',$data['Depart']);
			$this->db->set('Arrive',$data['Arrive']);
			$this->db->set('baggage',$data['baggage']);
			$this->db->set('class',$data['class']);
			$this->db->set('duration',$data['duration']);
			$this->db->set('aircraft',$data['aircraft']);
			$this->db->set('flight_date',$data['flight_date']);
			$this->db->where('id',$data['id']);
			$this->db->update($table);

		}

/****************************************************************************
*SERCH MODEL METHOD..
*/		
		public function Get_data_pay_by_search_key_model($table,$data){
			$this->db->select('*'); 
			$this->db->from($table); 
			
			$this->db->where('id', $data['id']);
			
			$result = $this->db->get();
			$result = $result->result();
			return $result;			
		}
		

}
