<?php 
	Class Medical_model extends CI_Model{
	    
/*serial  Data Check */
 	public function CheckPayDateNoData($m_pay_date){

 		$this->db->where('m_pay_date',$m_pay_date );  
           $query = $this->db->get("tb_pay_m_date"); 
           if($query->num_rows() > 0)  
           {  
                return true;  
           }  
           else  
           {  
                return false;  
           }  
      }

      
	//insert Or Add function 
	public function Insert_id_data_model($table,$data){
			$this->db->insert($table,$data);
			return $this->db->insert_id();
		}	


// Customer Data By ID
		public function Customer_info_model($Customer_id){
			$this->db->select('*');
			$this->db->from('tb_customer');
			$this->db->where('id',$Customer_id);
			$result = $this->db->get();
			$result = $result->row();
			return $result;
		}

//update medical 
	public function UpdateCustomerData($table, $data){
		$this->db->set('id',$data['id']);
		$this->db->set('fullname' ,$data['fullname']);
		$this->db->set('passport_no' ,$data['passport_no']);
		$this->db->set('phone' ,$data['phone']);
		$this->db->set('address' ,$data['address']);
		$this->db->set('m_c_name',$data['m_c_name']);
		$this->db->set('remark',$data['remark']);
		$this->db->set('m_rate',$data['m_rate']);
		$this->db->where('id',$data['id']);
		$this->db->update($table);
	}

	public function GetDataMedicalById($id){
			$this->db->select('*'); 
			$this->db->from('tb_medical'); 
			$this->db->where('passenger_id',$id );
			//var_dump($sdata['vendor_id']);
			$result = $this->db->get();
			$result = $result->result();
			return $result;	
		}

	public function MedicalPaymentId($table,$data){
		$this->db->set('status',$data['status']);
		$this->db->where($data['match_col'],$data['match_by']);		//var_dump($data);die();
		$this->db->update($table);
	}

// Customer Invoice Data Id

		public function Medical_info($passenger_id){
			$this->db->select('*');
			$this->db->from('tb_medical_passenger');
			$this->db->where('id',$passenger_id);
			$result = $this->db->get();
			$result = $result->row();
			return $result;
		}

// Agent Invoice Data Id
		public function Vendor_info_for_invoice($vendor_id){
			$this->db->select('*');
			$this->db->from('tb_vendor');
			$this->db->where('id',$vendor_id);
			$result = $this->db->get();
			$result = $result->row();
			return $result;
		}

		public function Agent_info_for_invoice($agent_id){
			$this->db->select('*');
			$this->db->from('tb_agent');
			$this->db->where('id',$agent_id);
			$result = $this->db->get();
			$result = $result->row();
			return $result;
		}

}