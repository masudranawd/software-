<?php 
	Class Vendor_model extends CI_Model{
/****************************************************************************
*SERCH MODEL METHOD..
*/		
		public function Get_data_by_Vendorsearch_key_model($table,$sdata){

			$this->db->select('*'); 
			$this->db->from($table); 
			$this->db->where('id', $sdata['vendor_id']);
			//var_dump($sdata['vendor_id']);
			$result = $this->db->get();
			$result = $result->result();
			return $result;			
		}


		public function GetvendorTicketPayData($id){
			$this->db->select('*'); 
			$this->db->from('tb_ticket'); 
			$this->db->where('vendor_id',$id );
			//var_dump($sdata['vendor_id']);
			$result = $this->db->get();
			$result = $result->result();
			return $result;	
		}
		

		public function GetvendorMedicalPayData($id){
			$this->db->select('*'); 
			$this->db->from('tb_medical'); 
			$this->db->where('vendor_id',$id );
			$result = $this->db->get();
			$result = $result->result();
			return $result;	
		}

// visa update data method
	public function update_vendor_data_model($table,$data){
		$this->db->set('id',$data['id']);
		$this->db->set('vendor_id',$data['vendor_id']);
		$this->db->set('vendor_name',$data['vendor_name']);
		$this->db->set('company_name',$data['company_name']);
		$this->db->set('phone',$data['phone']);
		$this->db->set('email',$data['email']);
		$this->db->set('address',$data['address']);
		$this->db->where('id',$data['id']);
		$this->db->update($table);
	}



/****************************************************************************
*Daily Expense SEARCH MODEL METHOD..
*/		
		public function Get_data_Date_search_key_model($table,$data){
			$this->db->select('*'); 
			$this->db->from($table); 
			if(!empty($data['fromdate'])){
				$this->db->where('agent_id', $data['agent_id']);
				$this->db->where('created_at >=', $data['fromdate']);
				$this->db->where('created_at <=', $data['todate']);
			}			
			$result = $this->db->get();
			$result = $result->result();
			return $result;			
		}

/****************************************************************************
*Daily Expense SEARCH MODEL METHOD..
*/		
		public function Get_data_vendor_Medical_Date_search_key_model($table,$data){
			$this->db->select('*'); 
			$this->db->from($table); 
			if(!empty($data['fromdate'])){
				$this->db->where('vendor_id', $data['vendor_id']);
				$this->db->where('created_at >=', $data['fromdate']);
				$this->db->where('created_at <=', $data['todate']);
			}			
			$result = $this->db->get();
			$result = $result->result();
			return $result;			

		}

	// medical passenger 
		public function MPassengerDataGetById($passenger_id){
			$this->db->select('*');
			$this->db->from('tb_medical_passenger');
			$this->db->where('id',$passenger_id);
			$result = $this->db->get();
			$result = $result->row();
			return $result;
		}

}
