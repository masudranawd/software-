<?php 
	Class Setting_model extends CI_Model{
//count
	public function CountAll($table){
		$this->db->select(); 
		$this->db->from($table);
		$result = $this->db->get(); 
		$result = $result->num_rows();
		return $result; 
	}
//insert Or Add function 
	public function insert_data_model($table,$data){
		$this->db->insert($table,$data);
	}
	

// get data show model 

	public function Get_data_method($table){
		$this->db->select('*');
		$this->db->from($table);
		if($table=='tb_activity'){ $this->db->order_by('activity_id','DESC'); }	
		if($table=='tb_ticket'){ $this->db->order_by('id','DESC'); }	
		$result = $this->db->get();
		$result = $result->result();
		return $result;

	}//end
	
    public function Get_Date_ById_method($sitetable,$siteData){
            $this->db->select('*');
			$this->db->from($sitetable);
			$this->db->where($siteData['match_col'],$siteData['match_by']);
			$result = $this->db->get();
			$result = $result->row();
			return $result;
    }

// remove data method

	public function Get_remove_data_method($table,$data){
		$this->db->where($data['match_col'],$data['match_by']);
		$this->db->delete($table);
	}
//update data method

	public function cat_update_data_model($table,$data){
		$this->db->set('id',$data['id']);
		$this->db->set('cat_name',$data['cat_name']);
		$this->db->where('id',$data['id']);
		$this->db->update($table);

	}
// visa update data method
	public function update_visa_data_model($table,$data){
		$this->db->set('id',$data['id']);
		$this->db->set('visa_type',$data['visa_type']);
		$this->db->where('id',$data['id']);
		$this->db->update($table);
	}

//Expenses_cat_update_data_model
	public function Expenses_cat_update_data_model($table,$data){
		$this->db->set('id',$data['id']);
		$this->db->set('expenses_cat_name',$data['expenses_cat_name']);
		$this->db->where('id',$data['id']);
		$this->db->update($table);
	}
	
//Cash In Out update_data_model
	public function CashINOut_cat_update_data_model($table,$data){
		$this->db->set('id',$data['id']);
		$this->db->set('name',$data['name']);
		$this->db->where('id',$data['id']);
		$this->db->update($table);
	}
	
/****************************************************************************
*SERCH MODEL METHOD..
*/		
		public function Get_data_by_search_key_model($table,$data){
			$this->db->select('*'); 
			$this->db->from($table); 
			
			$this->db->where('serial_no', $data['serial_no']);
			
			$result = $this->db->get();
			$result = $result->result();
			return $result;			
		}
		
	    public function GeneralsettingUpdate($table,$data){
		$this->db->set('id',$data['id']);
		$this->db->set('title',$data['title']);
		$this->db->set('name',$data['name']);
		$this->db->set('address',$data['address']);
		$this->db->set('phone',$data['phone']);
		$this->db->set('email',$data['email']);
		if(isset($data['logo'])){$this->db->set('logo',$data['logo']);}
		$this->db->where('id',$data['id']);
		$this->db->update($table);
	    }


}

