<?php 
	Class Agent_model extends CI_Model{

// visa update data method
	public function update_agent_data_model($table,$data){
		$this->db->set('id',$data['id']);
		$this->db->set('agent_id',$data['agent_id']);
		$this->db->set('agent_name',$data['agent_name']);
		$this->db->set('mobile_no',$data['mobile_no']);
		$this->db->set('gender',$data['gender']);
		$this->db->set('address',$data['address']);
		$this->db->set('agent_details',$data['agent_details']);
		$this->db->set('company_name',$data['company_name']);
		if(isset($data['agent_image'])){$this->db->set('agent_image',$data['agent_image']);}
		$this->db->where('id',$data['id']);
		$this->db->update($table);
	}

	public function GetAgentTicketPayData($id){
			$this->db->select('*');
			$this->db->from('tb_ticket');
			$this->db->where('agent_id',$id);
			$result = $this->db->get();
			$result = $result->result();
			return $result;
	}
public function AgentALlCustomerList($id){
			$this->db->select('*');
			$this->db->from('tb_customer');
			$this->db->where('agent_name',$id);
			$result = $this->db->get();
			$result = $result->result();
			return $result;
	}

	public function Countmember($id){
		$this->db->select(); 
		$this->db->from('tb_customer');
		$this->db->where('permission',0); 
		$this->db->where('agent_name',$id);
		$result = $this->db->get(); 
		$result = $result->num_rows();
		return $result; 
	}

/****************************************************************************
*Daily Expense SEARCH MODEL METHOD..
*/		
		public function Get_data_Date_search_key_model($table,$data){
			$this->db->select('*'); 
			$this->db->from($table); 
			if(!empty($data['fromdate'])){
				$this->db->where('agent_id', $data['agent_id']);
				$this->db->where('created_at >=', $data['fromdate']);
				$this->db->where('created_at <=', $data['todate']);
			}			
			$result = $this->db->get();
			$result = $result->result();
			return $result;			

		}

/****************************************************************************
*Daily Expense SEARCH MODEL METHOD..
*/		
		public function Get_data_Date_Payment_search_key_model($table,$data){
			$this->db->select('*'); 
			$this->db->from($table); 
			if(!empty($data['fromdate'])){
				$this->db->where('agent_id', $data['agent_id']);
				$this->db->where('payment_date >=', $data['fromdate']);
				$this->db->where('payment_date <=', $data['todate']);
			}			
			$result = $this->db->get();
			$result = $result->result();
			return $result;			
		}


/****************************************************************************
*Daily Expense SEARCH MODEL METHOD..
*/		
		public function Get_data_vendor_Date_search_key_model($table,$data){
			$this->db->select('*'); 
			$this->db->from($table); 
			if(!empty($data['fromdate'])){
				$this->db->where('vendor_id', $data['vendor_id']);
				$this->db->where('created_at >=', $data['fromdate']);
				$this->db->where('created_at <=', $data['todate']);
			}			
			$result = $this->db->get();
			$result = $result->result();
			return $result;			

		}

/****************************************************************************
*Daily Expense SEARCH MODEL METHOD..
*/		
		public function Get_data_vendor_Date_Payment_search_key_model($table,$data){
			$this->db->select('*'); 
			$this->db->from($table); 
			if(!empty($data['fromdate'])){
				$this->db->where('vendor_id', $data['vendor_id']);
				$this->db->where('payment_date >=', $data['fromdate']);
				$this->db->where('payment_date <=', $data['todate']);
			}			
			$result = $this->db->get();
			$result = $result->result();
			return $result;			
		}
// vendor Name BY Id

		public function vendorNameById($vendor_id){
			$this->db->select('*');
			$this->db->from('tb_vendor');
			$this->db->where('id',$vendor_id);
			$result = $this->db->get();
			$result = $result->row();
			return $result;
		}

/****************************************************************************
*SERCH MODEL METHOD..
*/		
		public function Get_data_by_Aagentsearch_key_model($table,$sdata){

			$this->db->select('*'); 
			$this->db->from($table); 
			$this->db->where('id', $sdata['agent_id']);
			//var_dump($sdata['vendor_id']);
			$result = $this->db->get();
			$result = $result->result();
			return $result;			
		}

//Medical 

		public function GetAgentMedicalPayData($id){
			$this->db->select('*'); 
			$this->db->from('tb_medical'); 
			$this->db->where('agent_id',$id );
			$result = $this->db->get();
			$result = $result->result();
			return $result;	
		}


}
