<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Agent extends CI_Controller {

	public function __construct(){
		parent:: __construct();
		$this->load->model('Customer_model');
		$this->load->model('Accounts_model');
		$this->load->model('Setting_model');
		$this->load->model('Agent_model');
		$this->load->model('User_model');
		$this->load->model('Payment_model');
		$this->load->model('Ticket_model');
		$this->load->model('Vendor_model');

		$login_user = $this->session->userdata('user_id'); 
		if(isset($login_user)){
			$login_user; 
		}else{
			
			redirect('User/'); 
		} 
	}

	public function index()
	{
		$this->AddAgent();
	}

	//Add Agent ui Mehthod

	public function AddAgent(){
		$data = array();

		$data['AllAgentList'] =  $this->Setting_model->Get_data_method('tb_agent');
		$data['AgentId'] = $this->Accounts_model->Get_data_singleData_id('tb_agent');
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/agent/add_agent.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}//end


	public function AllAgent(){
		$data = array();

		$data['AllAgentList'] =  $this->Setting_model->Get_data_method('tb_agent');
		$data['AgentId'] = $this->Accounts_model->Get_data_singleData_id('tb_agent');
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/agent/all_agent.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}//end

	//All Agent ui Mehthod

	public function AgentReport(){
		$data = array();

		$data['AllAgentList'] =  $this->Setting_model->Get_data_method('tb_agent');

		$sdata=array(
			'agent_id' => $this->input->post('agent_id'), 
			//'visa_no' => $this->input->post('visa_no'), 
			);		
		$data['AgentAccount'] =  $this->Accounts_model->Get_data_by_search_key_model('tb_agent',$sdata);
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/agent/agent_report.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}//end

// Insert Agent data method
	public function AgentReportDateMonth(){
		$data = array();

		$data['AllAgentList'] =  $this->Setting_model->Get_data_method('tb_agent');

		$sdata=array(
			'agent_id' => $this->input->post('agent_id'), 
			'fromdate' => date("m/d/Y", strtotime($this->input->post('fromdate'))), 
			'todate' => date("m/d/Y", strtotime($this->input->post('todate'))), 
			);		
		$data['AgentTicketList'] =  $this->Agent_model->Get_data_Date_search_key_model('tb_ticket',$sdata);

	$data['AgentPaymentList'] =  $this->Agent_model->Get_data_Date_Payment_search_key_model('tb_payment',$sdata);
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/agent/agent_payment_report.php',$sdata),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}//end

//Agent Report medical 
	public function AgentReportMedicalDateMonth(){
		$data = array();

		$sdata=array(
			'agent_id' => $this->input->post('agent_id'), 
			'fromdate' => date("m/d/Y", strtotime($this->input->post('fromdate'))), 
			'todate' => date("m/d/Y", strtotime($this->input->post('todate'))), 
			);		
		$data['AgentMedicalList'] =  $this->Agent_model->Get_data_Date_search_key_model('tb_medical',$sdata);

	$data['AgentPaymentList'] =  $this->Agent_model->Get_data_Date_Payment_search_key_model('tb_payment',$sdata);
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/agent/agent_payment_medical_report.php',$sdata),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}//end
	

	public function AddNewAgent(){
		$adata = array();
		$table ='tb_agent';
		$adata['agent_id'] = $this->input->post('agent_id');
		$adata['agent_name'] = $this->input->post('agent_name');
		$adata['mobile_no'] = $this->input->post('mobile_no');
		$adata['gender'] = $this->input->post('gender');
		$adata['address'] = $this->input->post('address');
		$adata['agent_details'] = $this->input->post('agent_details');
		$adata['agent_details'] = $this->input->post('agent_details');
		$adata['company_name'] = $this->input->post('company_name');
		

		if (empty($adata['agent_id']) OR empty($adata['agent_name'] OR empty($adata['mobile_no']))) {
			$datas['smg'] = "<b style='color:red;'> Invalid ! Please Check your Agent Id , Agent Name , And Contact Number</b>";
			$this->session->set_flashdata($datas);
			redirect('Agent');
		}else{
				$new_name                   	= time().$_FILES["agent_image"]['name'];
        		$config['file_name']        	= $new_name;
				$config['upload_path']          = 'images/agent/';
				$config['remove_spaces']		= FALSE;
                $config['allowed_types']        = 'gif|jpg|png|jpeg';
                $config['max_size']             = 100000;
                $config['max_width']            = 102400;
                $config['max_height']           = 76800;

                $this->load->library('upload', $config);
                $adata['agent_image'] = $new_name;


                if ( ! $this->upload->do_upload('agent_image'))
                {
                    $error = array('error' => $this->upload->display_errors());
                    //$this->load->view('upload_form', $error);
                }
                else
                { 
                 	$data = array('upload_data' => $this->upload->data());
                }
    /*activity Details*/
		$ATable = 'tb_activity';
		$AData = array();
		$AData['activity_details'] = '<div class="alert alert-success"> Success :)New Customer Add By &mdash; '.$this->session->fullname.'<span style="font-size:12px;">('.$this->session->user_id.')</span> </div>';
		$this->Setting_model->insert_data_model($ATable,$AData); //ACTIVITY UPDATED...
    /*activity details*/
        
			$this->Setting_model->insert_data_model($table,$adata);
			$datas['smg'] ="<b style='color:green;'>Successfuly Save !</b>";
			$this->session->set_flashdata($datas);
			redirect('Agent');
		}
	}//end

// Update agent info

	public function updateAgent(){
		$adata = array();
		$table ='tb_agent';
		$adata['id'] = $this->input->post('id');
		$adata['agent_id'] = $this->input->post('agent_id');
		$adata['agent_name'] = $this->input->post('agent_name');
		$adata['mobile_no'] = $this->input->post('mobile_no');
		$adata['gender'] = $this->input->post('gender');
		$adata['address'] = $this->input->post('address');
		$adata['agent_details'] = $this->input->post('agent_details');
		$adata['company_name'] = $this->input->post('company_name');
		

		if (empty($adata['id'])) {
			$datas['smg'] = "<b style='color:red;'> Invalid ! Please Check your Agent Id , Agent Name , And Contact Number</b>";
			$this->session->set_flashdata($datas);
			redirect('Agent/AllAgent');
		}else{
				
				$old_image	= $this->input->post('old_image');
				/*-----------------------------------------------*/
				$change_image = $_FILES["agent_image"]['name'];
				if(!empty($change_image)){
				unlink('images/agent/'.$old_image); 
				$new_name                   	= time().$change_image; 
				$config['file_name']        	= $new_name;
				$config['upload_path']          = 'images/agent/';
				$config['remove_spaces']		= FALSE;
			    $config['allowed_types']        = 'gif|jpg|jpeg|png|pdf';
				$this->load->library('upload', $config);
			    $adata['agent_image'] = $new_name;

			    if (! $this->upload->do_upload('agent_image')){
			    $error = array('error' => $this->upload->display_errors());
			    $this->load->view('upload_form', $error);
			    }else{	
			    array('upload_data' => $this->upload->data());
			     }
			}
			    /*activity Details*/
		$ATable = 'tb_activity';
		$AData = array();
		$AData['activity_details'] = '<div class="alert alert-warning"> Success :)Update Customer Add By &mdash; '.$this->session->fullname.'<span style="font-size:12px;">('.$this->session->user_id.')</span> </div>';
		$this->Setting_model->insert_data_model($ATable,$AData); //ACTIVITY UPDATED...
    /*activity details*/
    
			$this->Agent_model->update_agent_data_model($table,$adata);
			$datas['smgdu'] ="<b style='color:green;'>Successfuly Updated !</b>";
			$this->session->set_flashdata($datas);
			redirect('Agent/AllAgent');
		}

	}//end

	public function removeAgent($id){
		$data = array();
		$table = 'tb_agent';
		$data['match_by'] 	= $id;
		$data['match_col']  = 'id';
		$this->Setting_model->Get_remove_data_method($table,$data);
    /*activity Details*/
		$ATable = 'tb_activity';
		$AData = array();
		$AData['activity_details'] = '<div class="alert alert-danger"> Success :)Remove Customer By &mdash; '.$this->session->fullname.'<span style="font-size:12px;">('.$this->session->user_id.')</span> </div>';
		$this->Setting_model->insert_data_model($ATable,$AData); //ACTIVITY UPDATED...
    /*activity details*/
		$datas['smgdu'] = "<b style='color:red;'>Deleted Done !</b>";
       	$this->session->set_flashdata($datas);
        redirect('Agent/AllAgent');
	}


}


