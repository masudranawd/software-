<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Vendor extends CI_Controller {

	public function __construct(){
		parent:: __construct();
		$this->load->model('Customer_model');
		$this->load->model('Accounts_model');
		$this->load->model('Setting_model');
		$this->load->model('Agent_model');
		$this->load->model('User_model');
		$this->load->model('Vendor_model');
		$this->load->model('Payment_model');
		$this->load->model('Ticket_model');
		
		$login_user = $this->session->userdata('user_id'); 
		if(isset($login_user)){
			$login_user; 
		}else{
			
			redirect('User/'); 
		} 
	}

	public function index()
	{
		$this->AddVendor();
	}

	//Add Agent ui Mehthod

	public function AddVendor(){
		$data = array();

		$data['VendorId'] = $this->Accounts_model->Get_data_singleData_id('tb_vendor');
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/vendor/add_vendor.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}//end


	public function AllVendor(){
		$data = array();

		$data['AllVendorData'] =  $this->Setting_model->Get_data_method('tb_vendor');
		$data['AgentId'] = $this->Accounts_model->Get_data_singleData_id('tb_agent');
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/vendor/all_vendor.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}//end

	//All Agent ui Mehthod

	public function VendorReport(){
		$data = array();

		$data['AllVendorData'] =  $this->Setting_model->Get_data_method('tb_vendor');
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/vendor/vendor_report.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}//end

//All Vendor ui Mehthod
	public function VendorReportDateMonth(){
		$data = array();
		$sdata=array(
			'vendor_id' => $this->input->post('vendor_id'), 
			'fromdate' => date("m/d/Y", strtotime($this->input->post('fromdate'))), 
			'todate' => date("m/d/Y", strtotime($this->input->post('todate'))), 
			);		
		$data['VendoricketList'] =  $this->Agent_model->Get_data_vendor_Date_search_key_model('tb_ticket',$sdata);
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/vendor/vendor_payment_report.php',$sdata),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}//end
	//VendorReportDateMonth Medical 

	public function VendorMedicalReportDateMonth(){
		$data = array();
		$sdata=array(
			'vendor_id' => $this->input->post('vendor_id'), 
			'fromdate' => date("m/d/Y", strtotime($this->input->post('fromdate'))), 
			'todate' => date("m/d/Y", strtotime($this->input->post('todate'))), 
			);		
		$data['VendorMedicalList'] =  $this->Vendor_model->Get_data_vendor_Medical_Date_search_key_model('tb_medical',$sdata);
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/vendor/vendor_medical_pay_report.php',$sdata),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}


	public function AddNewVendor(){
		$adata = array();
		$table ='tb_vendor';
		$adata['vendor_id'] = $this->input->post('vendor_id');
		$adata['vendor_name'] = $this->input->post('vendor_name');
		$adata['company_name'] = $this->input->post('company_name');
		$adata['phone'] = $this->input->post('phone');
		$adata['address'] = $this->input->post('address');
		$adata['email'] = $this->input->post('email');

		if (empty($adata['vendor_id']) OR empty($adata['vendor_name'] )) {
			$datas['smg'] = "<b style='color:red;'> Invalid ! Please Check your Vendor Id , Verdor Name , And Contact Number</b>";
			$this->session->set_flashdata($datas);
			redirect('Vendor');
		}else{
   /*activity Details*/
		$ATable = 'tb_activity';
		$AData = array();
		$AData['activity_details'] = '<div class="alert alert-info"> Success :)Add New Vendor By &mdash; '.$this->session->fullname.'<span style="font-size:12px;">('.$this->session->user_id.')</span> </div>';
		$this->Setting_model->insert_data_model($ATable,$AData); //ACTIVITY UPDATED...
    /*activity details*/
			$this->Setting_model->insert_data_model($table,$adata);
			$datas['smg'] ="<b style='color:green;'>Successfuly Save !</b>";
			$this->session->set_flashdata($datas);
			redirect('Vendor');
		}
	}//end

// Update agent info

	public function updateVendor(){
		$adata = array();
		$table ='tb_vendor';
		$adata['id'] = $this->input->post('id');
		$adata['vendor_id'] = $this->input->post('vendor_id');
		$adata['vendor_name'] = $this->input->post('vendor_name');
		$adata['company_name'] = $this->input->post('company_name');
		$adata['phone'] = $this->input->post('phone');
		$adata['address'] = $this->input->post('address');
		$adata['email'] = $this->input->post('email');
		if (empty($adata['id'])) {
			$datas['smg'] = "<b style='color:red;'> Invalid !</b>";
			$this->session->set_flashdata($datas);
			redirect('Vendor/AllVendor');
		}else{
		/*activity Details*/
		$ATable = 'tb_activity';
		$AData = array();
		$AData['activity_details'] = '<div class="alert alert-warning"> Success :)Update Vendor By &mdash; '.$this->session->fullname.'<span style="font-size:12px;">('.$this->session->user_id.')</span> </div>';
		$this->Setting_model->insert_data_model($ATable,$AData); //ACTIVITY UPDATED...
    /*activity details*/
			$this->Vendor_model->update_vendor_data_model($table,$adata);
			$datas['smgdu'] ="<b style='color:green;'>Successfuly Updated !</b>";
			$this->session->set_flashdata($datas);
			redirect('Vendor/AllVendor');
		}

	}//end

	public function removeVendor($id){
		$data = array();
		$table = 'tb_vendor';
		$data['match_by'] 	= $id;
		$data['match_col']  = 'id';
		$this->Setting_model->Get_remove_data_method($table,$data);
		
       /*activity Details*/
		$ATable = 'tb_activity';
		$AData = array();
		$AData['activity_details'] = '<div class="alert alert-danger"> Success :)Remove Vendor  By &mdash; '.$this->session->fullname.'<span style="font-size:12px;">('.$this->session->user_id.')</span> </div>';
		$this->Setting_model->insert_data_model($ATable,$AData); //ACTIVITY UPDATED...
    /*activity details*/
    
		$datas['smgdu'] = "<b style='color:red;'>Deleted Done !</b>";
       	$this->session->set_flashdata($datas);
        redirect('Vendor/AllVendor');
	}


}


