<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ticket extends CI_Controller {

	public function __construct(){
		parent:: __construct();
		$this->load->model('Customer_model');
		$this->load->model('Accounts_model');
		$this->load->model('Setting_model');
		$this->load->model('Agent_model');
		$this->load->model('User_model');
		$this->load->model('Ticket_model');
		$this->load->model('Payment_model');
		$this->load->library('pdf');
		
		$login_user = $this->session->userdata('user_id'); 
		if(isset($login_user)){
			$login_user; 
		}else{
			redirect('User/'); 
		} 
	}

	public function index()
	{
		$this->TicketBooking();
	}

	//Add Ticker bookng ui Mehthod
	public function TicketBooking(){
		$data = array();

		$data['AllAgentList'] =  $this->Setting_model->Get_data_method('tb_agent');
		$data['AllVendorData']  =  $this->Setting_model->Get_data_method('tb_vendor');
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/ticket/add_ticket.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}//end

// all Passenger ticket list 
	public function TicketPasenger(){
		$data = array();

		$data['AllPassengerData'] =  $this->Setting_model->Get_data_method('tb_passenger');
		$data['AllVendorData']  =  $this->Setting_model->Get_data_method('tb_vendor');
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/ticket/ticket_passenger.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}//end


//Add Ticker bookng ui Mehthod
	public function FlightReport(){
		$data = array();
		
		$data['AllVendorData']  =  $this->Setting_model->Get_data_method('tb_vendor');
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		$sdata=array( 
			'fromdate' => date("m/d/Y", strtotime($this->input->post('fromdate'))), 
			'todate' => date("m/d/Y", strtotime($this->input->post('todate'))), 
			'created_at' => '',
			);		
		$data['AllFlightReport'] =  $this->Ticket_model->Get_Flight_report_model('tb_passenger',$sdata);
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/ticket/flight_report.php',$sdata),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}//end
// all ticket list 

	public function AllTicket(){
		$data = array();

		$data['AllTicketData'] =  $this->Setting_model->Get_data_method('tb_ticket');
		$data['AllAgentList']  =  $this->Setting_model->Get_data_method('tb_agent');
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/ticket/all_ticket.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}//end

	public function Pdf($id){

		$data = array();
		/*----------------ticket------------------*/	
		$TData = array();	
		$Ttable = 'tb_passenger';
		$TData['match_col'] = 'id';
		$TData['match_by'] = $id; 
		$data['TicketData'] = $this->Setting_model->Get_Date_ById_method($Ttable,$TData);
		/*----------------ticket------------------*/	

		$data['AllTicketData'] =  $this->Setting_model->Get_data_method('tb_ticket');
		$data['AllAgentList']  =  $this->Setting_model->Get_data_method('tb_agent');
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		
		//file link
		$data = array(
			//'Left ment' => $this->load->view('inc/left_menu.php',$data),
			//'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/ticket/ticketpdf.php',$data),
			//'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);}

	//All Agent ui Mehthod

	public function TicketReport(){
		$data = array();

		$data['AllAgentList'] =  $this->Setting_model->Get_data_method('tb_agent');

		$sdata=array(
			'agent_id' => $this->input->post('agent_id'), 
			//'visa_no' => $this->input->post('visa_no'), 
			);		
		$data['AgentAccount'] =  $this->Accounts_model->Get_data_by_search_key_model('tb_agent',$sdata);
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/ticket/ticket_report.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}//end

public function DailyTickterReportSearch(){
		$data = array();

		$data['AllAgentList'] =  $this->Setting_model->Get_data_method('tb_agent');

		$sdata=array(
			'created_at' => $this->input->post('created_at'), 
			'fromdate' 	 => '',
			'todate' 	 => '',
			);		
		$data['AllTicketReport'] =  $this->Ticket_model->Get_data_Daily_report_by_search_key_model('tb_ticket',$sdata);

		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/ticket/ticket_report_pdf.php',$sdata),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}//end
	
//All Agent ui Mehthod
	public function weeklymonthTicketReportSearch(){
		$data = array();


		$sdata=array( 
			'fromdate' => date("m/d/Y", strtotime($this->input->post('fromdate'))), 
			'todate' => date("m/d/Y", strtotime($this->input->post('todate'))), 
			'created_at' => '',
			);		
		//var_dump($sdata);
		$data['AllTicketReport'] =  $this->Ticket_model->Get_dataWeekly_Month_Date_search_key_model('tb_ticket',$sdata);
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/ticket/ticket_report_pdf.php',$sdata),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}//end


	public function AddAgentBookingTicket(){
		$cdata = array();
		$ctable = 'tb_passenger';
		$cdata['first_name'] 	= $this->input->post('first_name');
		$cdata['passport_no'] 	= $this->input->post('passport_no');
		$cdata['last_name'] 	= $this->input->post('last_name');
		$cdata['passport_no'] 	= $this->input->post('passport_no');
		$cdata['ticket_no'] 	= $this->input->post('ticket_no');
		$cdata['a_ticket_pnr'] 	= $this->input->post('a_ticket_pnr');
		$cdata['g_ticket_pnr'] 	= $this->input->post('g_ticket_pnr');
		$cdata['d_of_issue'] 	= $this->input->post('d_of_issue');
		$cdata['flight_name'] 	= $this->input->post('flight_name');
		$cdata['flight_code'] 	= $this->input->post('flight_code');
		$cdata['from_country'] 	= $this->input->post('from_country');
		$cdata['to_country'] 	= $this->input->post('to_country');
		$cdata['Depart'] 		= $this->input->post('Depart');
		$cdata['Arrive'] 		= $this->input->post('Arrive');
		$cdata['baggage'] 		= $this->input->post('baggage');
		$cdata['class'] 		= $this->input->post('class');
		$cdata['duration'] 		= $this->input->post('duration');
		$cdata['aircraft'] 		= $this->input->post('aircraft');
		$cdata['flight_date'] 	= date("m/d/Y", strtotime($this->input->post('flight_date')));

		$adata = array();
		$table ='tb_ticket';
		$adata['agent_id'] 			= $this->input->post('agent_id');
		$adata['vendor_id'] 		= $this->input->post('vendor_id');
		$adata['type']		 		= 'New Ticket';
		$adata['bill_amount'] 		= $this->input->post('bill_amount');
		$adata['agent_bill'] 		= $this->input->post('agent_bill');
		$adata['remark'] 	 		= $this->input->post('remark');
		$adata['issue_reissue']		= $this->input->post('issue_reissue');
		$adata['created_at'] 		= date('m/d/Y');

		if (empty($adata['agent_id'])) {
			$datas['smg'] = "<b style='color:red;'> Invalid !</b>";
			$this->session->set_flashdata($datas);
			redirect('Ticket');
		}else{
			$id = $this->Ticket_model->Insert_id_data_model($ctable,$cdata);
    		$adata['passenger_id'] = $id;
			 $this->Setting_model->insert_data_model($table,$adata);
			$datas['smg'] ="<b style='color:green;'>Successfuly Save !</b>";
		    /*activity Details*/
				$ATable = 'tb_activity';
				$AData = array();
				$AData['activity_details'] = '<div class="alert alert-success"> Success :)Add New Ticket By &mdash; '.$this->session->fullname.'<span style="font-size:12px;">('.$this->session->user_id.')</span> </div>';
				$this->Setting_model->insert_data_model($ATable,$AData); //ACTIVITY UPDATED...
		    /*activity details*/
			$this->session->set_flashdata($datas);
			redirect('Ticket/Pdf/'.$id);
		}
	}//end


	public function TicketPassengerEdit(){
		$cdata = array();
		$ctable = 'tb_passenger';
		$cdata['id'] 	= $this->input->post('id');
		$cdata['first_name'] 	= $this->input->post('first_name');
		$cdata['passport_no'] 	= $this->input->post('passport_no');
		$cdata['last_name'] 	= $this->input->post('last_name');
		$cdata['passport_no'] 	= $this->input->post('passport_no');
		$cdata['ticket_no'] 	= $this->input->post('ticket_no');
		$cdata['a_ticket_pnr'] 	= $this->input->post('a_ticket_pnr');
		$cdata['g_ticket_pnr'] 	= $this->input->post('g_ticket_pnr');
		$cdata['d_of_issue'] 	= $this->input->post('d_of_issue');
		$cdata['flight_name'] 	= $this->input->post('flight_name');
		$cdata['flight_code'] 	= $this->input->post('flight_code');
		$cdata['from_country'] 	= $this->input->post('from_country');
		$cdata['to_country'] 	= $this->input->post('to_country');
		$cdata['Depart'] 		= $this->input->post('Depart');
		$cdata['Arrive'] 		= $this->input->post('Arrive');
		$cdata['baggage'] 		= $this->input->post('baggage');
		$cdata['class'] 		= $this->input->post('class');
		$cdata['duration'] 		= $this->input->post('duration');
		$cdata['aircraft'] 		= $this->input->post('aircraft');
		$cdata['flight_date'] 	= date("m/d/Y", strtotime($this->input->post('flight_date')));

		if (empty($cdata['id'])) {
			$datas['smg'] = "<b style='color:red;'> Invalid !</b>";
			$this->session->set_flashdata($datas);
			redirect('TicketPasenger');
		}else{

			$this->Ticket_model->update_ticketPassengerData($ctable,$cdata);
			$datas['smg'] ="<b style='color:green;'>Successfuly Save !</b>";

		    /*activity Details*/
				$ATable = 'tb_activity';
				$AData = array();
				$AData['activity_details'] = '<div class="alert alert-success"> Success :)Add New Ticket By &mdash; '.$this->session->fullname.'<span style="font-size:12px;">('.$this->session->user_id.')</span> </div>';
				$this->Setting_model->insert_data_model($ATable,$AData); //ACTIVITY UPDATED...
		    /*activity details*/

			$this->session->set_flashdata($datas);
			redirect('Ticket/Pdf/'.$cdata['id']);
		}


	}


public function AddTicketPayment(){
		$adata = array();
		$table ='tb_ticket';
		$adata['payment_date'] = date("m/d/Y", strtotime($this->input->post('payment_date')));
		$adata['payment_method'] = $this->input->post('payment_method');
		$adata['payment_amount'] = $this->input->post('payment_amount');
		$adata['bank_name'] = $this->input->post('bank_name');
		$adata['bkash_n'] = $this->input->post('bkash_n');
		$adata['rocket_n'] = $this->input->post('rocket_n');
		$adata['nogod_n'] = $this->input->post('nogod_n');
		$adata['account_number'] = $this->input->post('account_number');
		$adata['type'] = 'Payment';
		$adata['created_at'] = date("m/d/Y");

		if (empty($adata['payment_date']) OR empty($adata['payment_method'] OR empty($adata['payment_amount']))) {
			$datas['smsp'] = "<b style='color:red;'> Invalid !</b>";
			$this->session->set_flashdata($datas);
			redirect('Ticket');
		}else{

			$this->Setting_model->insert_data_model($table,$adata);
			$datas['smsp'] ="<b style='color:green;'>Successfuly Save !</b>";
			$this->session->set_flashdata($datas);
			redirect('Ticket');
		}
}


	public function RemoveTicket($id){
		$data = array();
		$table = 'tb_ticket';
		$data['match_by'] 	= $id;
		$data['match_col']  = 'id';
		$this->Setting_model->Get_remove_data_method($table,$data);
    /*activity Details*/
		$ATable = 'tb_activity';
		$AData = array();
		$AData['activity_details'] = '<div class="alert alert-danger"> Success :)Remove Ticket By &mdash; '.$this->session->fullname.'<span style="font-size:12px;">('.$this->session->user_id.')</span> </div>';
		$this->Setting_model->insert_data_model($ATable,$AData); //ACTIVITY UPDATED...
    /*activity details*/
		$datas['smgdu'] = "<b style='color:red;'>Deleted Done !</b>";
       	$this->session->set_flashdata($datas);
        redirect('AllTicket');
	}

	public function PassengerRemove($id){
		$data = array();
		$table = 'tb_passenger';
		$data['match_by'] 	= $id;
		$data['match_col']  = 'id';
		$this->Setting_model->Get_remove_data_method($table,$data);
    /*activity Details*/
		$ATable = 'tb_activity';
		$AData = array();
		$AData['activity_details'] = '<div class="alert alert-danger"> Success :)Remove Customer By &mdash; '.$this->session->fullname.'<span style="font-size:12px;">('.$this->session->user_id.')</span> </div>';
		$this->Setting_model->insert_data_model($ATable,$AData); //ACTIVITY UPDATED...
    /*activity details*/
		$datas['smgdu'] = "<b style='color:red;'>Deleted Done !</b>";
       	$this->session->set_flashdata($datas);
        redirect('Ticket/TicketPasenger');
	}

}


