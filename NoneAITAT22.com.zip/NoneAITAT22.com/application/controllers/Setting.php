<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Setting extends CI_Controller {

	public function __construct(){
		parent:: __construct();
		
		$this->load->model('Customer_model');
		$this->load->model('Accounts_model');
		$this->load->model('Setting_model');
		$this->load->model('Agent_model');
		$this->load->model('User_model');
		

		$login_user = $this->session->userdata('user_id'); 
		if(isset($login_user)){
			$login_user; 
		}else{
			
			redirect('User/'); 
		} 
	}

	public function index()
	{
		$this->Category();
	}

//setting category ui method
	public function Category(){

		$data = array();

		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		
		$data['AllvisaCategory'] = $this->Setting_model->Get_data_method('tb_visa_category');
		$data['Allvisatypes'] = $this->Setting_model->Get_data_method('tb_visa_type');
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/setting/category.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}//end

//setting genarel ui method
	public function Genarel(){

		$data = array();
		//file link

		
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/setting/genarel.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}//end

// setting Error page 
	public function Error(){
		$data = array();

		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('inc/404.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}

// setting Expenses Category ui

	public function ExpensesCatgory(){
		$data = array();

		$data['AllExpensesCat'] = $this->Setting_model->Get_data_method('tb_expenses_category');
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/setting/expenses_cat.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}
	
	
// setting Expenses Category ui

	public function CashINOutCategory(){
		$data = array();

		$data['AllExpensesCat'] = $this->Setting_model->Get_data_method('tb_expenses_category');
		$data['AllCashINOutCat'] = $this->Setting_model->Get_data_method('tb_cashin_out_cat');
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/setting/cashin_out_cat.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}
	
	
// Expense Category 

	public function AdddCashINOUTCategory(){
		$data 	= array();
		$table 	='tb_cashin_out_cat';
		$data['name'] = $this->input->post('name');

		if (empty($data['name'])) {
			$datas['smg'] = "<h4 style='color:red;'> Please Check Name !</h4>";
            $this->session->set_flashdata($datas);
            redirect('Setting/CashINOutCategory');
		}else{
			$this->Setting_model->insert_data_model($table,$data);

			$datas['smg'] = "<h4 style='color:green;'> Successfuly Save !</h4>";
            $this->session->set_flashdata($datas);
            redirect('Setting/CashINOutCategory');
		}//else

	}//end



// Update Expenses Category
	public function UpdateCashINOutCategory(){
		$data 	= array();
		$table 	='tb_cashin_out_cat';
		$data['id'] = $this->input->post('id');
		$data['name'] = $this->input->post('name');

		if (empty($data['name'])) {
			$datas['smg'] = "<h4 style='color:red;'>Please Check Name !</h4>";
            $this->session->set_flashdata($datas);
            redirect('Setting/CashINOutCategory');
		}else{
			$this->Setting_model->CashINOut_cat_update_data_model($table,$data);

			$datas['smg'] = "<h4 style='color:green;'>Successfuly Updated !</h4>";
            $this->session->set_flashdata($datas);
            redirect('Setting/CashINOutCategory');
		}//else

	}
	

	public function RemoveCashInOut($id){
		$data = array();
		$table = 'tb_cashin_out_cat';
		$data['match_by'] 	= $id;
		$data['match_col']  = 'id';
		$this->Setting_model->Get_remove_data_method($table,$data);

		$datas['smgdu'] = "<b style='color:red;'>Deleted Done !</b>";
       	$this->session->set_flashdata($datas);
        redirect('Setting/CashINOutCategory');
	}
//General setting update

    public function GeneralUpdate(){
        
		$sdata = array();
		$table= 'tb_setting';
		$sdata['id']          = $this->input->post('id');
		$sdata['title']       = $this->input->post('title');
		$sdata['name']        = $this->input->post('name');
		$sdata['address']     = $this->input->post('address');
		$sdata['phone']     = $this->input->post('phone');
		$sdata['email']     = $this->input->post('email');
		if(empty($sdata['id'] )){
		/*-------msg------*/
		$Sdata['msg'] = '<div class="alert alert-danger"><button type="button" class="close" data-dismiss="alert">×</button><strong>Faild Update Save!</strong> :)</div>';
		$this->session->set_flashdata($Sdata); 
			redirect('Setting/Genarel/'); 
			}else{

				$old_image	= $this->input->post('old_image');
				/*-----------------------------------------------*/
				$change_image = $_FILES["logo"]['name'];
				if(!empty($change_image)){
				unlink('images/'.$old_image); 
				$new_name                   	= $change_image; 
				$config['file_name']        	= $new_name;
				$config['upload_path']          = 'images/';
				$config['remove_spaces']        =FALSE;
			    $config['allowed_types']        = 'gif|jpg|jpeg|png|pdf';
				$this->load->library('upload', $config);
			    $sdata['logo'] = $new_name;

			    if (! $this->upload->do_upload('logo')){
			    $error = array('error' => $this->upload->display_errors());
			    $this->load->view('upload_form', $error);
			    }else{	
			    array('upload_data' => $this->upload->data());
			     }
				}
		$this->Setting_model->GeneralsettingUpdate($table,$sdata); 	
		/*-------msg------*/
		$Sdata['msg'] = '<div class="alert alert-warning"><button type="button" class="close" data-dismiss="alert">×</button><strong>Successfully Update!</strong> :)</div>';
		$this->session->set_flashdata($Sdata); 
		redirect('Setting/Genarel/'); 
		}

    }

// Setting Functions 

	public function AddNewVisaCategory(){
		$data 	= array();
		$table 	='tb_visa_category';
		$data['cat_name'] = $this->input->post('cat_name');

		if (empty($data['cat_name'])) {
			$datas['smg'] = "<h4 style='color:red;'>Please Check Name !</h4>";
            $this->session->set_flashdata($datas);
            redirect('Setting');
		}else{
			$this->Setting_model->insert_data_model($table,$data);

			$datas['smg'] = "<h4 style='color:green;'>Successfuly Save !</h4>";
            $this->session->set_flashdata($datas);
            redirect('Setting');
		}//else

	}//end

//remove visa category
	public function remove_visa_category($id){
		$data=array();
		$table ='tb_visa_category';
		$data['match_by'] 	= $id;
		$data['match_col']  = 'id';
		$this->Setting_model->Get_remove_data_method($table,$data);

		$datas['smg'] = "<h4 style='color:red;'>Deleted Done !</h4>";
       	$this->session->set_flashdata($datas);
        redirect('Setting');
	}

//update visa category 
	public function UpdateVisaCategory(){
		$data 	= array();
		$table 	='tb_visa_category';
		$data['id'] = $this->input->post('id');
		$data['cat_name'] = $this->input->post('cat_name');

		if (empty($data['cat_name'])) {
			$datas['smg'] = "<h4 style='color:red;'>Please Check Name !</h4>";
            $this->session->set_flashdata($datas);
            redirect('Setting');
		}else{
			$this->Setting_model->cat_update_data_model($table,$data);

			$datas['smg'] = "<h4 style='color:green;'>Successfuly Updated !</h4>";
            $this->session->set_flashdata($datas);
            redirect('Setting');
		}//else

	}


// Add New Visa Type Functions 
	public function AddNewVisaType(){
		$data 	= array();
		$table 	='tb_visa_type';
		$data['visa_type'] = $this->input->post('visa_type');

		if (empty($data['visa_type'])) {
			$datas['smgv'] = "<h4 style='color:red;'>Invalid ! Please Check Name !</h4>";
            $this->session->set_flashdata($datas);
            redirect('Setting');
		}else{
			$this->Setting_model->insert_data_model($table,$data);

			$datas['smgv'] = "<h4 style='color:green;'>Successfuly Save !</h4>";
            $this->session->set_flashdata($datas);
            redirect('Setting');
		}//else

	}//end


//remove visa Type
	public function remove_visa_type($id){
		$data=array();
		$table ='tb_visa_type';
		$data['match_by'] 	= $id;
		$data['match_col']  = 'id';
		$this->Setting_model->Get_remove_data_method($table,$data);

		$datas['smgdu'] = "<h4 style='color:red;'>Deleted Done !</h4>";
       	$this->session->set_flashdata($datas);
        redirect('Setting');
	}

//update visa Type 
	public function UpdateVisaType(){
		$data 	= array();
		$table 	='tb_visa_type';
		$data['id'] = $this->input->post('id');
		$data['visa_type'] = $this->input->post('visa_type');
		$this->Setting_model->update_visa_data_model($table,$data);
		$datas['smgdu'] = "<h4 style='color:green;'> Successfuly Updated !</h4>";
        $this->session->set_flashdata($datas);
        redirect('Setting');
	}
// Expense Category 

	public function AddNewExpensesCategory(){
		$data 	= array();
		$table 	='tb_expenses_category';
		$data['expenses_cat_name'] = $this->input->post('expenses_cat_name');

		if (empty($data['expenses_cat_name'])) {
			$datas['smg'] = "<h4 style='color:red;'> Please Check Name !</h4>";
            $this->session->set_flashdata($datas);
            redirect('Setting/ExpensesCatgory');
		}else{
			$this->Setting_model->insert_data_model($table,$data);
    /*activity Details*/
		$ATable = 'tb_activity';
		$AData = array();
		$AData['activity_details'] = '<div class="alert alert-success"> Success :)Expenses catgory Add By &mdash; '.$this->session->fullname.'<span style="font-size:12px;">('.$this->session->user_id.')</span> </div>';
		$this->Setting_model->insert_data_model($ATable,$AData); //ACTIVITY UPDATED...
    /*activity details*/
			$datas['smg'] = "<h4 style='color:green;'> Successfuly Save !</h4>";
            $this->session->set_flashdata($datas);
            redirect('Setting/ExpensesCatgory');
		}//else

	}//end

// Update Expenses Category

	public function UpdateExpensesCategory(){
		$data 	= array();
		$table 	='tb_expenses_category';
		$data['id'] = $this->input->post('id');
		$data['expenses_cat_name'] = $this->input->post('expenses_cat_name');

		if (empty($data['expenses_cat_name'])) {
			$datas['smg'] = "<h4 style='color:red;'>Please Check Name !</h4>";
            $this->session->set_flashdata($datas);
            redirect('Setting/ExpensesCatgory');
		}else{
			$this->Setting_model->Expenses_cat_update_data_model($table,$data);
    /*activity Details*/
		$ATable = 'tb_activity';
		$AData = array();
		$AData['activity_details'] = '<div class="alert alert-warning"> Success :)Expenses category Update By &mdash; '.$this->session->fullname.'<span style="font-size:12px;">('.$this->session->user_id.')</span> </div>';
		$this->Setting_model->insert_data_model($ATable,$AData); //ACTIVITY UPDATED...
    /*activity details*/
			$datas['smg'] = "<h4 style='color:green;'>Successfuly Updated !</h4>";
            $this->session->set_flashdata($datas);
            redirect('Setting/ExpensesCatgory');
		}//else

	}
}
