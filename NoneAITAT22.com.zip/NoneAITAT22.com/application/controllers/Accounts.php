<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Accounts extends CI_Controller {

	public function __construct(){
		parent:: __construct();
		$this->load->model('Setting_model');
		$this->load->model('Customer_model');
		$this->load->model('Agent_model');
		$this->load->model('Accounts_model');
		$this->load->model('Expenses_model');
		$this->load->model('User_model');
		$login_user = $this->session->userdata('user_id'); 
		if(isset($login_user)){
			$login_user; 
		}else{
			
			redirect('User/'); 
		} 
	}

	public function index()
	{
		$this->CustomerPayment();
	}

//Customer payment ui
	public function CustomerPayment(){
		$data = array();

		$data['AllAgentList'] =  $this->Setting_model->Get_data_method('tb_agent');
		$data['AllvisaCategory'] = $this->Setting_model->Get_data_method('tb_visa_category');
		$data['AllCashInCatData'] = $this->Accounts_model->Get_data_method('tb_cashin_out_cat');
		$data['Allvisatypes'] = $this->Setting_model->Get_data_method('tb_visa_type');
		$data['AllPaymentData'] = $this->Accounts_model->Get_data_method('tb_payment');
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));

		$sdata=array(
			'serial_no' => $this->input->post('serial_no'), 
			//'visa_no' => $this->input->post('visa_no'), 
			);		
		$data['CustomerAccounts'] =  $this->Setting_model->Get_data_by_search_key_model('tb_customer',$sdata);
		
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/accounts/customer_accounts_list.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}//end

//Customer payment ui
	public function CustomerSearch(){
		$data = array();

		$data['AllAgentList'] =  $this->Setting_model->Get_data_method('tb_agent');
		$data['AllvisaCategory'] = $this->Setting_model->Get_data_method('tb_visa_category');
		$data['Allvisatypes'] = $this->Setting_model->Get_data_method('tb_visa_type');
		$data['AllCashInCatData'] = $this->Accounts_model->Get_data_method('tb_cashin_out_cat');
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));

		$sdata=array(
			'serial_no' => $this->input->post('serial_no'), 
			//'visa_no' => $this->input->post('visa_no'), 
			);		
		$data['CustomerAccounts'] =  $this->Setting_model->Get_data_by_search_key_model('tb_customer',$sdata);
		$data['Voucherdata'] = $this->Accounts_model->Get_data_singleData_id('tb_payment',$data);
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/accounts/customer_accounts.php',$sdata),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}//end

	public function CustomerInvoice($id){
		$data = array();

		$CIdata=array(
			'match_col' => 'id',
			'match_by'	=> $id
			);		
		$data['InvoiceData'] =  $this->Customer_model->GetSingleDataById('tb_payment',$CIdata);
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/accounts/customer_invoice.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}
	


// Agent Payment ui 

	public function AgentPayment(){
		$data = array();

		$data['AllAgentList'] =  $this->Setting_model->Get_data_method('tb_agent');
		$data['AllvisaCategory'] = $this->Setting_model->Get_data_method('tb_visa_category');
		$data['Allvisatypes'] = $this->Setting_model->Get_data_method('tb_visa_type');
		$data['AllPaymentData'] = $this->Accounts_model->Get_data_method('tb_payment');
		$data['AllCashInCatData'] = $this->Accounts_model->Get_data_method('tb_cashin_out_cat');
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));

		$sdata=array(
			'agent_id' => $this->input->post('agent_id'), 
			//'visa_no' => $this->input->post('visa_no'), 
			);		
		$data['AgentAccount'] =  $this->Accounts_model->Get_data_by_search_key_model('tb_agent',$sdata);
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/accounts/Agent_accounts_list.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}//end


	public function AgentSearch(){
		$data = array();

		$sdata=array(
			'agent_id' => $this->input->post('agent_id'), 
			//'visa_no' => $this->input->post('visa_no'), 
			);		
		$data['AgentAccount'] =  $this->Accounts_model->Get_data_by_search_key_model('tb_agent',$sdata);
		$data['AllCashInCatData'] = $this->Accounts_model->Get_data_method('tb_cashin_out_cat');
		$data['Voucherdata'] = $this->Accounts_model->Get_data_singleData_id('tb_payment',$data);
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/accounts/Agent_accounts.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}


//Agent Invoice 
	public function AgentInvoice($id){
		$data = array();

		$CIdata=array(
			'match_col' => 'id',
			'match_by'	=> $id
			);		
		$data['InvoiceData'] =  $this->Customer_model->GetSingleDataById('tb_payment',$CIdata);
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/accounts/Agent_invoice.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}

// customer payment report 
	public function CustomerPaymentReport(){
		$data = array();

		$data['AllAgentList'] =  $this->Setting_model->Get_data_method('tb_agent');
		$data['AllvisaCategory'] = $this->Setting_model->Get_data_method('tb_visa_category');
		$data['Allvisatypes'] = $this->Setting_model->Get_data_method('tb_visa_type');
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));

		$sdata=array(
			'serial_no' => $this->input->post('serial_no'), 
			//'visa_no' => $this->input->post('visa_no'), 
			);		
		$data['CustomerAccounts'] =  $this->Setting_model->Get_data_by_search_key_model('tb_customer',$sdata);
		$data['Voucherdata'] = $this->Accounts_model->Get_data_singleData_id('tb_payment',$data);
		
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/
		
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/accounts/customer_payment-report.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}

// Cash Report
	public function CashReport(){
		$data = array();
		//file link

		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/accounts/cash_report.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}

// Daily Cash In And Cash Out  Report 
	public function DailyCashInAndOurReport(){
		$data = array();

		$sdata=array(
			'payment_date' => $this->input->post('payment_date'), 
			);		
		$data['DailyCashData'] =  $this->Accounts_model->Get_data_Daily_CashIN_OUT_search_key_model('tb_payment',$sdata);

		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/accounts/daily_cash_report.php',$sdata),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}
// Daily Expense Report 
	public function DailyCashSearch(){
		$data = array();

		$sdata=array(
			'payment_date' =>date("m/d/Y", strtotime($this->input->post('payment_date'))),
			'type' => $this->input->post('type'), 
			'payment_type' => $this->input->post('payment_type'),
			);		
		$data['DailyCashData'] =  $this->Accounts_model->Get_data_Daily_cahs_search_key_model('tb_payment',$sdata);

		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/accounts/daily_cash_report.php',$sdata),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}

	public function weeklymonthCahsSearch(){
		$data = array();

		$sdata=array(
			'fromdate' 	=> $this->input->post('fromdate'), 
			'todate' 	=> $this->input->post('todate'), 
			);		
		
		$data['MonthWeekCasheData'] =  $this->Accounts_model->weeklymonthCahsSearch('tb_payment',$sdata);

		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/accounts/w_d_cash_report.php',$sdata),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}

// insert New payment method

	public function AddNewPayment(){
		$data = array();
		$table = 'tb_payment';
		$data['voucher_no'] = $this->input->post('voucher_no');
		$data['customer_id'] = $this->input->post('customer_id');
		$data['for_payment'] = $this->input->post('for_payment');
		$data['method'] = $this->input->post('method');
		$data['payment'] = $this->input->post('payment');
		$data['payment_date'] = $this->input->post('payment_date');
		$data['bank_name'] = $this->input->post('bank_name');
		$data['bank_recepit_n'] = $this->input->post('bank_recepit_n');
		$data['bkash_n'] = $this->input->post('bkash_n');
		$data['rocket_n'] = $this->input->post('rocket_n');
		$data['details'] = $this->input->post('details');
		$data['type'] = 'customer';
		$data['payment_type'] = $this->input->post('payment_type');

		if (empty($data['customer_id']) OR empty($data['payment_type']) OR empty($data['for_payment']) OR empty($data['payment']) OR empty($data['payment_date']) ) {
			$mdata['sms'] = "<b style='color:red;'> Faild ! chcek Entry data , Name , Id Number Serial No</b>";
			$this->session->set_flashdata($mdata);
			redirect('Accounts/CustomerSearch');
		}else{

			$id = $this->Customer_model->Insert_id_data_moele($table,$data);


			$mdata['sms'] = "<b style='color:green;'> Successfuly Save !</b>";
			$this->session->set_flashdata($mdata);
			redirect('Accounts/CustomerInvoice/'.$id);

		}
	}


// Insert Old Customer payment method

	public function AddOlcustomerNewPayment(){
		$table = 'tb_payment';

		if (empty('customer_id') OR empty('payment_type') OR empty('for_payment') OR empty('payment') OR empty('payment_date') ) {
			$mdata['sms'] = "<b style='color:red;'> Faild ! chcek Entry data , Name , Id Number Serial No</b>";
			$this->session->set_flashdata($mdata);
			redirect('Accounts/CustomerSearch');
		}else{

	         $Oltable = 'tb_customer';
	        	$sdata = array(
		         'serial_no' => $this->input->post('serial_no'),
		         'entry_date' => $this->input->post('payment_date'),
		      );
            $customerrId = $this->Customer_model->Insert_id_data_moele($Oltable,$sdata);
            
		$data = array(
		    'voucher_no' => $this->input->post('voucher_no'),
		    'customer_id' => $customerrId,
		    'for_payment' => $this->input->post('for_payment'),
		    'method' => $this->input->post('method'),
		    'payment' => $this->input->post('payment'),
		    'payment_date' => $this->input->post('payment_date'),
		    'bank_name' => $this->input->post('bank_name'),
		    'bank_recepit_n' => $this->input->post('bank_recepit_n'),
		    'bkash_n' => $this->input->post('bkash_n'),
		    'rocket_n' => $this->input->post('rocket_n'),
		    'details' => $this->input->post('details'),
		    'type' => 'customer',
		    'payment_type' => $this->input->post('payment_type'),
		    );
            
			$id = $this->Customer_model->Insert_id_data_moele($table,$data);
            
			$mdata['sms'] = "<b style='color:green;'> Successfuly Save !</b>";
			$this->session->set_flashdata($mdata);
			redirect('Accounts/CustomerInvoice/'.$id);

		}
	}






// insert New Agent payment method

	public function AddNewAgentPayment(){
		$data = array();
		$table = 'tb_payment';
		$data['voucher_no'] = $this->input->post('voucher_no');
		$data['agent_id'] = $this->input->post('agent_id');
		$data['for_payment'] = $this->input->post('for_payment');
		$data['method'] = $this->input->post('method');
		$data['payment'] = $this->input->post('payment');
		$data['payment_date'] = $this->input->post('payment_date');
		$data['bank_name'] = $this->input->post('bank_name');
		$data['bank_recepit_n'] = $this->input->post('bank_recepit_n');
		$data['bkash_n'] = $this->input->post('bkash_n');
		$data['rocket_n'] = $this->input->post('rocket_n');
		$data['details'] = $this->input->post('details');
		$data['type'] = 'agent';
		$data['payment_type'] = $this->input->post('payment_type');

		if (empty($data['agent_id']) OR empty($data['for_payment']) OR empty($data['payment']) OR empty($data['payment_date']) ) {
			$mdata['sms'] = "<b style='color:red;'> Faild ! chcek Entry data , Name , Id Number Serial No</b>";
			$this->session->set_flashdata($mdata);
			redirect('Accounts/AgentSearch');
		}else{

			$id = $this->Customer_model->Insert_id_data_moele($table,$data);
			$mdata['sms'] = "<b style='color:green;'> Successfuly Save !</b>";
			$this->session->set_flashdata($mdata);
			redirect('Accounts/AgentInvoice/'.$id);

		}
	}

// Insert Old Customer payment method

	public function AddOlAgentNewPayment(){
		$table = 'tb_payment';

		if (empty('customer_id') OR empty('payment_type') OR empty('for_payment') OR empty('payment') OR empty('payment_date') ) {
			$mdata['sms'] = "<b style='color:red;'> Faild ! chcek Entry data , Name , Id Number Serial No</b>";
			$this->session->set_flashdata($mdata);
			redirect('Accounts/AgentInvoice');
		}else{

	         $Oltable = 'tb_agent';
	        	$sdata = array(
		         'agent_id' => $this->input->post('agent_id'),
		      );
            $AgentId = $this->Customer_model->Insert_id_data_moele($Oltable,$sdata);
            
		$data = array(
		    'voucher_no' => $this->input->post('voucher_no'),
		    'agent_id' => $AgentId,
		    'for_payment' => $this->input->post('for_payment'),
		    'method' => $this->input->post('method'),
		    'payment' => $this->input->post('payment'),
		    'payment_date' => $this->input->post('payment_date'),
		    'bank_name' => $this->input->post('bank_name'),
		    'bank_recepit_n' => $this->input->post('bank_recepit_n'),
		    'bkash_n' => $this->input->post('bkash_n'),
		    'rocket_n' => $this->input->post('rocket_n'),
		    'details' => $this->input->post('details'),
		    'type' => 'agent',
		    'payment_type' => $this->input->post('payment_type'),
		    );
            
			$id = $this->Customer_model->Insert_id_data_moele($table,$data);
            
			$mdata['sms'] = "<b style='color:green;'> Successfuly Save !</b>";
			$this->session->set_flashdata($mdata);
			redirect('Accounts/AgentInvoice/'.$id);

		}
	}
	public function CustomerPaymentEdit(){

		$data = array();
		$table = 'tb_payment';
		$data['id'] = $this->input->post('id');
		$data['for_payment'] = $this->input->post('for_payment');
		$data['method'] = $this->input->post('method');
		$data['payment'] = $this->input->post('payment');
		$data['payment_date'] = $this->input->post('payment_date');
		$data['bank_name'] = $this->input->post('bank_name');
		$data['bank_recepit_n'] = $this->input->post('bank_recepit_n');
		$data['bkash_n'] = $this->input->post('bkash_n');
		$data['rocket_n'] = $this->input->post('rocket_n');
		$data['details'] = $this->input->post('details');
		$data['payment_type'] = $this->input->post('payment_type');

			$this->Accounts_model->EditPayment_get_data_By_ID($table,$data);
			$mdata['sms'] = "<b style='color:green;'> Successfuly Save !</b>";
			$this->session->set_flashdata($mdata);
			redirect('Accounts/CustomerInvoice/'.$data['id']);

	}
	
	public function AgentPaymentEdit(){

		$data = array();
		$table = 'tb_payment';
		$data['id'] = $this->input->post('id');
		$data['for_payment'] = $this->input->post('for_payment');
		$data['method'] = $this->input->post('method');
		$data['payment'] = $this->input->post('payment');
		$data['payment_date'] = $this->input->post('payment_date');
		$data['bank_name'] = $this->input->post('bank_name');
		$data['bank_recepit_n'] = $this->input->post('bank_recepit_n');
		$data['bkash_n'] = $this->input->post('bkash_n');
		$data['rocket_n'] = $this->input->post('rocket_n');
		$data['details'] = $this->input->post('details');
		$data['payment_type'] = $this->input->post('payment_type');

			$this->Accounts_model->EditPayment_get_data_By_ID($table,$data);
			$mdata['sms'] = "<b style='color:green;'> Successfuly Save !</b>";
			$this->session->set_flashdata($mdata);
			redirect('Accounts/AgentInvoice/'.$data['id']);

	}

}//end Accounts Controller