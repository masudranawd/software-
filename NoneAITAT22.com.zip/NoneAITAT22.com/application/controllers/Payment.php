<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Payment extends CI_Controller {

	public function __construct(){
		parent:: __construct();
		$this->load->model('Customer_model');
		$this->load->model('Accounts_model');
		$this->load->model('Setting_model');
		$this->load->model('Agent_model');
		$this->load->model('User_model');
		$this->load->model('Payment_model');
		$this->load->model('Vendor_model');
		$this->load->model('Ticket_model');
		$login_user = $this->session->userdata('user_id'); 
		if(isset($login_user)){
			$login_user; 
		}else{
			
			redirect('User/'); 
		} 
	}

	public function index()
	{
		$this->VendorPayment();
	}

//Customer payment ui
	public function Pay_Date(){
		$data = array();

		$data['AllCustomerList'] =  $this->Customer_model->Get_data_method('tb_customer');
		$data['AllPayDate'] = $this->Accounts_model->Get_data_method('tb_pay_date');
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));

		$sdata=array(
			'serial_no' => $this->input->post('serial_no'), 
			//'visa_no' => $this->input->post('visa_no'), 
			);		
		$data['CustomerAccounts'] =  $this->Setting_model->Get_data_by_search_key_model('tb_customer',$sdata);
		
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/payment/pay_date.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}//end


//Cash In payment ui
	public function CashInayment($id){
		$data = array();
		$data['id'] = $id;
			/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_pay_date';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = $id; 
		$data['PayDate'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	

		$data['AllVendorData']   =  $this->Setting_model->Get_data_method('tb_vendor');
		$data['AllAgentList']    =  $this->Setting_model->Get_data_method('tb_agent');
		$data['AllvisaCategory'] = $this->Setting_model->Get_data_method('tb_visa_category');
		$data['Allvisatypes'] 	 = $this->Setting_model->Get_data_method('tb_visa_type');
		$data['AllPaymentData']  = $this->Setting_model->Get_data_method('tb_ticket');



		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));

		$sdata=array(
			'serial_no' => $this->input->post('serial_no'), 
			//'visa_no' => $this->input->post('visa_no'), 
			);		
		$data['CustomerAccounts'] =  $this->Setting_model->Get_data_by_search_key_model('tb_customer',$sdata);
		
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/asset.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/payment/daily_lager.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}//end



	public function PayDateSearch(){
		$data = array();
		$data['id'] = $this->input->post('id');
			/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_pay_date';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] =$this->input->post('id'); 
		$data['PayDate'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	

		$data['AllVendorData']   =  $this->Setting_model->Get_data_method('tb_vendor');
		$data['AllAgentList']    =  $this->Setting_model->Get_data_method('tb_agent');
		$data['AllvisaCategory'] = $this->Setting_model->Get_data_method('tb_visa_category');
		$data['Allvisatypes'] 	 = $this->Setting_model->Get_data_method('tb_visa_type');
		$data['AllPaymentData']  = $this->Setting_model->Get_data_method('tb_ticket');


		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));

		$sdata=array(
			'id' => $this->input->post('id'), 
			);		
		$data['AllPaymentDatal'] =  $this->Ticket_model->Get_data_pay_by_search_key_model('tb_pay_date',$sdata);
		
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/asset.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/payment/daily_lager.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}


//===================================================================================|	
/*function add*/

	public function AddNewPayDate(){
		$data = array();
		$table = 'tb_pay_date';
		$data['pay_date'] = $this->input->post('pay_date');
		$data['date_id'] = date("md", strtotime($this->input->post('pay_date')));

		 $check = $this->Payment_model->CheckPayDateNoData($data['pay_date']);
		    if($check == false){
				$id = $this->Customer_model->Insert_id_data_moele($table,$data);
				$mdata['sms'] = "<b style='color:green;'> Successfuly Save !</b>";
				$this->session->set_flashdata($mdata);
				redirect('Payment/CashInayment/'.$id);
			}else{

		    $mdata['sms'] = "<b style='color:red;'> <strong> This Date Is Already Been Taken .Please Use Another One Date!</strong> !</b>";
			$this->session->set_flashdata($mdata);
			redirect('Pay_Date');
			}
	}


/*Payment Add */

public function AddNewCashInPaymentData(){

		$data = array();
		$table 					= 'tb_ticket';
		$data['pay_id'] 		= $this->input->post('pay_id');
		$id 					= $this->input->post('pay_id');
		$data['agent_id']	 	= $this->input->post('agent_id');
		$data['vendor_id'] 		= $this->input->post('vendor_id');
		$data['payment_method'] = $this->input->post('payment_method');
		$data['payment_amount'] = $this->input->post('payment_amount');
		$data['payment_date'] 	=  date("m/d/Y", strtotime($this->input->post('payment_date')));
		$data['bank_name']		= $this->input->post('bank_name');
		$data['bkash_n'] 		= $this->input->post('bkash_n');
		$data['account_number'] = $this->input->post('account_number');
		$data['nogod_n'] 		= $this->input->post('nogod_n');
		$data['rocket_n'] 		= $this->input->post('rocket_n');
		$data['remark']			= $this->input->post('remark');
		$data['type'] 			= 'Payment';
		$data['created_at'] 	= date('m/d/Y');



		if(empty($data['payment_amount'])){
			$mdata['sms'] = "<b style='color:red;'> Faild ! chcek Entry Type, Amount, Money Recipt</b>";
			$this->session->set_flashdata($mdata);
			redirect('Payment/CashInayment/'.$id);
		}else{

			$this->Setting_model->insert_data_model($table,$data);

	/*activity Details*/
		$ATable = 'tb_activity';
		$AData = array();
		$AData['activity_details'] = '<div class="alert alert-success"> Success :)Customer Payment By &mdash; '.$this->session->fullname.'<span style="font-size:12px;">('.$this->session->user_id.')</span> Customer Serial No &mdash;'.$serial_no.'</div>';
		$this->Setting_model->insert_data_model($ATable,$AData); //ACTIVITY UPDATED...
        /*activity details*/

			$mdata['sms'] = "<b style='color:orange;'> Successfuly Save !</b>";
			$this->session->set_flashdata($mdata);
			redirect('Payment/CashInayment/'.$id);

		}
}













































//Customer payment ui
	public function VendorPayment(){
		$data = array();

		$data['AllVendorData'] =  $this->Setting_model->Get_data_method('tb_vendor');
		$data['Voucherdata'] = $this->Accounts_model->Get_data_singleData_id('tb_ticket',$data);
		$sdata=array(
			'vendor_id' => $this->input->post('vendor_id'), 
			);	
		$data['VendorAccount'] =  $this->Vendor_model->Get_data_by_Vendorsearch_key_model('tb_vendor',$sdata);
		//var_dump($data['VendorAccount'] );die();
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));

		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/payment/vendor_payment.php',$sdata),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}//end

//Customer payment ui
	public function AllPayment(){
		$data = array();

		$data['AllPaymentData'] =  $this->Setting_model->Get_data_method('tb_ticket');
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));

		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/payment/all_payment.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}//end

	public function CustomerInvoice($id){
		$data = array();

		$CIdata=array(
			'match_col' => 'id',
			'match_by'	=> $id
			);		
		$data['InvoiceData'] =  $this->Customer_model->GetSingleDataById('tb_ticket',$CIdata);
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/payment/vendor_invoice.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}
	


// Agent Payment ui 

	public function AgentPayment(){
		$data = array();

		$data['AllAgentList'] =  $this->Setting_model->Get_data_method('tb_agent');

		$sdata=array(
			'agent_id' => $this->input->post('agent_id'), 
			);	
		$data['AgentAccount'] =  $this->Agent_model->Get_data_by_Aagentsearch_key_model('tb_agent',$sdata);
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/payment/agent_payment.php',$sdata),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}//end



//Agent Invoice 
	public function AgentInvoice($id){
		$data = array();

		$CIdata=array(
			'match_col' => 'id',
			'match_by'	=> $id
			);		
		$data['InvoiceData'] =  $this->Customer_model->GetSingleDataById('tb_ticket',$CIdata);
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/payment/Agent_invoice.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}

// Cash Report
	public function PaymentReport(){
		$data = array();
		//file link

		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/payment/payment_report.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}

// Daily Payment  Report 
	public function DailyPaymentReport(){
		$data = array();

		$sdata=array(
			'payment_date' => $this->input->post('payment_date'), 
			);		
		$data['DailyCashData'] =  $this->Payment_model->Get_data_Daily_Payment_search_key_model('tb_ticket',$sdata);

		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/payment/daily_payment_report.php',$sdata),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}

	public function weeklymonthPaymentReport(){
		$data = array();

		$sdata=array(
			'fromdate' => date("m/d/Y", strtotime($this->input->post('fromdate'))), 
			'todate' => date("m/d/Y", strtotime($this->input->post('todate'))), 
			);		

		$data['MonthlyWeeklyListData'] =  $this->Payment_model->weeklymonthReportModel('tb_ticket',$sdata);
		//var_dump($data['MonthlyWeeklyListData']); die();

		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/payment/month_weekly_report.php',$sdata),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}


	public function AllReport(){
		$data = array();

		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/payment/report.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}


	public function AllReprotData(){
		$data = array();

		$sdata=array(
			'fromdate' => date("m/d/Y", strtotime($this->input->post('fromdate'))), 
			'todate' => date("m/d/Y", strtotime($this->input->post('todate'))), 
			);		

		$data['AllPaymentData'] =  $this->Payment_model->weeklymonthReportModel('tb_ticket',$sdata);
		$data['AllTicketBookingData'] =  $this->Payment_model->TicketweeklymonthReportModel('tb_ticket',$sdata);
		//var_dump($data['MonthlyWeeklyListData']); die();

		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/payment/all_report.php',$sdata),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}


// insert New payment method

	public function AddNewVendorPayment(){
		$data = array();
		$table = 'tb_ticket';
		$data['vendor_id'] = $this->input->post('vendor_id');
		$data['payment_method'] = $this->input->post('payment_method');
		$data['payment_amount'] = $this->input->post('payment_amount');
		$data['payment_due']	= $this->input->post('payment_due') - $data['payment_amount'];
		$data['payment_date'] =  date("m/d/Y", strtotime($this->input->post('payment_date')));
		$data['bank_name'] = $this->input->post('bank_name');
		$data['bkash_n'] = $this->input->post('bkash_n');
		$data['account_number'] = $this->input->post('account_number');
		$data['nogod_n'] = $this->input->post('nogod_n');
		$data['rocket_n'] = $this->input->post('rocket_n');
		$data['remark']	= $this->input->post('remark');
		$data['type'] = 'Payment';
		$data['created_at'] = date('m/d/Y');

		if (empty($data['vendor_id']) OR empty($data['payment_amount']) OR empty($data['payment_date']) ) {
			$mdata['sms'] = "<b style='color:red;'> Faild ! chcek Entry data ,Amount, Payment_method</b>";
			$this->session->set_flashdata($mdata);
			redirect('Payment');
		}else{
			$id = $this->Customer_model->Insert_id_data_moele($table,$data);
    /*activity Details*/
		$ATable = 'tb_activity';
		$AData = array();
		$AData['activity_details'] = '<div class="alert alert-success"> Success :)Vendor Payment Add By &mdash; '.$this->session->fullname.'<span style="font-size:12px;">('.$this->session->user_id.')</span> </div>';
		$this->Setting_model->insert_data_model($ATable,$AData); //ACTIVITY UPDATED...
    /*activity details*/
    
			$mdata['sms'] = "<b style='color:green;'> Successfuly Save !</b>";
			$this->session->set_flashdata($mdata);
			redirect('Payment');
			//redirect('Payment/CustomerInvoice/'.$id);

		}
	}

// insert New Agent payment method

	public function AddNewAgentPayment(){
		$data = array();
		$table = 'tb_ticket';
		$data['agent_id'] = $this->input->post('agent_id');
		$data['payment_method'] = $this->input->post('payment_method');
		$data['payment_amount'] = $this->input->post('payment_amount');
		$data['payment_due']	= $this->input->post('payment_due') - $data['payment_amount'];
		$data['payment_date'] =  date("m/d/Y", strtotime($this->input->post('payment_date')));
		$data['bank_name'] = $this->input->post('bank_name');
		$data['bkash_n'] = $this->input->post('bkash_n');
		$data['account_number'] = $this->input->post('account_number');
		$data['nogod_n'] = $this->input->post('nogod_n');
		$data['rocket_n'] = $this->input->post('rocket_n');
		$data['remark']	= $this->input->post('remark');
		$data['type'] = 'Payment';
		$data['created_at'] = date('m/d/Y');

		if (empty($data['agent_id']) OR empty($data['payment_amount']) OR empty($data['payment_date']) ) {
			$mdata['sms'] = "<b style='color:red;'> Faild ! chcek Entry data , Amount </b>";
			$this->session->set_flashdata($mdata);
			redirect('AgentPayment');
		}else{
			$id = $this->Customer_model->Insert_id_data_moele($table,$data);
			
    /*activity Details*/
		$ATable = 'tb_activity';
		$AData = array();
		$AData['activity_details'] = '<div class="alert alert-info"> Success :) Customer Payment Add By &mdash; '.$this->session->fullname.'<span style="font-size:12px;">('.$this->session->user_id.')</span> </div>';
		$this->Setting_model->insert_data_model($ATable,$AData); //ACTIVITY UPDATED...
    /*activity details*/
    
			$mdata['sms'] = "<b style='color:green;'> Successfuly Save !</b>";
			$this->session->set_flashdata($mdata);
			redirect('Payment/AgentPayment/');
			//redirect('Payment/AgentInvoice/'.$id);

		}
	}


	public function CustomerPaymentEdit(){

		$data = array();
		$table = 'tb_ticket';
		$data['id'] = $this->input->post('id');
		$data['for_payment'] = $this->input->post('for_payment');
		$data['method'] = $this->input->post('method');
		$data['payment'] = $this->input->post('payment');
		$data['payment_date'] = $this->input->post('payment_date');
		$data['bank_name'] = $this->input->post('bank_name');
		$data['bank_recepit_n'] = $this->input->post('bank_recepit_n');
		$data['bkash_n'] = $this->input->post('bkash_n');
		$data['rocket_n'] = $this->input->post('rocket_n');
		$data['details'] = $this->input->post('details');
		$data['payment_type'] = $this->input->post('payment_type');

			$this->Accounts_model->EditPayment_get_data_By_ID($table,$data);
			$mdata['sms'] = "<b style='color:green;'> Successfuly Save !</b>";
			$this->session->set_flashdata($mdata);
			redirect('Accounts/CustomerInvoice/'.$data['id']);

	}
	
	public function AgentPaymentEdit(){

		$data = array();
		$table = 'tb_ticket';
		$data['id'] = $this->input->post('id');
		$data['for_payment'] = $this->input->post('for_payment');
		$data['method'] = $this->input->post('method');
		$data['payment'] = $this->input->post('payment');
		$data['payment_date'] = $this->input->post('payment_date');
		$data['bank_name'] = $this->input->post('bank_name');
		$data['bank_recepit_n'] = $this->input->post('bank_recepit_n');
		$data['bkash_n'] = $this->input->post('bkash_n');
		$data['rocket_n'] = $this->input->post('rocket_n');
		$data['details'] = $this->input->post('details');
		$data['payment_type'] = $this->input->post('payment_type');

			$this->Accounts_model->EditPayment_get_data_By_ID($table,$data);
			$mdata['sms'] = "<b style='color:green;'> Successfuly Save !</b>";
			$this->session->set_flashdata($mdata);
			redirect('Accounts/AgentInvoice/'.$data['id']);

	}

	public function removePayment($id){
		$data = array();
		$table = 'tb_ticket';
		$data['match_by'] 	= $id;
		$data['match_col']  = 'id';
		$this->Setting_model->Get_remove_data_method($table,$data);
		
    /*activity Details*/
		$ATable = 'tb_activity';
		$AData = array();
		$AData['activity_details'] = '<div class="alert alert-danger"> Success :)Remove Payment By &mdash; '.$this->session->fullname.'<span style="font-size:12px;">('.$this->session->user_id.')</span> </div>';
		$this->Setting_model->insert_data_model($ATable,$AData); //ACTIVITY UPDATED...
    /*activity details*/
    
		$datas['smgdu'] = "<b style='color:red;'>Deleted Done !</b>";
       	$this->session->set_flashdata($datas);
        redirect('Payment/AllPayment');
	}

}//end Accounts Controller