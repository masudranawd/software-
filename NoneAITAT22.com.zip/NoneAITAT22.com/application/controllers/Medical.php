<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Medical extends CI_Controller {

	public function __construct(){
		parent:: __construct();
		$this->load->model('Setting_model');
		$this->load->model('Customer_model');
		$this->load->model('Accounts_model');
		$this->load->model('Agent_model');
		$this->load->model('User_model');
		$this->load->model('Payment_model');
		$this->load->model('Medical_model');
		$this->load->model('Ticket_model');
		$login_user = $this->session->userdata('user_id'); 
		if(isset($login_user)){
			$login_user; 
		}else{
			redirect('User/'); 
		} 
	}

	public function index()
	{
		$this->AddMedical();
	}

	//Add Medical ui Mehthod

	public function AddMedical(){
		$data = array();
		$data['AllAgentList'] =  $this->Setting_model->Get_data_method('tb_agent');
		$data['AllVendorData']  =  $this->Setting_model->Get_data_method('tb_vendor');
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/medical/add_medical.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}//end


	public function AllMedical(){
		$data = array();
	$data['AllPassengerList'] = $this->Customer_model->Get_data_method('tb_medical_passenger');
		$data['AllMedicalData'] =  $this->Setting_model->Get_data_method('tb_medical');
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/medical/all_medical.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}//end


	public function AllMedicalPayment(){
		$data = array();
		$data['AllPassengerList'] =  $this->Customer_model->Get_data_method('tb_medical_passenger');
		$data['AllMedicalData'] =  $this->Setting_model->Get_data_method('tb_medical');
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/medical/all_medical_payment.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}//end

	public function MedicalPayDate(){
		$data = array();

		$data['AllPassengerList'] =  $this->Customer_model->Get_data_method('tb_medical_passenger');
		$data['AllMedicalData'] =  $this->Setting_model->Get_data_method('tb_pay_m_date');
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/medical/m_pay_date.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}


	public function PayDateSearch(){
		$data = array();
		$data['id'] = $this->input->post('id');
			/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_pay_m_date';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] =$this->input->post('id'); 
		$data['PayDate'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	

		$data['AllVendorData']   =  $this->Setting_model->Get_data_method('tb_vendor');
		$data['AllAgentList']    =  $this->Setting_model->Get_data_method('tb_agent');
		$data['AllPaymentData']  = $this->Setting_model->Get_data_method('tb_medical');


		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));

		$sdata=array(
			'id' => $this->input->post('id'), 
			);		
		$data['AllPaymentDatal'] =  $this->Ticket_model->Get_data_pay_by_search_key_model('tb_pay_m_date',$sdata);
		
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/asset.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/medical/Add_payment',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}


	public function MedicalPayment($id){
		$data = array();

		$data['id'] = $id;
			/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_pay_m_date';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = $id; 
		$data['PayDate'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		
		$data['AllPaymentData'] =  $this->Customer_model->Get_data_method('tb_medical');

		$data['AllAgentList'] =  $this->Setting_model->Get_data_method('tb_agent');
		$data['AllVendorData']  =  $this->Setting_model->Get_data_method('tb_vendor');
		$data['AllMedicalData'] =  $this->Setting_model->Get_data_method('tb_medical');
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/asset.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/medical/Add_payment.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}




//report section 
	public function MedicalReport(){
		$data = array();

		$data['AllAgentList'] =  $this->Setting_model->Get_data_method('tb_agent');

		$sdata=array(
			'agent_id' => $this->input->post('agent_id'), 
			);		
		$data['AgentAccount'] =  $this->Accounts_model->Get_data_by_search_key_model('tb_agent',$sdata);
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/medical/medical_report.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}//end

//DailyMedical Report serch 
	public function DailyMedicalReportSearch(){
		$data = array();

		$sdata=array(
			'created_at' => $this->input->post('created_at'), 
			'fromdate' => '',
			'todate' => '',
			);		
		$data['AllMedicalReport'] =  $this->Ticket_model->Get_data_Daily_report_by_search_key_model('tb_medical',$sdata);

		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/medical/daily_report.php',$sdata),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}//end
	

//All Agent ui Mehthod
	public function WMMedicalReportSearch(){
		$data = array();
		$sdata=array( 
			'fromdate' => date("m/d/Y", strtotime($this->input->post('fromdate'))), 
			'todate' => date("m/d/Y", strtotime($this->input->post('todate'))), 
			'created_at' => '',
			);		
		//var_dump($sdata);
		$data['AllMedicalReport'] =  $this->Ticket_model->Get_dataWeekly_Month_Date_search_key_model('tb_medical',$sdata);
		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		//file link
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/medical/daily_report.php',$sdata),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}//end

//===================================================================================|	
/*function add*/

	public function AddNewPayDate(){
		$data = array();
		$table = 'tb_pay_m_date';
		$data['m_pay_date'] = $this->input->post('m_pay_date');
		 $check = $this->Medical_model->CheckPayDateNoData($data['m_pay_date']);
		    if($check == false){
				$id = $this->Medical_model->Insert_id_data_model($table,$data);
				$mdata['sms'] = "<b style='color:green;'> Successfuly Save !</b>";
				$this->session->set_flashdata($mdata);
				redirect('Medical/MedicalPayment/'.$id);
			}else{

		    $mdata['sms'] = "<b style='color:red;'> <strong> This Date Is Already Been Taken .Please Use Another One Date!</strong> !</b>";
			$this->session->set_flashdata($mdata);
			redirect('MedicalPayDate');
			}
	}



	public function AddNewMedical(){
		$mpdata = array();
		$mptable 				 = 'tb_medical_passenger';
		$mpdata['fullname']	     = $this->input->post('fullname');
		$mpdata['passport_no']	 = $this->input->post('passport_no');
		$mpdata['m_c_name']	 	 = $this->input->post('m_c_name');
		$mpdata['phone']	 	 = $this->input->post('phone');
		$mpdata['address']	     = $this->input->post('address');
		$mpdata['remark']		 = $this->input->post('remark');
		$mpdata['agent_id']		 = $this->input->post('agent_id');
		$mpdata['vendor_id']	 = $this->input->post('vendor_id');
		$mpdata['created_at']	 = date('m/d/Y');

		$data = array();
		$table = 'tb_medical';
		$data['created_at'] = date('m/d/Y');
		$data['type'] 		= 'Medical';
		$data['agent_id']	= $this->input->post('agent_id');
		$data['vendor_id']	= $this->input->post('vendor_id');
		$data['v_rate']		= $this->input->post('v_rate');
		$data['a_rate']		= $this->input->post('a_rate');
		if (empty($mpdata['passport_no']) OR empty($data['v_rate'])OR empty($data['a_rate'])) {
			$mdata['sms'] = "<b style='color:red;'> Faild Save !  Check Customer & vendor rate Agent Rate</b>";
		}else{
 		  /*activity Details*/
			$ATable = 'tb_activity';
			$AData = array();
			$AData['activity_details'] = '<div class="alert alert-success"> Success :)Add Medical By &mdash; '.$this->session->fullname.'<span style="font-size:12px;">('.$this->session->user_id.')</span> </div>';
			$this->Setting_model->insert_data_model($ATable,$AData); //ACTIVITY UPDATED...
   		  /*activity details*/
			$mdata['sms'] = "<b style='color:green;'> Successfuly Save !</b>";
			$id = $this->Medical_model->Insert_id_data_model($mptable,$mpdata);
			$data['passenger_id'] = $id;
			$this->Setting_model->insert_data_model($table,$data);
		}
			$this->session->set_flashdata($mdata);
			redirect('Medical');
	}//addnewmedical 

	public function UpdateMedical(){
		$data = array();

		$table = 'tb_medical_passenger';
		$data['id']			 = $this->input->post('id');
		$data['fullname'] 	 = $this->input->post('fullname');
		$data['passport_no'] = $this->input->post('passport_no');
		$data['phone'] 	 	 = $this->input->post('phone');
		$data['address'] 	 = $this->input->post('address');
		$data['fullname'] 	 = $this->input->post('fullname');
		$data['m_c_name']	 = $this->input->post('m_c_name');
		$data['remark']		 = $this->input->post('remark');
		$data['m_rate']		 = $this->input->post('m_rate');

 		  /*activity Details*/
			$ATable = 'tb_activity';
			$AData = array();
			$AData['activity_details'] = '<div class="alert alert-success"> Success :)Add Medical By &mdash; '.$this->session->fullname.'<span style="font-size:12px;">('.$this->session->user_id.')</span> </div>';
			$this->Setting_model->insert_data_model($ATable,$AData); //ACTIVITY UPDATED...
   		  /*activity details*/
    
			$mdata['sms'] = "<b style='color:green;'> Successfuly Save !</b>";
			$this->Medical_model->UpdateCustomerData($table,$data);
			$this->session->set_flashdata($mdata);
			redirect('AllMedical');

	}



	public function RemoveMedical($id){
		$data=array();
		$table ='tb_medical_passenger';
		$data['match_by'] 	= $id;
		$data['match_col']  = 'id';
		$this->Setting_model->Get_remove_data_method($table,$data);
		
    	/*activity Details*/
		$ATable = 'tb_activity';
		$AData = array();
		$AData['activity_details'] = '<div class="alert alert-danger"> Success :)Medical Remove By &mdash; '.$this->session->fullname.'<span style="font-size:12px;"></span> </div>';
		$this->Setting_model->insert_data_model($ATable,$AData); //ACTIVITY UPDATED...
   		/*activity details*/
    
		$datas['smg'] = "<h4 style='color:red;'>Deleted Done !</h4>";
       	$this->session->set_flashdata($datas);
        redirect('AllMedical');
	}


/*Payment Add */
public function AddMedicalNewPay(){
		$data = array();
		$table 					= 'tb_medical';
		$data['pay_id'] 		= $this->input->post('pay_id');
		$id 					= $this->input->post('pay_id');
		$data['agent_id']	 	= $this->input->post('agent_id');
		$data['vendor_id'] 		= $this->input->post('vendor_id');
		$data['remark']		 	= $this->input->post('remark');
		$data['payment']		= $this->input->post('payment');
		$data['payment_method']	= $this->input->post('payment_method');
		$data['bank_name']		= $this->input->post('bank_name');
		$data['account_number']	= $this->input->post('account_number');
		$data['bkash_n']		= $this->input->post('bkash_n');
		$data['rocket_n']		= $this->input->post('rocket_n');
		$data['created_at']  	= date('m/d/Y');
		$data['type']  			= 'Payment';


		if(empty($data['payment'])){
			$mdata['sms'] = "<b style='color:red;'> Faild ! chcek Entry Type, Amount, Money Recipt</b>";
			$this->session->set_flashdata($mdata);
			redirect('Medical/MedicalPayment/'.$id);
		}else{

			$this->Setting_model->insert_data_model($table,$data);

	/*activity Details*/
		$ATable = 'tb_activity';
		$AData = array();
		$AData['activity_details'] = '<div class="alert alert-success"> Success :)Customer Payment By &mdash; '.$this->session->fullname.'<span style="font-size:12px;">('.$this->session->user_id.')</span> Customer Serial No &mdash;'.$serial_no.'</div>';
		$this->Setting_model->insert_data_model($ATable,$AData); //ACTIVITY UPDATED...
        /*activity details*/

			$mdata['sms'] = "<b style='color:orange;'> Successfuly Save !</b>";
			$this->session->set_flashdata($mdata);
			redirect('Medical/MedicalPayment/'.$id);

		}
	}

	public function RemoveMedicalpayment($id,$pay_id){
		$data=array();
		$table ='tb_medical';
		$data['match_by'] 	= $id;
		$data['match_col']  = 'id';
		$data['pay_id']  = $pay_id;
		$this->Setting_model->Get_remove_data_method($table,$data);
		
    	/*activity Details*/
		$ATable = 'tb_activity';
		$AData = array();
		$AData['activity_details'] = '<div class="alert alert-danger"> Success :)Medical Remove By &mdash; '.$this->session->fullname.'<span style="font-size:12px;"></span> </div>';
		$this->Setting_model->insert_data_model($ATable,$AData); //ACTIVITY UPDATED...
   		/*activity details*/
    
		$datas['smg'] = "<h4 style='color:red;'>Deleted Done !</h4>";
       	$this->session->set_flashdata($datas);
    redirect('Medical/MedicalPayment/'.$data['pay_id']);
	}


	public function medicalComplete($id){
		$table ='tb_medical_passenger';
		$data['match_by'] 	= $id;
		$data['match_col']  = 'id';
		$data['status'] 	= 1;
		$this->Medical_model->MedicalPaymentId($table,$data);	

		/*activity Details*/
		$ATable = 'tb_activity';
		$AData = array();
		$AData['activity_details'] = '<div class="alert alert-info"> Success :)Medical Payment Paid By &mdash; '.$this->session->fullname.'<span style="font-size:12px;"></span> </div>';
		$this->Setting_model->insert_data_model($ATable,$AData); //ACTIVITY UPDATED...
   		/*activity details*/

		$datas['smg'] = "<h4 style='color:red;'>Deleted Done !</h4>";
       	$this->session->set_flashdata($datas);
        redirect('MedicalPayment');

	}

}


