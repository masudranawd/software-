<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	public function __construct(){
		parent:: __construct();
		
		$this->load->model('Customer_model');
		$this->load->model('Accounts_model');
		$this->load->model('Setting_model');
		$this->load->model('Agent_model');
		$this->load->model('User_model');

		$login_user = $this->session->userdata('user_id'); 
		if(isset($login_user)){
			$login_user; 
		}else{
			
			redirect('User/'); 
		} 
	}

	public function index()
	{
		$this->Homepage();
	}

	public function Homepage(){
		$data = array();

		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		
		$data['TotalVendor'] = $this->Setting_model->CountAll('tb_vendor');//total 
		$data['TotalAgent'] = $this->Setting_model->CountAll('tb_agent');//total 
		$data['TotalUser'] = $this->Setting_model->CountAll('tb_user');//total 
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		//ui link 
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/dashboard/dashboard.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}
//Activity ui method
	public function Activity(){
		$data = array();

		$data['pData'] = $this->User_model->GetUserById(array('uid'=>$this->session->id));
		$data['AllActivityData'] = $this->Setting_model->Get_data_method('tb_activity');
		/*----------------setting------------------*/	
		$siteData = array();	
		$sitetable = 'tb_setting';
		$siteData['match_col'] = 'id';
		$siteData['match_by'] = 1; 
		$data['SiteData'] = $this->Setting_model->Get_Date_ById_method($sitetable,$siteData);
		/*----------------setting------------------*/	
		//ui link 
		$data = array(
			'Left ment' => $this->load->view('inc/left_menu.php',$data),
			'Header' 	=> $this->load->view('inc/header.php',$data),
			'Main File' => $this->load->view('template/dashboard/activity.php',$data),
			'Footer' 	=> $this->load->view('inc/footer.php',$data)
		);
		$this->load->view('index',$data);
	}
}
