
            <!-- page content -->
            <div class="right_col" role="main">
                <div class="">
                    <!--<div class="page-title">
                        <div class="title_left">
                            <h3>Form Validation</h3>
                        </div>

                        <div class="title_right">
                            <div class="col-md-5 col-sm-5 form-group pull-right top_search">
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search for...">
                                    <span class="input-group-btn">
                                        <button class="btn btn-default" type="button">Go!</button>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>-->
                    <div class="clearfix"></div>

                    <div class="row">
                        <div class="col-md-12 col-sm-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>New Customer<small>ADD</small></h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                        </li>
                                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>

 <?php  
  if(empty($AgentId->id)){
    $agent_id = 'AG';
  }else{
    $agent_id = 'AG'.sprintf("%d",$AgentId->id+1);
  }
?>    
                                <div class="x_content">
                            <?php echo form_open_multipart('Agent/AddNewAgent');?>
                                      <div class="row">
                                        <div class="col-md-6">
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align" style="color:red;">Customer id<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" data-validate-length-range="6" data-validate-words="2" name="agent_id" value="<?php echo $agent_id;?>" />
                                              </div>
                                          </div>
                                        </div>
                                        <div class="col-md-6">
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align" style="color:red;">Customer Name<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" data-validate-length-range="6" data-validate-words="2" name="agent_name"  />
                                              </div>
                                          </div>
                                        </div>
                                        <div class="col-md-6">
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Campany Name<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" data-validate-length-range="6" data-validate-words="2" name="company_name"  />
                                              </div>
                                          </div>
                                        </div>


                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align" style="color:red;">Contact No.<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" class='optional' name="mobile_no"  type="text"    />
                                                </div>
                                          </div>
                                        </div><!--end--->

                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Gender <span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                <select class="form-control"  name="gender" >
                                                  <option value="male"> Male</option>
                                                  <option value="female">Female</option>
                                                </select>
                                                </div>
                                          </div>
                                        </div><!--end--->


                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Address <span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                <textarea class="form-control" rows="1.5" name="address"></textarea>
                                              </div>
                                          </div>
                                        </div><!--end--->

                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Customer Profile  <span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" class='optional' name="agent_image"  type="file"  />
                                              </div>
                                          </div>
                                        </div><!--end--->

                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Customer Details <span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                <textarea class="form-control" rows="2" name="agent_details"></textarea>
                                              </div>
                                          </div>
                                        </div><!--end--->  
                                         <div class="col-md-6"><!--start--->
                                            <?php echo $this->session->flashdata('smg');?>
                                          </div>
                                        </div><!--end--->

                                      </div><!---ROW END-->
                            
                     
                                        <div class="">
                                            <div class="form-group">
                                                <div class="col-md-6 offset-md-3">
                                                    <button type='submit' class="btn btn-primary">Save</button>
                                                    <button type='reset' class="btn btn-success">Cancel</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div><!--end col-md-12--->


                </div>
                    </div>
                </div>
            </div>
            <!-- /page content -->
<!--- model start---->