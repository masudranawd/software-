
            <!-- page content -->
            <div class="right_col" role="main">
                <div class="">
                    <div class="clearfix"></div>
                       <?php echo $this->session->flashdata('smg');?>
                    <div class="row">
                        <div class="col-md-12 col-sm-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>Customer Ticket<small>Report</small></h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                        </li>
                                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content">
                         <form class="" action="<?php echo base_url('Agent/AgentReportDateMonth');?>" method="post" novalidate target="_blank">
                                      <div class="row">
                                        <div class="col-md-4">
                                          <div class="field item form-group" style="margin-top: -10px;">
                                                 <select class="chosent form-control" name="agent_id"  required="required" >
                                                    <option>Select Customer </option> 
                                                  <?php 
                                                    foreach ($AllAgentList as $AgentList) {
                                                  ?>
                                                    <option value="<?php echo $AgentList->id;?>">
                                                      <?php echo $AgentList->agent_name;?> / <?php echo $AgentList->company_name;?> / <?php echo $AgentList->agent_id;?> / <?php echo $AgentList->agent_id;?> / <?php echo $AgentList->mobile_no;?>
                                                      </option>
                                                  <?php
                                                      }  
                                                  ?>
                                                  </select>
                                              <script type="text/javascript">$(".chosent").chosen(); </script>
                                            </div>
                                        </div>      

                                        <label class="col-form-label col-md-1 col-sm-3  label-align">From Date<span class="required">*</span></label>
                                        <div class="col-md-3 ">
                                            <input type="date" class="form-control has-feedback-left" id="" name="fromdate">
                                        </div>


                                        <label class="col-form-label col-md-1 col-sm-3  label-align">To Date<span class="required">*</span></label>
                                        <div class="col-md-3 ">
                                            <input type="date" class="form-control has-feedback-left"  name="todate">
                                        </div>
                                </div>
                                <div class="row">
                                  <div class="col-md-10"></div>
                                    <div class="col-md-2 col-sm-6">
                                        <div class="form-group">
                                            <div class="col-md-2 offset-md-3">
                                              <button type='submit' class="btn btn-info sourc" >Submit</button>
                                            </div>
                                         </div>     
                                    </div>
                                </div>
                                    </form>
                                </div>
                            </div>
                        </div>



                        <div class="col-md-12 col-sm-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>Customer Medical <small>Report</small></h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                        </li>
                                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content">
        <form class="" action="<?php echo base_url('Agent/AgentReportMedicalDateMonth');?>" method="post" novalidate target="_blank">
                                      <div class="row">
                                        <div class="col-md-4">
                                          <div class="field item form-group" style="margin-top: -10px;">
                                                 <select class="chosent form-control" name="agent_id"  required="required" >
                                                    <option>Select Customer </option> 
                                                  <?php 
                                                    foreach ($AllAgentList as $AgentList) {
                                                  ?>
                                                    <option value="<?php echo $AgentList->id;?>">
                                                      <?php echo $AgentList->agent_name;?> / <?php echo $AgentList->company_name;?> / <?php echo $AgentList->agent_id;?> / <?php echo $AgentList->agent_id;?> / <?php echo $AgentList->mobile_no;?>
                                                      </option>
                                                  <?php
                                                      }  
                                                  ?>
                                                  </select>
                                              <script type="text/javascript">$(".chosent").chosen(); </script>
                                            </div>
                                        </div>      

                                        <label class="col-form-label col-md-1 col-sm-3  label-align">From Date<span class="required">*</span></label>
                                        <div class="col-md-3 ">
                                            <input type="date" class="form-control has-feedback-left" id="" name="fromdate">
                                        </div>


                                        <label class="col-form-label col-md-1 col-sm-3  label-align">To Date<span class="required">*</span></label>
                                        <div class="col-md-3 ">
                                            <input type="date" class="form-control has-feedback-left"  name="todate">
                                        </div>
                                </div>
                                <div class="row">
                                  <div class="col-md-10"></div>
                                    <div class="col-md-2 col-sm-6">
                                        <div class="form-group">
                                            <div class="col-md-2 offset-md-3">
                                              <button type='submit' class="btn btn-info sourc" >Submit</button>
                                            </div>
                                         </div>     
                                    </div>
                                </div>
                                    </form>
                                </div>
                            </div>
                        </div>
      </div><!-- end row---->
 
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                  <div class="x_content">
                      <div class="row">
                          <div class="col-sm-12">
                            <div class="card-box table-responsive">
                    <table id="datatable-buttons" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                          <tr class="headings">
                            <th class="column-title" style="display: table-cell;">Customer Id </th>
                            <th class="column-title" style="display: table-cell;">Customer Name</th>
                            <th class="column-title" style="display: table-cell;">Phone </th>
                            <th class="column-title" style="display: table-cell;">Ticket Due Amount </th>
                            <th class="column-title" style="display: table-cell;">Medical Due Amount </th>
                          </tr>
                      </thead>


                      <tbody>
<?php 
    foreach ($AllAgentList as $agentData) {
?>
                     <?php 
                             $VendorPayTicketList = $this->Agent_model->GetAgentTicketPayData($agentData->id);
                               $billTotal =0;
                               $payTotal =0;
                              $duepayment = 0;
                              foreach ($VendorPayTicketList as $VendorPayTicketData) {
                                  $billTotal = (int)$billTotal + (int)$VendorPayTicketData->agent_bill;
                                  $payTotal = (int)$payTotal + (int)$VendorPayTicketData->payment_amount;
                                 $duepayment = (int)$billTotal - (int)$payTotal;
                          ?>
                          <?php   }?>
 <tr class="even pointer">
                            <td class=""><?php echo $agentData->agent_id;?></td>
                            <td class=" "><?php echo $agentData->agent_name;?></td>
                            <td class=" "><?php echo $agentData->mobile_no;?></td>
                            <td class=" ">
                                <?php echo $duepayment; ?>
                            </td>
                            <td>
                            <?php 
                            $agentPayMedicalList = $this->Agent_model->GetAgentMedicalPayData($agentData->id);
                               $rateTotal =0;
                               $payrateTotal =0;
                                $medicalpayment =0;
                              foreach ($agentPayMedicalList as $AgentPayMedicalData) {
                                  $rateTotal = (int)$rateTotal + (int)$AgentPayMedicalData->v_rate;
                                  $payrateTotal = (int)$payrateTotal + (int)$AgentPayMedicalData->payment;
                                 $medicalpayment = (int)$rateTotal - (int)$payrateTotal;
                          ?>
                          <?php   }?>
                            <?php echo $medicalpayment;?>
                            </td>
                            </td>
                          </tr>



<?php
    }
?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
                </div>
              </div>

            </div><!--end row-->
          </div>
        </div>
        <!-- /page content -->
