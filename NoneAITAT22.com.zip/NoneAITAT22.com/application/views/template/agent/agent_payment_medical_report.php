    <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Customer Medical Report</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="#">Settings 1</a>
                            <a class="dropdown-item" href="#">Settings 2</a>
                          </div>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      <div class="row">
                          <div class="col-sm-12">
                            <div class="card-box table-responsive"  id="printMe">


                          <table style="width:80%;height:100%;margin:0px auto;margin-top: 20px;">
                                <tr><br><br>
                                   <th style="text-align: center;width:10%;">
                                       <img src="<?php echo base_url();?>images/<?php echo $SiteData->logo;?>" alt="" style="height:100px;width:100px;">
                                    </th>
                                    <th style="width:40%;text-align: left;">
                                    <h6 style="color:#000;font-weight: bold;"><?php echo $SiteData->name;?></h6>
                                    <h6 style="color:#000;font-weight: bold;"><?php echo $SiteData->address;?></h6>
                                    <h6 style="color:#000;font-weight: bold;">E-mail:<?php echo $SiteData->email;?></h6>
                                    <h6 style="color:#000;font-weight: bold;">Phone: <?php echo $SiteData->phone;?></h6>
                               </th>
                               <th style="width: 25%"></th>
                               <th style="width:25%;text-align: left;">
                                    <h6 style="color:#000;font-weight: bold;">Customer Medical Ledger </h6>
                                  <address style="color:#000;">
                                       <strong>
                                        <?php 
                             $AgentName = $this->Customer_model->AgentNameById($agent_id);
                              echo 'Agent Name: '. $AgentName->agent_name.'<br>';
                              echo 'Phone: '. $AgentName->mobile_no.'<br>';
                            ?>
                              <?php if($fromdate){echo  'From date :'.$fromdate; }else{ echo '';} ?><br><?php if($todate){echo  'To date :'.$todate; }else{ echo '';} ?>

                                      </address>
                                  </th>
                                    </tr>
                              </table>

                  
                    <table  class="table_border " style="width:90%;border-collapse: collapse;margin:0px auto;" >
                      <thead>
                        <tr>
                          <th>Sl</th>
                          <th>Type</th>
                          <th>Details</th>
                          <th>Rate Amount</th>
                          <th>Payment Amount</th>
                        </tr>
                      </thead>

                      <tbody>
                      <?php
                          $sl=0;
                          $billTotal = 0;
                          $payTotal = 0;
                        foreach ($AgentMedicalList as $MedicalPayData) {
                          $sl++;
                          $billTotal = (int)$billTotal+(int)$MedicalPayData->a_rate;
                          $payTotal = (int)$payTotal+(int)$MedicalPayData->payment;
                      ?>   <tr>
                          <td style="width: 3%;text-align:center;"><?php echo $sl;?></td>
                          <td style="width: 8%;text-align:center;"><?php echo $MedicalPayData->type;?></td>
                          <?php 
                              if ($MedicalPayData->type == 'Medical') {
                           ?>

                          <td style="width: 50%;">

                        <?php $PassengerData = $this->Vendor_model->MPassengerDataGetById($MedicalPayData->passenger_id); ?> 
                            <b>Passenger Name :</b>
                            <?php echo $PassengerData->fullname; ?>
                            <b>P.P</b><?php echo $PassengerData->passport_no;?>
                            <b>M Name</b><?php echo $PassengerData->m_c_name;?>
                            <br>
                            <?php if ($MedicalPayData->remark) {echo '<b>Remark:</b>'.$MedicalPayData->remark;}else{ echo '';} ?>

                          </td>

                           <?php
                              }else{
                          ?>
                          <td>

                           
<b>Date :</b> <?php echo date('dS M Y', strtotime($MedicalPayData->payment_date));?>,<b> Payment Method :</b> <?php echo $MedicalPayData->payment_method;?>,
<?php 
    if ($MedicalPayData->bank_name) {echo '<b>Bank Name:</b>'.$MedicalPayData->bank_name; echo '<b> Account Number : </b>'.$MedicalPayData->account_number;}elseif ($MedicalPayData->bkash_n) {echo  '<b>Bkash Number : </b>'. $MedicalPayData->bkash_n;}elseif ($MedicalPayData->rocket_n) {echo  '<b>Rocket Number : </b>'.$MedicalPayData->rocket_n;}elseif ($MedicalPayData->nogod_n) {echo  '<b>Nogod Number : </b>'. $MedicalPayData->nogod_n;}
?>
                       
                            

                          </td> 
                          <?php
                              }
                          ?>

                          <td style="text-align: right;width:10%;" ><?php echo $MedicalPayData->a_rate;?></td>
                          <td style="text-align: right;width:8%;"><?php echo $MedicalPayData->payment;?></td> 
                        </tr>
                      <?php
                      }
                      ?>
                        <tr>
                          <td colspan="4" style="text-align: right;color:#000;font-weight: bold;">Total Bill = <?php echo $billTotal;?></td>
                          <td style="color:#000;font-weight: bold; text-align: right;width:11%;">Total Payment =<?php echo $payTotal;?></td>
                        </tr>
                        <tr>
                          <td colspan="5" style="color:#000;font-weight: bold; text-align: right;">Total Due =<?php echo (int)$billTotal -(int)$payTotal;?></td>
                        </tr>

                      </tbody>
                    </table>

                  </div>
                </div>
                      <div class="row no-print">
                        <div class=" ">
                          <button class="btn btn-default" onclick="printDiv('printMe')"><i class="fa fa-print"></i> Print</button>
                        </div>
                      </div>
              </div>
            </div>
                </div>
              </div>

            </div><!--end row-->
          </div>
        </div>
        <!-- /page content -->


        <script>
    function printDiv(divName){
        var printContents = document.getElementById(divName).innerHTML;
        var originalContents = document.body.innerHTML;
        document.body.innerHTML = printContents;
        window.print();
        document.body.innerHTML = originalContents;
    }   
  </script>