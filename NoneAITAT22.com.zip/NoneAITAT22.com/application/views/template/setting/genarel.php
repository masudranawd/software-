
            <!-- page content -->
            <div class="right_col" role="main">
                <div class="">
                    <!--<div class="page-title">
                        <div class="title_left">
                            <h3>Form Validation</h3>
                        </div>

                        <div class="title_right">
                            <div class="col-md-5 col-sm-5 form-group pull-right top_search">
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search for...">
                                    <span class="input-group-btn">
                                        <button class="btn btn-default" type="button">Go!</button>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>-->
                    <div class="clearfix"></div>

                    <div class="row">
                        <div class="col-md-12 col-sm-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>Genarel Setting</h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                        </li>
                                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content">
                                    <?php echo form_open_multipart('Setting/GeneralUpdate/');?>
                                      <div class="row">
                                          <input class="form-control" type="hidden" name="id" value="<?php echo $SiteData->id;?>"/>
                                          <input class="form-control" type="hidden" name="old_image" value="<?php echo $SiteData->logo;?>"/>
                                        <div class="col-md-6">
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Name<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" name="name" value="<?php echo $SiteData->name;?>"/>
                                              </div>
                                          </div>
                                        </div>
                                        <div class="col-md-6">
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Title<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" name="title" value="<?php echo $SiteData->title;?>"/>
                                              </div>
                                          </div>
                                          </div>
                                        <div class="col-md-6">
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Phone<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" name="phone" value="<?php echo $SiteData->phone;?>"/>
                                              </div>
                                          </div>
                                          </div>
                                        <div class="col-md-6">
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Email<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" name="email" value="<?php echo $SiteData->email;?>"/>
                                              </div>
                                          </div>
                                        </div>


                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Address <span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                <textarea class="form-control" rows="1.5" name="address" rows="4" cols="50"><?php echo $SiteData->address;?></textarea>
                                              </div>
                                          </div>
                                        </div><!--end--->

                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Logo <span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" class='optional' name="logo"  type="file"  />
                                                  <img src="<?php echo base_url();?>images/<?php echo $SiteData->logo;?>" style="width:100%;">
                                              </div>
                                          </div>
                                        </div><!--end--->
                                      </div><!---ROW END-->
                            
                     
                                        <div class="ln_solid">
                                            <div class="form-group">
                                                <div class="col-md-6 offset-md-3">
                                                    <button type='submit' class="btn btn-primary">Save</button>
                                                    <button type='reset' class="btn btn-success">Cancel</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div><!--end col-md-12--->
                    </div>
                </div>
            </div>
            <!-- /page content -->
<!--- model start---->
<!-- Modal profile view-->
<div class="modal fade" id="profile" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="myModalLabel">Profile view</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body">

      </div>
    </div>
  </div>
</div>
<!-- Modal Profile Edit-->
<div class="modal fade" id="editprofile" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="myModalLabel">Profile Edit</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body">
        <form class="" action="" method="post" novalidate>
                                     
          <div class="field item form-group">
            <label class="col-form-label col-md-2 col-sm-3  label-align">Agent_id<span class="required">*</span></label>
            <div class="col-md-10 col-sm-6">
                <input class="form-control" data-validate-length-range="6" data-validate-words="2" name="agent_id" required="required" />
            </div>
         </div>
                                       
                                     
            <div class="field item form-group">
                <label class="col-form-label col-md-2 col-sm-3  label-align">User Name<span class="required">*</span></label>
                <div class="col-md-10 col-sm-6">
                   <input class="form-control" data-validate-length-range="6" data-validate-words="2" name="agent_name" required="required" />
                </div>
           </div>
                                  
           <!--start--->
          <div class="field item form-group">
             <label class="col-form-label col-md-2 col-sm-3  label-align">Contact No.<span class="required">*</span></label>
              <div class="col-md-10 col-sm-6">
                 <input class="form-control" class='optional' name="contact_number"  type="text"  required="required"  />
              </div>
          </div>
          <!--end--->

        <!--start--->
          <div class="field item form-group">
             <label class="col-form-label col-md-2 col-sm-3  label-align">Gender <span class="required">*</span></label>
            <div class="col-md-10 col-sm-6">
              <div id="gender" class="btn-group" data-toggle="buttons">
                <label class="btn btn-primary" data-toggle-class="btn-primary" data-toggle-passive-class="btn-secondary">
                   <input type="radio" name="gender" value="male" class="join-btn"> &nbsp; Male &nbsp;
                </label>
                <label class="btn btn-secondary active" data-toggle-class="btn-primary" data-toggle-passive-class="btn-secondary">
                  <input type="radio" name="gender" value="female" class="join-btn"> Female
                </label>
               </div>
            </div>
          </div>
         <!--end--->
         
         <!--start--->
            <div class="field item form-group">
                <label class="col-form-label col-md-2 col-sm-3  label-align">Address <span class="required">*</span></label>
                 <div class="col-md-10 col-sm-6">
                    <textarea class="form-control" rows="1.5" name="address"></textarea>
                  </div>
            </div>

          <div class="field item form-group">
             <label class="col-form-label col-md-2 col-sm-3  label-align">Customer Profile  <span class="required">*</span></label>
            <div class="col-md-10 col-sm-6">
              <input class="form-control" class='optional' name="kapil_no"  type="file"  />
            </div>
          </div>
          <div class="ln_solid">
            <div class="form-group">
               <div class="col-md-6 offset-md-3">
                   <button type='submit' class="btn btn-primary">Save</button>
                    <button type='reset' class="btn btn-success">Cancel</button>
                 </div>
            </div>
          </div>
         </form>
      </div>
    </div>
  </div>
</div>
<!--- model end ----->
