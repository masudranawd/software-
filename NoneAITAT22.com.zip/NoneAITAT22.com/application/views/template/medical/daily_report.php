    <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="clearfix"></div>
    <h2><?php echo $this->session->flashdata('smgdu');?></h2>
            <div class="row">
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Medical Payment Report</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="#">Settings 1</a>
                            <a class="dropdown-item" href="#">Settings 2</a>
                          </div>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      <div class="row">
                          <div class="col-sm-12">
                            <div class="card-box table-responsive"  id="printMe" >
                                
                             <table style="width:80%;height:100%;margin:0px auto;margin-top: 20px;">
                                <tr><br><br>
                                   <th style="text-align: center;width:10%;">
                                       <img src="<?php echo base_url();?>images/<?php echo $SiteData->logo;?>" alt="" style="height:100px;width:100px;">
                                    </th>
                                    <th style="width:40%;text-align: left;">
                                    <h6 style="color:#000;font-weight: bold;"><?php echo $SiteData->name;?></h6>
                                    <h6 style="color:#000;font-weight: bold;"><?php echo $SiteData->address;?></h6>
                                    <h6 style="color:#000;font-weight: bold;">E-mail:<?php echo $SiteData->email;?></h6>
                                    <h6 style="color:#000;font-weight: bold;">Phone: <?php echo $SiteData->phone;?></h6>
                               </th>
                               <th style="width: 25%"></th>
                               <th style="width:25%;text-align: left;">
                                    <h6 style="color:#000;font-weight: bold;"> Medical Payment Report</h6>
                                  <address style="color:#000;">
                                       <strong>
                                    <h4 style="color:#000;"><?php if ($created_at){ echo 'Date:'.$created_at;}else{echo '';}?></h4>
                                    <h4 style="color:#000;"><?php if ($fromdate){ echo 'From Date:'.$fromdate;}else{echo '';}?> - <?php if ($todate){ echo 'To Date:'.$todate;}else{echo '';}?> </h4>

                                      </address>
                                  </th>
                                    </tr>
                              </table>

                    <table  class="table_border" style="width:90%;height:100%;margin:0px auto;">
                   
                      <thead>
                        <tr>
                          <th> Id</th>
                          <th>Customer Name</th>
                          <th>Descriptions </th>
                          <th>Bill Amount</th>
                        </tr>
                      </thead>


                      <tbody>
                      <?php
                          $sl=0;
                          $paymenttotal = 0; 
                        foreach ($AllMedicalReport as $MedicalData) {  
                          if ($MedicalData->type == 'Payment') {
                            
                            $paymenttotal = (int)$paymenttotal+(int)$MedicalData->payment;
                             $sl++;
                        
                      ?>
                        <tr>
                          <td><?php echo $sl;?></td>
                          <td>   
                            <?php
                              if ($MedicalData->vendor_id == !null) {

                              $vendorname = $this->Medical_model->Vendor_info_for_invoice($MedicalData->vendor_id);
                               echo $vendorname->vendor_name;
                             
                              }else{

                                 $Agentname = $this->Medical_model->Agent_info_for_invoice($MedicalData->agent_id);
                               echo $Agentname->agent_name;

                              }?>
                          </td>
                        
                          <?php 
                           ?>

                          <td style="width: 55%;">
                            <?php if ($MedicalData->payment_method  == 'CashIn') {?>
                                <?php echo $MedicalData->payment_method;?>
                            <?php }elseif($MedicalData->payment_method  == 'Bank'){?> 
     <?php echo $MedicalData->payment_method;?>     <?php echo $MedicalData->bank_name;?> <?php echo $MedicalData->account_number;?>
                            <?php }elseif($MedicalData->payment_method  == 'Bkash'){?> 
     <?php echo $MedicalData->payment_method;?>     <?php echo $MedicalData->bkash_n;?>
                            <?php }elseif($MedicalData->payment_method  == 'Rocket'){?> 
     <?php echo $MedicalData->payment_method;?>     <?php echo $MedicalData->rocket_n;?>
                            <?php }elseif($MedicalData->payment_method  == 'Nogod'){?> 
     <?php echo $MedicalData->payment_method;?>     <?php echo $MedicalData->nogod_n;?>
                            <?php } ?>
                          </td>
                          <td style="text-align: right;"><?php echo $MedicalData->payment;?></td>
                        </tr>

                      <?php
                        }
                      }
                      ?>
                    </tbody>
                      <tbody>
                      <tr>
                        
                          <th style="color:#fff;"></th>
                          <th style="color:#fff;"></th>
                          <th style="color:#fff;"></th>
                          <th style="text-align: right;">Total Cash In =<?php  if($paymenttotal){ echo  $paymenttotal;}else{ echo '0';}?></th>
                      </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
                  <div class="row no-print">
                      <div class=" ">
                        <button class="btn btn-default" onclick="printDiv('printMe')"><i class="fa fa-print"></i> Print</button>
                      </div>
                  </div>
              </div>
            </div>
                </div>
              </div>

            </div><!--end row-->
          </div>
        </div>
        <!-- /page content -->

        <script>
    function printDiv(divName){
        var printContents = document.getElementById(divName).innerHTML;
        var originalContents = document.body.innerHTML;
        document.body.innerHTML = printContents;
        window.print();
        document.body.innerHTML = originalContents;
    }   
  </script>