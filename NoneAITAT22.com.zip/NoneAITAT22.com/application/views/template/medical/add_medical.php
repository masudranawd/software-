
            <!-- page content -->
            <div class="right_col" role="main">
                <div class="">
                    <div class="clearfix"></div>

                    <div class="row">
                        <div class="col-md-12 col-sm-12">
                          <div class="">
                            <a  href="<?php echo base_url('')?>Medical" type="button" class="btn btn-round btn-primary"> New Medical </a>
                          </div><br>
                            <div class="x_panel" style="background-color: #eee;">
                                <div class="x_title">
                                    <h2>Add Medical <small><?php echo $this->session->flashdata('sms');?></small></h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                        </li>
                                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content">
                                      <form action="<?php echo base_url('Medical/AddNewMedical');?>" method="post">
                                      <div class="row">
                    
                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align" style="color:red;">
                                            Vendor Select  <span class="required">*</span>
                                              </label>
                                              <div class="col-md-10 col-sm-6">
                                                 <select class="chosent form-control" name="vendor_id" required="">
                                                    <option value="" >Select Vendor</option> 
                                                  <?php 
                                                    foreach ($AllVendorData as $VendorData) {
                                                  ?>
                                                    <option value="<?php echo $VendorData->id;?>"  style="font-size: 16px;"><?php echo $VendorData->vendor_name;?>/<?php echo $VendorData->vendor_id;?>/<?php echo $VendorData->company_name;?>/<?php echo $VendorData->phone;?></option>
                                                  <?php
                                                      }  
                                                  ?>
                                                  </select>
                                      <script type="text/javascript">$(".chosent").chosen(); </script>
                                              </div>
                                          </div>
                                        </div><!--end--->



                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align" style="color:red;">
                                              Customer  <span class="required">*</span>
                                              </label>
                                              <div class="col-md-10 col-sm-6">
                                                 <select class="chosent form-control" name="agent_id" required="">
                                                    <option value="" >Select Customer</option> 
                                                 <?php 
                                                    foreach ($AllAgentList as $AgentData) {
                                                  ?>
                                                    <option value="<?php echo $AgentData->id;?>" style="font-size: 16px;"><?php echo $AgentData->agent_name;?>/<?php echo $AgentData->agent_id;?>/<?php echo $AgentData->mobile_no;?></option>
                                                  <?php
                                                      }  
                                                  ?>
                                                  </select>
                                      <script type="text/javascript">$(".chosent").chosen(); </script>
                                              </div>
                                          </div>
                                        </div><!--end--->

                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Passenger Name<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" class='optional' name="fullname"  type="text"   />
                                                </div>
                                          </div>
                                        </div><!--end--->  

                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Passport No<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" class='optional' name="passport_no"  type="text"   />
                                                </div>
                                          </div>
                                        </div><!--end--->  

                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Medical Name<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" class='optional' name="m_c_name"  type="text"   />
                                                </div>
                                          </div>
                                        </div><!--end--->     

                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Phone<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" class='optional' name="phone"  type="text"   />
                                                </div>
                                          </div>
                                        </div><!--end--->

                                         <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Address<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" class='optional' name="address"  type="text"   />
                                                </div>
                                          </div>
                                        </div><!--end--->
                                  
                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Remark<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" class='optional' name="remark"  type="text"   />
                                                </div>
                                          </div>
                                        </div><!--end--->
                                         
                                         <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align"  style="color:red">Vendor Rate <span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" class='optional' name="v_rate"  type="number"  required="required" />
                                                </div>
                                          </div>
                                        </div><!--end--->    

                                         <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align"  style="color:red"> Customer Rate <span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" class='optional' name="a_rate"  type="number"  required="required" />
                                                </div>
                                          </div>
                                        </div><!--end--->

                                      </div><!---ROW END-->
                            
                     
                                        <div class="ln_solid">
                                            <div class="form-group">
                                                <div class="col-md-6 offset-md-3">
                                                    <button type="submit" class="btn btn-info">Save</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <!-- /page content -->