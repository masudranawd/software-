    <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="clearfix"></div>
    <h2><?php echo $this->session->flashdata('smgdu');?></h2>
            <div class="row">
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>All Medical Customer Payment Paid List</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="#">Settings 1</a>
                            <a class="dropdown-item" href="#">Settings 2</a>
                          </div>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      <div class="row">
                          <div class="col-sm-12">
                            <div class="card-box table-responsive">
                    <table id="datatable-buttons" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                        <tr>
                          <th> Id</th>
                          <th>Customer Name</th>
                          <th>Passport No</th>
                          <th>Medical Center</th>
                          <th>Phone</th>
                          <th>Address</th>
                          <th>Remark</th>
                          <th>Rate</th>
                          <th>Action</th>
                        </tr>
                      </thead>


                      <tbody>
                      <?php
                          $sl=0;
                          $total =0;
                        foreach ($AllPassengerList as $PassengerData) {
                            if($PassengerData->status == '1'){
                          $sl++;
                      ?>

                        <tr>
                          <td><?php echo $sl;?></td>
                          <td><?php echo $PassengerData->fullname;?></td>
                          <td><?php  echo $PassengerData->passport_no;?></td>

                          <td style="text-align: center;">
                            <?php echo $PassengerData->m_c_name;?>
                          </td>

                          <td style="text-align: center;">
                            <?php echo $PassengerData->phone;?>
                          </td>

                          <td style="text-align: center;">
                            <?php echo $PassengerData->address;?>
                          </td>

                          <td style="text-align: right;"><?php echo $PassengerData->remark;?></td>
                          <td style="text-align: right;"><?php echo $PassengerData->m_rate;?></td>
                          <td style="text-align: center;">
                         <a href="" class="btn btn-round btn-warning btn-xs">Paid</a>
                          </td>
                        </tr>

                      <?php
                        }
                      }
                      ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
                </div>
              </div>

            </div><!--end row-->
          </div>
        </div>
        <!-- /page content --> 