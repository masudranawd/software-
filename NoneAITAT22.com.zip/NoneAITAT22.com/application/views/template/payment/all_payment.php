    <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="clearfix"></div>
    <h2><?php echo $this->session->flashdata('smgdu');?></h2>
            <div class="row">
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>All Payment List </h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="#">Settings 1</a>
                            <a class="dropdown-item" href="#">Settings 2</a>
                          </div>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      <div class="row">
                          <div class="col-sm-12">
                            <div class="card-box table-responsive">
                    <table id="datatable-buttons" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                          <tr class="headings">
                            <th class="column-title" style="display: table-cell;">Date</th>
                            <th class="column-title" style="display: table-cell;">Name</th>
                            <th class="column-title" style="display: table-cell;">Type</th>
                            <th class="column-title" style="display: table-cell;">Method</th>
                            <th class="column-title" style="display: table-cell;">payment </th>
                            <th class="column-title" style="display: table-cell;">action </th>
                          </tr>
                      </thead>


                      <tbody>
<?php 
    foreach ($AllPaymentData as $PaymentData) {
      if ($PaymentData->type == 'Payment') {
?>
 <tr class="even pointer">
                            <td class=""><?php echo $PaymentData->payment_date;?></td>

                          <td><?php 
                            if ($PaymentData->vendor_id) {
                            ?>

                            <?php 
                              $vendorname = $this->Payment_model->vendor_info_for_invoice($PaymentData->vendor_id);
                                echo $vendorname->vendor_name;
                             ?>

                            <?php
                            }else{
                            ?>
                            <?php 
                              $AgentName = $this->Payment_model->Agent_info_for_invoice($PaymentData->agent_id);
                                echo $AgentName->agent_name;
                             ?>

                            <?php
                            } ?></td>
                            <td class=""><?php echo $PaymentData->type;?></td>
                            <td class=" "><?php echo $PaymentData->payment_method;?>&nbsp;
                              <?php 
                                    if ($PaymentData->bank_name) {echo '<b>Bank Name:</b>'.$PaymentData->bank_name; echo '<b> Account Number : </b>'.$PaymentData->account_number;}elseif ($PaymentData->bkash_n) {echo  '<b>Bkash Number : </b>'. $PaymentData->bkash_n;}elseif ($PaymentData->rocket_n) {echo  '<b>Rocket Number : </b>'.$PaymentData->rocket_n;}elseif ($PaymentData->nogod_n) {echo  '<b>Nogod Number : </b>'. $PaymentData->nogod_n;}
                              ?>
                            </td>
                            <td class=" "><?php echo $PaymentData->payment_amount;?>

                            </td>
                            <td class="last">
                              <?php if($pData->types =='Admin'){?>
                              <a href="<?php echo base_url('Payment/removePayment/');?><?php echo $PaymentData->id;?>" class="btn btn-round btn-danger">D</a>
                              <?php }?>
                            </td>
                            </td>
                          </tr>
<?php
    }
    
      }
?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
                </div>
              </div>

            </div><!--end row-->
          </div>
        </div>
        <!-- /page content -->