
            <!-- page content -->
            <div class="right_col" role="main">
                <div class="">
                    <div class="clearfix"></div>
                    <!--payment-->
 <?php echo $this->session->flashdata('smsp');?>      
                         <div class="row">



                        <div class="col-md-12 col-sm-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>Customer Search<small></small>  <?php echo $this->session->flashdata('sms');?></h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                        </li>
                                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content">

                                  <form action="<?php echo base_url('Payment/AgentPayment');?>" method="post">
                            
                                      <div class="row">
                                      <div class="col-md-8"><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align" style="color:red;">
                                              Agent Name  <span class="required">*</span>
                                              </label>
                                              <div class="col-md-10 col-sm-6">
                                                 <select class="chosent form-control" name="agent_id" >
                                                    <option value="" >Select Customer</option> 
                                                  <?php 
                                                    foreach ($AllAgentList as $AgentList) {
                                                  ?>
                                                    <option value="<?php echo $AgentList->id;?>"><?php echo $AgentList->agent_name;?>/<?php echo $AgentList->agent_id;?>/<?php echo $AgentList->mobile_no;?></option>
                                                  <?php
                                                      }  
                                                  ?>
                                                  </select>
                                      <script type="text/javascript">$(".chosent").chosen(); </script>
                                              </div>
                                          </div>
                                        </div><!--end--->



                                        <div class="col-md-2"><!--start--->
                                            <div class="form-group">
                                                <div class="col-md-6 offset-md-3">
                                                    <button type='submit' class="btn btn-warning">Save</button>
                                                </div>
                                            </div>
                                        </div><!--end--->



                                      </div><!---ROW END-->
                            
                  
                                    </form>
                                </div>
                            </div>
                        </div>
<!--search -->
  <?php 
  //var_dump($VendorAccount); die();
   if($AgentAccount == !null){
  ?>
  <div class="col-md-12 col-sm-12">
                          <!---table----->
                <div class="x_panel">
                  <div class="x_title">
                    <h2> Vendor Information<small></small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>

                  <div class="x_content">
                    <div class="table-responsive">
                      <table class="table table-striped jambo_table bulk_action">
                        <thead>
                          <tr class="headings">
                            <th class="column-title" style="display: table-cell;">Name</th>
                            <th class="column-title" style="display: table-cell;">Serail No</th>
                            <th class="column-title" style="display: table-cell;">Mobile No</th>
                          </tr>
                        </thead>

                        <tbody>

                      <?php 
                          // var_dump($AllvisaCategory);
                          $sl = 0;
                            foreach ($AgentAccount as $AgentData) {
                              $sl++;
                             // var_dump($CustomerAccounts);die();
                          ?>
                          <tr class="even pointer">
                            <td class=" "><?php echo $AgentData->agent_name;?></td>
                            <td class=" "><?php echo $AgentData->agent_id;?></td>
                            <td class=" "><?php echo $AgentData->mobile_no;?></td>
                            </td>
                          </tr>
                          <?php
                            }
                          ?>

                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
          </div><!-- end col-md-6-->

                  <div class="x_content">
                    <div class="table-responsive">
                      <table class="table table-striped jambo_table bulk_action">
                        <tbody>
                         <?php 
                             $VendorPayTicketList = $this->Agent_model->GetAgentTicketPayData($AgentData->id);
                               $billTotal = 0;
                               $payTotal = 0;
                               $duepayment = 0;
                              foreach ($VendorPayTicketList as $VendorPayTicketData) {
                                  $billTotal = (int)$billTotal + (int)$VendorPayTicketData->agent_bill;
                                  $payTotal = (int)$payTotal + (int)$VendorPayTicketData->payment_amount;
                                 $duepayment = (int)$billTotal - (int)$payTotal;
                          ?>
                          <?php   }?>

                        </tbody>
                      </table>
                    </div>
                </div>

                        <div class="col-md-12 col-sm-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>Payment Add<small></small>  <?php echo $this->session->flashdata('sms');?></h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                        </li>
                                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content">

                                  <form action="<?php echo base_url('Payment/AddNewAgentPayment');?>" method="post">
                            
                                      <div class="row">
                                                 <input type="hidden" class="chosent form-control" name="agent_id" value="<?php echo $agent_id;?>" >
                                        

                                        <div class="col-md-6">
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align" style="color:red">Due Amount <span class="required">*</span></label>
                                                  <div class="col-md-10">
                                                      <input type="text" class="form-control"  name="payment_due" value="<?php echo $duepayment;?>" readonly>
                                                    </div>
                                          </div>
                                        </div>

                                        <div class="col-md-6">
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align" style="color:red">Payment Date<span class="required">*</span></label>
                                                  <div class="col-md-10 ">
                                                      <input type="text" class="form-control has-feedback-left" id="single_cal4" placeholder="First Name" name="payment_date" aria-describedby="inputSuccess2Status4"  required="required" >
                                                      <span class="fa fa-calendar-o form-control-feedback left" aria-hidden="true"></span>
                                                      <span id="inputSuccess2Status4" class="sr-only">(success)</span>
                                                    </div>
                                          </div>
                                        </div>
<script>
$(document).ready(function(){
    $("select").change(function(){
        $(this).find("option:selected").each(function(){
            var optionValue = $(this).attr("value");
            if(optionValue){
                $(".box").not("." + optionValue).hide();
                $("." + optionValue).show();
            } else{
                $(".box").hide();
            }
        });
    }).change();
});
</script>



                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Payment Method <span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <select class="form-control"  name="payment_method">
                                                    <option value="">Select Payment Method</option>
                                                    <option value="CashIn">CashIn</option>
                                                    <option value="Bank">Bank</option>
                                                    <option value="Bkash">Bkash</option>
                                                    <option value="Rocket">Rocket</option>
                                                    <option value="Nogod">Nogod</option>
                                                  </select>
                                                </div>
                                          </div>
                                        </div><!--end--->

                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align" style="color:red">Amount.<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" class='optional' name="payment_amount"  type="number"    required="required" />
                                                </div>
                                          </div>
                                        </div><!--end--->

                                        <div class="col-md-6 Bank box" ><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Bank <span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" class='optional' name="bank_name"  type="text" placeholder="Name"/>
                                                </div>
                                          </div>
                                        </div><!--end--->

                                        <div class="col-md-6 Bank box"><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Account N <span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" class='optional' name="account_number"  type="text" placeholder="Number" />
                                                </div>
                                          </div>
                                        </div><!--end--->

                                        <div class="col-md-6  Bkash box" ><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Bkash <span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" class='optional' name="bkash_n"  type="text"   placeholder="Number" />
                                                </div>
                                          </div>
                                        </div><!--end--->

                                        <div class="col-md-6  Rocket box"><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Rocket <span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" class='optional' name="rocket_n"  type="text"   placeholder="Number" />
                                                </div>
                                          </div>
                                        </div><!--end--->

                                        <div class="col-md-6 Nogod box"><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Nogod <span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" class='optional' name="nogod_n"  type="text" placeholder="Number" />
                                                </div>
                                          </div>
                                        </div><!--end--->

                                        <div class="col-md-6" style="margin-top: 10px;"><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Remark <span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" class='optional' name="remark"  type="text" placeholder="Enter Remark !" />
                                                </div>
                                          </div>
                                        </div><!--end--->


                                        <div class="col-md-2" style="margin-top: 10px;"><!--start--->
                                            <div class="form-group">
                                                <div class="col-md-6 offset-md-3">
                                                    <button type='submit' class="btn btn-info btn-lg">Save</button>
                                                </div>
                                            </div>
                                        </div><!--end--->


                                      </div><!---ROW END-->
                            
                  
                                    </form>
                                </div>
                            </div>
                        </div>


<?php } ?>
                    </div>

                </div>
            </div>
            <!-- /page content -->