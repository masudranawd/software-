    <!-- page content -->
        <div class="right_col" role="main">
  <div class="col-md-12 col-sm-12">
          <div>
            <nav class="nav navbar-nav">
              <ul class=" navbar-right" style="text-align: center;">
                  <a  href="<?php echo base_url('')?>Pay_Date" type="button" class="btn btn-round btn-secondary">Go Back </a>
              </ul>
            </nav>
          </div>
                          <!---table----->
                <div class="x_panel">
                  <div class="x_title">
                    <h2 style="color: #fff;"> &nbsp;&nbsp; &nbsp;&nbsp;Daily Ladger Book<small>Date:<?php echo $PayDate->pay_date;?> <?php echo $this->session->flashdata('sms');?> </small></h2>
                    <center> 
                      <botton type="button" class="btn btn-round btn-success btn-block" style="font-size: 22px;">Payment</botton>
                    </center>
                    <div class="clearfix"></div>
                  </div>

                  <div class="x_content">
                    <div class="table-responsive">
                      <table class="table table-striped jambo_table bulk_action" style="width: 100%;">
                        <thead>
                          <tr class="headings">
                            <th class="column-title" style="text-align: center;">Sl</th>
                            <th class="column-title" style="text-align: center;">V_ID</th>
                            <th class="column-title" style="text-align: center;">V Name</th>
                            <th class="column-title" style="text-align: center;">C_ID</th>
                            <th class="column-title" style="text-align: center;">C Name</th>
                            <th class="column-title" style="text-align: center;">Type</th>
                            <th class="column-title" style="text-align: center;">Method</th>
                            <th class="column-title" style="text-align: center;">Amount</th>
                            <th class="column-title" style="text-align: center;">Remark</th>
                            <th class="column-title" style="text-align: center;">Action</th>
                          </tr>
                        </thead>
                        <tbody>

                      <?php 
                          // var_dump($AllvisaCategory);
                          $sl = 0;
                          $totalpay = 0;
                            foreach ($AllPaymentData as $PaymentData) {
                              if($PaymentData->pay_id == $id){
                              if($PaymentData->type == 'Payment'){
                              $sl++;
                              $totalpay = (int)$totalpay + (int)$PaymentData->account_number;
                          ?>
                          <tr class="even pointer">
                            <td class=" "><?php echo $sl;?></td>


                            <td class=" "> 
                              <?php 
                                  if ($PaymentData->vendor_id == !null ) {
                               ?>                             
                                <?php  
                                  $CustomerInfo = $this->Payment_model->vendor_info_for_invoice($PaymentData->vendor_id);echo ' <b> Sl.</b>'; echo $CustomerInfo->vendor_id;
                              ?>
                            <?php }else{ echo '';} ?>

                            </td>

                            <td class=" "> 
                              <?php 
                                  if ($PaymentData->vendor_id == !null ) {
                               ?>                             
                                <?php  
                                  $CustomerInfo = $this->Payment_model->vendor_info_for_invoice($PaymentData->vendor_id);echo ' <b> Sl.</b>'; echo $CustomerInfo->vendor_name;
                              ?>
                            <?php }else{ echo '';} ?>

                            </td>

                            <td class=" ">

                              <?php 
                                  if ($PaymentData->agent_id == !null ) {
                               ?>   
                              <?php  
                                  $AgentInfo = $this->Accounts_model->Agent_info_for_invoice($PaymentData->agent_id);echo '<b>Sl.</b>';
                                    echo $AgentInfo->agent_id; 
                              ?>

                            <?php }else{
                                echo '';} ?>
                            </td>


                            <td class="" style="width: 12%;"> 
                               <?php 
                                  if ($PaymentData->agent_id == !null ) {
                               ?>  
                              <?php  
                                  $AgentInfo = $this->Accounts_model->Agent_info_for_invoice($PaymentData->agent_id);
                                    echo $AgentInfo->agent_name;
                              ?>
 <?php }else{
                                echo '';} ?>
                            </td>
                            </td>

                            <td style="text-align: center;"><?php if( $PaymentData->type == !null){echo $PaymentData->type;}else{echo '';}?></td> 
                            <td style="text-align: center;"><?php echo $PaymentData->payment_method;?></td>
                            <td style="text-align: center;"><?php if($PaymentData->payment_amount== null){ echo '';}else{ echo $PaymentData->payment_amount;}?></td>
                            <td class=" "><?php echo $PaymentData->remark;?></td>
                            <td class=" ">
                              <a href="" class="btn btn-round btn-danger" data-toggle="modal" data-target="#Remove<?php echo $PaymentData->id;?>">X</a>
                            </td>
                          </tr>

<!--- remove model  ---->
<div class="modal fade" id="Remove<?php echo $PaymentData->id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="myModalLabel"> Voucher  No:##<?php echo $PaymentData->voucher_no;?> </h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body">

<form action="<?php echo base_url('Accounts/RemoveCashInpayment/');?><?php  echo $PaymentData->id;?>/<?php  echo $PaymentData->pay_id;?>" method="post">
          <div class="field item form-group">
            <label class="col-form-label col-md-12 col-sm-3  label-align" style="color:red;font-size: 1.3rem;font-weight: 900;text-align: center;">  Are You Sure ? Remove It. </label>
         </div>     

          <div class="ln_solid">
            <div class="form-group">
               <div class="col-md-6 offset-md-3">
                   <button type='submit' class="btn btn-primary">Yes</button>
                    <button type='reset' class="btn btn-success">No</button>
                 </div>
            </div>
          </div>
         </form>
      </div>
    </div>
  </div>
</div>
<!--- model end ----->
                            <?php
                          }
                         }
                       }
                        ?>
        <!-- start -->
        <tr style="height: 400px;">
          <form action="<?php echo base_url('payment/AddNewCashInPaymentData');?>" method="post" >
           <input type="hidden" name="payment_date" value="<?php echo $PayDate->pay_date;?>">
           <input type="hidden" name="pay_id" value="<?php echo $PayDate->id;?>">

            <td style="width: 2%;">  <?php echo $sl+1;?></td>
               <td colspan="2" style="width: 13%;">
                <div class="field item form-group  customer Booth" style="margin-top: -8px;">
                 <select style="border-radius: 10px;" class="chosent  pay" name="vendor_id"  >
                       <option  value="">Select Vendor</option> 
                        <?php 
                          foreach ($AllVendorData as $VendorData) {
                        ?>
                        <option value="<?php echo $VendorData->id;?>"> <?php echo $VendorData->vendor_id;?> / <?php echo $VendorData->company_name;?> / <?php echo $VendorData->vendor_name;?> / <?php echo $VendorData->phone;?>  
                        </option>
                        <?php
                          }  
                       ?>
                  </select>
                <script type="text/javascript">$(".chosent").chosen(); </script>
              </div>
               </td><!--end-->

             
               <td colspan="3" style="width: 13%;">
                  <div class="field item form-group  Agent Booth" style="margin-top: -8px;width: 100%;">
                   <select class="chosent pay" name="agent_id" style="height: 300px;width: 100%;" >
                      <option value="" >Select Customer</option> 
                        <?php  foreach ($AllAgentList as $AgentData) { ?>
                          <option value="<?php echo $AgentData->id;?>"> <?php echo $AgentData->agent_id;?> / <?php echo $AgentData->agent_name;?> 
                          </option>
                     <?php  }  ?>
                    </select>
                 <script type="text/javascript">$(".chosent").chosen(); </script>
               </div>
               </td>

               <td style="width: 10%;"><script>
$(document).ready(function(){
    $("select").change(function(){
        $(this).find("option:selected").each(function(){
            var optionValue = $(this).attr("value");
            if(optionValue){
                $(".box").not("." + optionValue).hide();
                $("." + optionValue).show();
            } else{
                $(".box").hide();
            }
        });
    }).change();
});
</script>

                                  <!--start--->
                                          <div class="field item form-group">
                                              <div class="col-md-12 col-sm-6">
                                                  <select class="form-control"  name="payment_method" required>
                                                    <option value="">Select Payment Method</option>
                                                    <option value="CashIn">CashIn</option>
                                                    <option value="Bank">Bank</option>
                                                    <option value="Bkash">Bkash</option>
                                                    <option value="Rocket">Rocket</option>
                                                    <option value="Nogod">Nogod</option>
                                                  </select>
                                                </div>
                                        </div><!--end--->

                                      <!--start--->
                                          <div class="field item form-group Bank box">
                                            <input type="text" name="bank_name" class="form-control" placeholder="Bank Name">
                                        </div><!--end--->
                                      
                                        <!--start--->
                                          <div class="field item form-group Bank box  ">
                                              <input class="form-control" class='optional' name="account_number"  type="text" placeholder="Recepit No" />
                                        </div><!--end--->

<!--start--->
                                    <!--start--->
                                          <div class="field item form-group  Bkash box">
                                              <input class="form-control" class='optional' name="bkash_n"  type="text"   placeholder="Number" />
                                        </div><!--end--->
<!--start--->
                                          <div class="field item form-group  Rocket box">
                                            <input class="form-control" class='optional' name="rocket_n"  type="text"   placeholder="Number" />
                                          </div><!--end--->

                                       <!--start--->
                                          <div class="field item form-group Nogod box">
                                            <input class="form-control" class='optional' name="nogod_n"  type="text" placeholder="Number" />
                                        </div><!--end--->

           
               </td>

               <td style="width: 10%;">
                   <div class="field item form-group">
                        <input  class="form-control pay" type="text" name="payment_amount" placeholder="enter Amount">
                   </div>
               </td>
               <td style="width: 10%;">
                  <div class="field item form-group">
                      <div class="col-md-12">
                        <textarea  class="form-control " type="text" name="remark" placeholder="enter Remark" rows="1">
                          </textarea>
                      </div>
                   </div>
               </td>
               <td style="width: 5%;">
                     <button type='submit' class="btn btn-warning sourc">+Add </button>
               </td>
          </form>
        </tr>
        <!-- end -->

<tr>
  <td colspan="10" style="text-align: right;">Total Cash IN = <?php echo   $totalpay;?></td>
</tr>


                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
          </div><!-- end col-md-6-->

  
         <div class="col-md-2 col-sm-6">
               <div class="col-md-12 offset-md-3">
                    <button type='submit' class="btn btn-warning sourc"  data-toggle="modal" data-target="#ConfirmData" >Confirm </button>
                 </div>
        </div>
            

<!--- remove model  ---->
<div class="modal fade" id="ConfirmData" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="myModalLabel"> Date:##<?php echo $PayDate->pay_date;?> </h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body">

<form action="<?php echo base_url('DateWais');?>" method="post">
          <div class="field item form-group">
            <label class="col-form-label col-md-12 col-sm-3  label-align" style="color:green;font-size: 1.3rem;font-weight: 900;text-align: center;">  Are You Sure ? Your Ladger Completed . </label>
         </div>        

          <div class="ln_solid">
            <div class="form-group">
               <div class="col-md-6 offset-md-3">
                   <button type='submit' class="btn btn-primary">Yes</button>
                    <button type='reset' class="btn btn-success">No</button>
                 </div>
            </div>
          </div>
         </form>
      </div>
    </div>
  </div>
</div>
<!--- model end ----->

                    </div><!-- end row---->
                </div>
            </div>
            <!-- /page content -->



