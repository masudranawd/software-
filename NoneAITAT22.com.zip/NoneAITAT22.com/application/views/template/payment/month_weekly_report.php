    <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Weekly and Monthly  Cash Report</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="#">Settings 1</a>
                            <a class="dropdown-item" href="#">Settings 2</a>
                          </div>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      <div class="row">
                          <div class="col-sm-12">
                            <div class="card-box table-responsive"  id="printMe">    
                            <table style="width:80%;height:100%;margin:0px auto;margin-top: 20px;">
                                <tr><br><br>
                                   <th style="text-align: center;width:10%;">
                                       <img src="<?php echo base_url();?>images/<?php echo $SiteData->logo;?>" alt="" style="height:100px;width:100px;">
                                    </th>
                                    <th style="width:40%;text-align: left;">
                                    <h6 style="color:#000;font-weight: bold;"><?php echo $SiteData->name;?></h6>
                                    <h6 style="color:#000;font-weight: bold;"><?php echo $SiteData->address;?></h6>
                                    <h6 style="color:#000;font-weight: bold;">E-mail:<?php echo $SiteData->email;?></h6>
                                    <h6 style="color:#000;font-weight: bold;">Phone: <?php echo $SiteData->phone;?></h6>
                               </th>
                               <th style="width: 25%"></th>
                               <th style="width:25%;text-align: left;">
                                    <h6 style="color:#000;font-weight: bold;">Payment Ledger Statement</h6>
                                  <address style="color:#000;">
                                       <strong>
                              <?php if($fromdate){echo  'From date :'.$fromdate; }else{ echo '';} ?><br><?php if($todate){echo  'To date :'.$todate; }else{ echo '';} ?>

                                      </address>
                                  </th>
                                    </tr>
                              </table>

                    <table class="table_border" style="width:90%;border-collapse: collapse;margin:0px auto;" >
                      <thead>
                        <tr>
                          <th>Sl</th>
                          <th>Payment Date</th>
                          <th>Name</th>
                          <th>Type</th>
                          <th>Details</th>
                          <th>Amount</th>
                        </tr>
                      </thead>


                      <tbody>
                      <?php
                          $sl=0;
                          $total = 0;
                        foreach ($MonthlyWeeklyListData as $DailyCash) {
                          $sl++;
                          $total = $total+$DailyCash->payment_amount;
                      ?>


                        <tr>
                          <td><?php echo $sl;?></td>
                          <td style="width: 10%;"><?php echo date('dS M Y', strtotime($DailyCash->payment_date));?></td>      
                          <td><?php 
                            if ($DailyCash->vendor_id) {
                            ?>

                            <?php 
                              $vendorname = $this->Payment_model->vendor_info_for_invoice($DailyCash->vendor_id);
                                echo '<b>Vendor Name:</b>'.$vendorname->vendor_name;
                             ?>

                            <?php
                            }else{
                            ?>
                            <?php 
                              $AgentName = $this->Payment_model->Agent_info_for_invoice($DailyCash->agent_id);
                                echo '<b>Agent Name:</b>'.$AgentName->agent_name;
                             ?>

                            <?php
                            } ?></td>
                          <td><?php echo $DailyCash->type;?></td>     
                          <td style="width: 50%;text-align:left;">
                            <b> Payment Method :</b> <?php echo $DailyCash->payment_method;?>,
                            <?php 
                                if ($DailyCash->bank_name) {echo '<b>Bank Name:</b>'.$DailyCash->bank_name; echo '<b> Account Number : </b>'.$DailyCash->account_number;}elseif ($DailyCash->bkash_n) {echo  '<b>Bkash Number : </b>'. $DailyCash->bkash_n;}elseif ($DailyCash->rocket_n) {echo  '<b>Rocket Number : </b>'.$DailyCash->rocket_n;}elseif ($DailyCash->nogod_n) {echo  '<b>Nogod Number : </b>'. $DailyCash->nogod_n;}
                            ?>
                          </td>
                          <td><?php echo $DailyCash->payment_amount;?></td>
                        </tr>
                      <?php
                        }
                      ?>


                        <tr>
                          <td colspan="5" style="text-align: right;">Total</td>
                          <td><?php echo $total;?></td>
                        </tr>
                      </tbody>
                    </table>


                  </div>
                </div>

                      <div class="row no-print">
                        <div class=" ">
                          <button class="btn btn-default" onclick="printDiv('printMe')"><i class="fa fa-print"></i> Print</button>
                        </div>
                      </div>
              </div>
            </div>
                </div>
              </div>

            </div><!--end row-->
          </div>
        </div>
        <!-- /page content -->


        <script>
    function printDiv(divName){
        var printContents = document.getElementById(divName).innerHTML;
        var originalContents = document.body.innerHTML;
        document.body.innerHTML = printContents;
        window.print();
        document.body.innerHTML = originalContents;
    }   
  </script>