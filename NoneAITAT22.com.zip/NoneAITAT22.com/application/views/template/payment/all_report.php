    <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>All Report</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="#">Settings 1</a>
                            <a class="dropdown-item" href="#">Settings 2</a>
                          </div>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      <div class="row">
                          <div class="col-sm-12">
                            <div class="card-box table-responsive"  id="printMe">
       <table style="width:80%;height:100%;margin:0px auto;margin-top: 20px;">
                                <tr><br><br>
                                   <th style="text-align: center;width:10%;">
                                       <img src="<?php echo base_url();?>images/<?php echo $SiteData->logo;?>" alt="" style="height:100px;width:100px;">
                                    </th>
                                    <th style="width:40%;text-align: left;">
                                    <h6 style="color:#000;font-weight: bold;"><?php echo $SiteData->name;?></h6>
                                    <h6 style="color:#000;font-weight: bold;"><?php echo $SiteData->address;?></h6>
                                    <h6 style="color:#000;font-weight: bold;">E-mail:<?php echo $SiteData->email;?></h6>
                                    <h6 style="color:#000;font-weight: bold;">Phone: <?php echo $SiteData->phone;?></h6>
                               </th>
                               <th style="width: 25%"></th>
                               <th style="width:25%;text-align: left;">
                                    <h6 style="color:#000;font-weight: bold;"> Ledger Statement</h6>
                                  <address style="color:#000;">
                                       <strong>
                              <?php if($fromdate){echo  'From date :'.$fromdate; }else{ echo '';} ?><br><?php if($todate){echo  'To date :'.$todate; }else{ echo '';} ?>

                                      </address>
                                  </th>
                                    </tr>
                              </table>

                    <table  class="table_border " style="width:90%;border-collapse: collapse;margin:0px auto;" >
                      <thead>
                        <tr>
                          <th>Sl</th>
                          <th>Type</th>
                          <th>Description</th>
                          <th>Vendor Bill </th>
                          <th>Agent Bill </th>
                          <th>Payment Amount</th>
                          <th>Payment Due</th>
                        </tr>
                      </thead>


                      <tbody>
                      <?php
                          $sl=0;
                          $AbillTotal =0;
                          $billTotal = 0;
                          $payTotal = 0;
                        foreach ($AllTicketBookingData as $TicketPayData) {
                          $sl++;
                          $billTotal = (int)$billTotal+(int)$TicketPayData->bill_amount;
                          $AbillTotal = (int)$AbillTotal+(int)$TicketPayData->agent_bill;
                          $payTotal = (int)$payTotal+(int)$TicketPayData->payment_amount;
                      ?>   <tr>
                          <td style="width: 3%;text-align:center;"><?php echo $sl;?></td>
                          <td style="width: 8%;text-align:center;">
                              
                              <?php if ($TicketPayData->type == 'New Ticket') { echo $TicketPayData->type;}else{ 
                              ?>
                              <?php if($TicketPayData->vendor_id){ echo 'Vendor Payment';}else{ echo 'Customer Payment'; }?>
                              <?php }?> 
                              
                              
                              </td>
                          <?php 
                              if ($TicketPayData->type == 'New Ticket') {
                           ?>

                          <td style="width: 55%;">

      <?php $PassengerData = $this->Ticket_model->PassengerDataGetById($TicketPayData->passenger_id); ?> 
                            <b>Passenger Name :</b>
                            <?php echo $PassengerData->first_name.$PassengerData->last_name; ?>
                            <b>P.P</b><?php echo $PassengerData->passport_no;?>
                            <b>Ticket No</b><?php echo $PassengerData->ticket_no;?>
                            <b>AirLine PNR</b><?php echo $PassengerData->a_ticket_pnr;?>
                            <b>Galileo PNR</b><?php echo $PassengerData->g_ticket_pnr;?>
                            <b>Issue Date </b> <?php echo $PassengerData->d_of_issue;?>
                          </td>

                          

                           <?php
                              }else{
                          ?>
                          <td>

                           
<b>Date :</b> <?php echo date('dS M Y', strtotime($TicketPayData->payment_date));?>,<b> Payment Method :</b> <?php echo $TicketPayData->payment_method;?>,
<?php 
    if ($TicketPayData->bank_name) {echo '<b>Bank Name:</b>'.$TicketPayData->bank_name; echo '<b> Account Number : </b>'.$TicketPayData->account_number;}elseif ($TicketPayData->bkash_n) {echo  '<b>Bkash Number : </b>'. $TicketPayData->bkash_n;}elseif ($TicketPayData->rocket_n) {echo  '<b>Rocket Number : </b>'.$TicketPayData->rocket_n;}elseif ($TicketPayData->nogod_n) {echo  '<b>Nogod Number : </b>'. $TicketPayData->nogod_n;}
?>
                       
                            

                          </td> 
                          <?php
                              }
                          ?>

                          <td style="text-align: right;width: 8%;" ><?php echo $TicketPayData->bill_amount;?></td>
                          <td style="text-align: right;width: 8%;" ><?php echo $TicketPayData->agent_bill;?></td>
                          <td style="text-align: right;width: 8%;"><?php echo $TicketPayData->payment_amount;?></td> 
                          <td style="text-align: right;width: 10%;"><?php echo $TicketPayData->payment_due;?></td>
                       
                        </tr>
                      <?php
                      }
                      ?>
                        <tr>
                          <td colspan="4" style="text-align: right;color:#000;font-weight: bold;">Total Bill = <?php echo $billTotal;?></td>
                         <td style="color:#000;font-weight: bold; text-align: right;">Total Agent Bill = <?php echo $AbillTotal;?></td>
                          <td style="color:#000;font-weight: bold; text-align: right;width:11%;">Total Payment =<?php echo $payTotal;?></td>
                          <td style="color:#000;font-weight: bold; text-align: right;width:11%;"></td>
                        </tr>

                      </tbody>
                    </table>

                  </div>
                </div>
                      <div class="row no-print">
                        <div class=" ">
                          <button class="btn btn-default" onclick="printDiv('printMe')"><i class="fa fa-print"></i> Print</button>
                        </div>
                      </div>
              </div>
            </div>
                </div>
              </div>

            </div><!--end row-->
          </div>
        </div>
        <!-- /page content -->


        <script>
    function printDiv(divName){
        var printContents = document.getElementById(divName).innerHTML;
        var originalContents = document.body.innerHTML;
        document.body.innerHTML = printContents;
        window.print();
        document.body.innerHTML = originalContents;
    }   
  </script>