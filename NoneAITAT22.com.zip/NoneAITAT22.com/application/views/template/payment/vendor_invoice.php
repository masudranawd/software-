
        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="clearfix"></div>
 <div class="row">
              <div class="col-md-12">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>Invoice Print</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="#">Settings 1</a>
                            <a class="dropdown-item" href="#">Settings 2</a>
                          </div>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">

                    <section class="content invoice" id="printMe">
                        <!-- /.col -->
                      <!-- info row -->
                      <div class="row invoice-info" >
                          <table style="width:90%;height:100%;margin:0px auto;margin-top: 20px;">
                                <tr><br><br>
                                   <th style="text-align: center;width:10%;">
                                       <img src="<?php echo base_url();?>images/<?php echo $SiteData->logo;?>" alt="" style="height:100px;width:100px;">
                                    </th>
                                    <th style="width:40%;text-align: left;">
                                    <h6 style="color:#000;font-weight: bold;"><?php echo $SiteData->name;?></h6>
                                    <h6 style="color:#000;font-weight: bold;"><?php echo $SiteData->address;?></h6>
                                    <h6 style="color:#000;font-weight: bold;">E-mail:<?php echo $SiteData->email;?></h6>
                                    <h6 style="color:#000;font-weight: bold;">Phone: <?php echo $SiteData->phone;?></h6>
                               </th>
                               <th style="width: 25%"></th>
                               <th style="width:25%;text-align: left;">
                                    <h6 style="color:#000;font-weight: bold;">Customer Ledger Statement</h6>
                                  <address style="color:#000;">
                                       <strong>Name:
                                          <?php 
                                          $CustomerInfo = $this->Payment_model->vendor_info_for_invoice($InvoiceData->vendor_id);
                       
                                          if($CustomerInfo->vendor_name){ echo $CustomerInfo->vendor_name;}else{'';}
                                          ?>
                                            
                                          </strong><br>
                                          <b>SL:</b>
                                          <?php 
                                          $CustomerInfo = $this->Payment_model->vendor_info_for_invoice($InvoiceData->vendor_id);
                       
                                          if($CustomerInfo->vendor_id){ echo $CustomerInfo->vendor_id;}else{'';}
                                          ?>
                                          <br>
                                          <b>Phone:</b>
                                          <?php 
                                          $CustomerInfo = $this->Payment_model->vendor_info_for_invoice($InvoiceData->vendor_id);
                       
                                          if($CustomerInfo->phone){ echo $CustomerInfo->phone;}else{'';}
                                          ?><br>
                                  <b>Date:<?php echo  $InvoiceData->payment_date;?></b>
                                  <br>
                                  <b>Payment Amount:</b> <?php echo  $InvoiceData->payment_amount;?>
                                      </address>
                                  </th>
                                    </tr>
                              </table>
                        <!-- /.col -->
                      </div>
                      <!-- /.row -->

                      <!-- Table row -->
                      <div class="row">
                        <div class="table">
                          <table class="table table-striped">
                            <thead>
                              <tr>
                                <th>sl</th>
                                <th>Details</th>
                                <th>Amount</th>
                              </tr>
                            </thead>
                            <tbody>
                              <tr>
                                <td>1</td>
                                <td>
                                  
                           
<b>Date :</b> <?php echo date('dS M Y', strtotime($InvoiceData->payment_date));?>,<b> Payment Method :</b> <?php echo $InvoiceData->payment_method;?>,
<?php 
    if ($InvoiceData->bank_name) {echo '<b>Bank Name:</b>'.$InvoiceData->bank_name; echo '<b> Account Number : </b>'.$InvoiceData->account_number;}elseif ($InvoiceData->bkash_n) {echo  '<b>Bkash Number : </b>'. $InvoiceData->bkash_n;}elseif ($InvoiceData->rocket_n) {echo  '<b>Rocket Number : </b>'.$InvoiceData->rocket_n;}elseif ($InvoiceData->nogod_n) {echo  '<b>Nogod Number : </b>'. $InvoiceData->nogod_n;}
?>
                                </td>
                                <td><?php echo  $InvoiceData->payment_amount;?></td>
                              </tr>

                              <tr>
                                <td colspan="2" style="text-align: right;"><b>Total= </b></td>
                                <td><?php echo  $InvoiceData->payment_amount;?></td>
                              </tr>

                            </tbody>
                          </table>
                        </div>
                        <!-- /.col -->
                      </div>
                      <!-- /.row -->

                      <!-- this row will not appear when printing -->
                    </section>


                      <div class="row no-print">
                        <div class=" ">
                          <button class="btn btn-default" onclick="printDiv('printMe')"><i class="fa fa-print"></i> Print</button>
                        </div>
                      </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <script>
    function printDiv(divName){
        var printContents = document.getElementById(divName).innerHTML;
        var originalContents = document.body.innerHTML;
        document.body.innerHTML = printContents;
        window.print();
        document.body.innerHTML = originalContents;
    }   
  </script>