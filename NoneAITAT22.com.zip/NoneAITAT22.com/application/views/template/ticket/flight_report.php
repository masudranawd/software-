
            <!-- page content -->
            <div class="right_col" role="main">
                <div class="">
                    
                    <div class="clearfix"></div>

  <?php echo $this->session->flashdata('smg');?>
                    <div class="row">
                        <div class="col-md-12 col-sm-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>Flight<small>Report</small></h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                        </li>
                                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content">
                                    <form class="" action="<?php echo base_url('Ticket/FlightReport');?>" method="post" novalidate>
                                  
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">From Date<span class="required">*</span></label>
                                                  <div class="col-md-3 ">
                                                      <input type="date" class="form-control"  name="fromdate">
                                                    </div>
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">To Date<span class="required">*</span></label>
                                                  <div class="col-md-3 ">
                                                      <input type="date" class="form-control" name="todate">
                                                    </div>

                                        <div class="col-md-2 col-sm-6">
                                            <div class="form-group">
                                                <div class="col-md-2 offset-md-3">
                                                    <button type='submit' class="btn btn-secondary sourc" >Submit</button>
                                                </div>
                                            </div>
                                           
                                        </div>
                                          </div>

                                    </form>
                                </div>
                            </div>
                        </div>
<?php 
    if ($AllFlightReport ) {
?>
                  <div class="x_content">
                      <div class="row">
                          <div class="col-sm-12">
                            <div class="card-box table-responsive"  id="printMe" >
                              <table style="width:90%;height:100%;margin:0px auto;">
                                <tr><br><br>
                                   <th style="text-align: center;width:10%;">
                                       <img src="<?php echo base_url();?>images/<?php echo $SiteData->logo;?>" alt="" style="height:100px;width:100px;">
                                    </th>
                                    <th style="width:40%;text-align: left;">
                                    <h6 style="color:#000;font-weight: bold;"><?php echo $SiteData->name;?></h6>
                                    <h6 style="color:#000;font-weight: bold;"><?php echo $SiteData->address;?></h6>
                                    <h6 style="color:#000;font-weight: bold;">E-mail:<?php echo $SiteData->email;?></h6>
                                    <h6 style="color:#000;font-weight: bold;">Phone: <?php echo $SiteData->phone;?></h6>
                               </th>
                               <th style="width: 25%"></th>
                               <th style="width:25%;text-align: left;">

                                    <h2 style="color:#000;font-weight: bold;">Flight Report</h2>
                                    <h6 style="color:#000;font-weight: bold;"><?php if ($fromdate){ echo 'From Date:'.$fromdate;}else{echo '';}?> 
                                    <br>
                                     <?php if ($todate){ echo 'To Date:'.$todate;}else{echo '';}?> </h6>
                                  </th>
                                    </tr>
                              </table>

                    <table  class="table_order " style="width:90%;height:100%;margin:0px auto; background-color: #fff;color:#000">
                   
                      <thead>
                        <tr>
                          <th style="text-align: center;"> Id</th>
                          <th style="text-align: center;">Passenger Name</th>
                          <th style="text-align: center;">Passport No </th>
                          <th style="text-align: center;">Flight Date</th>
                          <th style="text-align: center;">Descriptions </th>
                        </tr>
                      </thead>


                      <tbody>
                      <?php
                          $sl=0;
                          $billtotal = 0; 
                          $paymenttotal = 0; 
                        foreach ($AllFlightReport as $Flightdata) {
                          $sl++;
                        
                      ?>
                        <tr>
                          <td style="text-align:center;"><?php echo $sl;?></td>
                          <td style="text-align:left;">
                            <?php echo $Flightdata->first_name.$Flightdata->last_name; ?>  
                          </td>
                          <td style="text-align:center;">
                            <?php echo $Flightdata->passport_no; ?>  
                          </td>
                          <td style="text-align:center;">
                            <?php echo $Flightdata->flight_date; ?>  
                          </td>
                          <td style="width:50%;text-align:left;">
                            <?php echo '<b>Ticket No :</b>'.$Flightdata->ticket_no; ?> 
                            <?php echo '<b>Airline PNR :</b>'.$Flightdata->a_ticket_pnr; ?> 
                            <?php echo '<b>Galileo PNR :</b>'.$Flightdata->g_ticket_pnr; ?> 
                            <?php echo '<b>Date of Issue  :</b>'.$Flightdata->d_of_issue; ?> 
                            <?php echo '<b>Date of Issue  :</b>'.$Flightdata->d_of_issue; ?> 
                            <?php echo '<b>Flight Name  :</b>'.$Flightdata->flight_name.$Flightdata->flight_code; ?> 
                            <?php echo '<b>Form  :</b>'.$Flightdata->from_country; ?> 
                            <?php echo '<b>To   :</b>'.$Flightdata->to_country; ?> 
                            <?php echo '<b>Depart  :</b>'.$Flightdata->Depart; ?> 
                            <?php echo '<b>Arrive   :</b>'.$Flightdata->Arrive; ?> 
                            <?php echo '<b>Baggage   :</b>'.$Flightdata->baggage; ?> 
                            <?php echo '<b>Class  :</b>'.$Flightdata->class; ?>
                            <?php echo '<b>Duration   :</b>'.$Flightdata->duration; ?> 
                          </td>
                        </tr>
                      <?php
                        }
                      ?>
                    </tbody>
                      <tbody>
                      <tr>
                      </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
                  <div class="row no-print">
                      <div class=" ">
                        <button class="btn btn-default" onclick="printDiv('printMe')"><i class="fa fa-print"></i> Print</button>
                      </div>
                  </div>
              </div>
            </div>
                </div>
              </div>

            
<?php
    }else{
  ?>
  <div style="color:red"><h2>Flight Not Fround !</h2></div>
<?php 
    }
?>
   
   </div><!--end row-->
          </div>
        </div>
        <!-- /page content -->

        <script>
    function printDiv(divName){
        var printContents = document.getElementById(divName).innerHTML;
        var originalContents = document.body.innerHTML;
        document.body.innerHTML = printContents;
        window.print();
        document.body.innerHTML = originalContents;
    }   
  </script>



