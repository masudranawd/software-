<?php 
//include tcpdf/library 
//include 'tcpdf/tcpdf.php'; 
//make TCPDF Object
$pdf = new TCPDF('p','mm','A4'); 
$pdf->SetFont('aefurat', '', 12);

//remove default header & footer. 
$pdf->setPrintHeader(false); 
$pdf->setPrintFooter(false); 
//add page
$pdf->AddPage(); 
//add conten
//USING CELL
//1# $pdf->Cell(190,10,'This is A cell',1,1,'C');


$pdf->writeHTMLCell(0,0,0,15,'',0,0); //HEADER.
$pdf->Image(base_url('images/').$SiteData->logo,160,30,0,25);

$tbl = <<<EOD
<br>
<br>

<table cellspacing="0">
	<tr>
	<th style="width:150mm;">
		<b style="font-size:19px;">Air Trip International Ltd.</b> <br>	
		Ciy Heart, Suite #5/3 (4th fl), 67 Naya Paltan <br>
		VIP Road, Dhaka-1000, Phone: 9353512-5<br><br>
		Navana Tower Type-C, (5th Floor) 45 Gulshan Avenue<br>
		Gulshan-1, Dhaka-1212, Phone: 985754-7<br>
		E-mail: airtrip@timesgroupbd.com, www.timesgroupbd.com
<br><br>
	</th>
	<th style="width:40mm;font-size:18px;">
	</th>

	</tr>
</table>

<table cellspacing="0">
	<tr>
	<th style="font-size:18px;"><b>Passenger Information</b></th>
	</tr>
</table>

<table cellspacing="0" border="1"  >
    <tr style="background-color:#87ceeb;color:#000;">
	    <th style="width:60mm">&nbsp;&nbsp;Passenger Information </th>
	    <th style="width:35mm">&nbsp;&nbsp;Passport <br>&nbsp;&nbsp;Number</th>
	    <th style="width:40mm">&nbsp;&nbsp;Frequent Flyer <br>&nbsp;&nbsp;Number</th>
	    <th style="width:55mm"> Ticket </th>
    </tr>
    <tr>
    	<th>&nbsp;&nbsp;$TicketData->last_name / $TicketData->first_name </th>
    	<th>&nbsp;&nbsp;$TicketData->passport_no </th>
    	<th> </th>
    	<th>&nbsp;&nbsp;$TicketData->ticket_no </th>
    </tr>
</table>

<br/>
<br/>
<table cellspacing="0" border="1"  >
    <tr style="background-color:#87ceeb;color:#000;">
	    <th style="width:100mm">&nbsp;&nbsp;AirLine PNR </th>
	    <th style="width:45mm">&nbsp;&nbsp;Galileo PNR</th>
	    <th style="width:45mm">&nbsp;&nbsp;Date of Issue</th>
    </tr>
    <tr>
    	<th>&nbsp;&nbsp;$TicketData->a_ticket_pnr </th>
    	<th>&nbsp;&nbsp;$TicketData->g_ticket_pnr </th>
    	<th>&nbsp;&nbsp;$TicketData->d_of_issue </th>
    </tr>
</table>
<br>
<br>
<table cellspacing="0">
	<tr>
	<th style="font-size:18px;"><b>Itinerary Information</b></th>
	</tr>
</table>
<table cellspacing="0" border="1"  >
    <tr style="background-color:#87ceeb;color:#000;">
	    <th style="width:30mm">&nbsp;&nbsp;Flight #</th>
	    <th style="width:25mm">&nbsp;&nbsp;From</th>
	    <th style="width:25mm">&nbsp;&nbsp;To</th>
	    <th style="width:25mm">&nbsp;&nbsp;Depart</th>
	    <th style="width:25mm">&nbsp;&nbsp;Arrive</th>
	    <th style="width:10mm">&nbsp;&nbsp;Seat</th>
	    <th style="width:50mm">&nbsp;&nbsp;Info</th>
    </tr>
    <tr>
    	<th>&nbsp;&nbsp;$TicketData->flight_name   $TicketData->flight_code</th>
    	<th>&nbsp;&nbsp;$TicketData->from_country  </th>
    	<th>&nbsp;&nbsp;$TicketData->to_country  </th>
    	<th>&nbsp;&nbsp;$TicketData->Depart </th>
    	<th>&nbsp;&nbsp;$TicketData->Arrive  </th>
    	<th> </th>
    	<th>
    	&nbsp;&nbsp;Baggage: $TicketData->baggage<br>
    	&nbsp;&nbsp;Class: $TicketData->class<br>
    	&nbsp;&nbsp;Duration: $TicketData->duration<br>
    	&nbsp;&nbsp;Status: Completed<br>
    	&nbsp;&nbsp;Aircraft: $TicketData->aircraft<br>
    	&nbsp;&nbsp;Special Svc: 
    	</th>
    </tr>
</table>


EOD;

$pdf->writeHTML($tbl, true, false, false, false, );


//$pdf->Image('1', 100, 100, 10 , 0, 'png', '', '', false, 300, '', false, false, 0, 'LB', false, false);


//$pdf->writeHTMLCell(74,0,10,100,'<P>Header OF VOUCHAR<P>',1,1); //HEADER..

//$pdf->writeHTMLCell(190,0,12,40,'<b>From : '.$fromdate.'</b>',0,0); 
//$pdf->writeHTMLCell(190,0,12,45,'<b>To &nbsp; &nbsp; : '.$todate.'</b>',0,0); 

$pdf->writeHTMLCell(190,0,12,0,'',0,0); 
//$pdf->writeHTMLCell(190,0,10,225,'<P>FOOTER OF VOUCHAR<P>',1,1); //FOOTER..

//$pdf->Image('1.png',10,261,74,15);

//output / result..
$pdf->Output(); 