<!-- page content -->
            <div class="right_col" role="main">
                <div class="">
                    <div class="clearfix"></div>
                    <div class="row">
                        <div class="col-md-12 col-sm-12">
                            <div class="x_panel" style="background-color: #eee;">
                                <div class="x_title">
                                    <h2>Ticket Booking Add 
                            <a  href="<?php echo base_url('')?>Ticket" type="button" class="btn btn-round btn-primary">Ticket Booking </a> <small><?php echo $this->session->flashdata('smg');?></small></h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                        </li>
                                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content">
                                      <form action="<?php echo base_url('Ticket/AddAgentBookingTicket');?>" method="post">
                                      <div class="row">                    
                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align" style="color:red;">
                                            Vendor Select  <span class="required">*</span>
                                              </label>
                                              <div class="col-md-10 col-sm-6">
                                                 <select class="chosent form-control" name="vendor_id" required="">
                                                    <option value="" >Select Vendor</option> 
                                                  <?php 
                                                    foreach ($AllVendorData as $VendorData) {
                                                  ?>
                                                    <option value="<?php echo $VendorData->id;?>"  style="font-size: 16px;"><?php echo $VendorData->vendor_name;?>/<?php echo $VendorData->vendor_id;?>/<?php echo $VendorData->company_name;?>/<?php echo $VendorData->phone;?></option>
                                                  <?php
                                                      }  
                                                  ?>
                                                  </select>
                                      <script type="text/javascript">$(".chosent").chosen(); </script>
                                              </div>
                                          </div>
                                        </div><!--end--->



                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align" style="color:red;">
                                              Customer  <span class="required">*</span>
                                              </label>
                                              <div class="col-md-10 col-sm-6">
                                                 <select class="chosent form-control" name="agent_id" required="">
                                                    <option value="" >Select Customer</option> 
                                                 <?php 
                                                    foreach ($AllAgentList as $AgentData) {
                                                  ?>
                                                    <option value="<?php echo $AgentData->id;?>" style="font-size: 16px;"><?php echo $AgentData->agent_name;?>/<?php echo $AgentData->agent_id;?>/<?php echo $AgentData->mobile_no;?></option>
                                                  <?php
                                                      }  
                                                  ?>
                                                  </select>
                                      <script type="text/javascript">$(".chosent").chosen(); </script>
                                              </div>
                                          </div>
                                        </div><!--end--->

                                        <!--start -->
                                        <div class="col-md-6">
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">First Name<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" data-validate-length-range="6" data-validate-words="2" name="first_name" required="required" />
                                              </div>
                                          </div>
                                        </div>
                                        <!--end -->
                                        
                                        <!--start -->
                                        <div class="col-md-6">
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align" >Last Name<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" data-validate-length-range="6" data-validate-words="2" name="last_name" required="required" />
                                              </div>
                                          </div>
                                        </div>
                                        <!--end -->

                                        <!--start -->
                                        <div class="col-md-6">
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Passport No<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" data-validate-length-range="6" data-validate-words="2" name="passport_no" required="required" />
                                              </div>
                                          </div>
                                        </div>
                                        <!--end -->

                                      <div class="col-md-6">
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Ticket Number<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" data-validate-length-range="6" data-validate-words="2" name="ticket_no" required="required" />
                                              </div>
                                          </div>
                                        </div>
                                        
                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align" style="color:red;">AirLine PNR<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" class='optional' name="a_ticket_pnr"  type="text"     required="required" />
                                                </div>
                                          </div>
                                        </div><!--end--->   

                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align" style="color:red;">Galileo PNR<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" class='optional' name="g_ticket_pnr"  type="text"     required="required" />
                                                </div>
                                          </div>
                                        </div><!--end--->

                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">
                                               Flight#  <span class="required">*</span>
                                              </label>
                                              <div class="col-md-10 col-sm-6">
                                                 <select class="chosent form-control" name="flight_name" >
                                                    <option value="" >Select Flight</option>
                                                    
  <option value="INDIGO AIRLINES">INDIGO AIRLINES</option>
  <option value="AIR CANADA">AIR CANADA</option>
  <option value="AIR FRANCE">AIR FRANCE</option>
  <option value="AIR INDIA">AIR INDIA</option>
  <option value="AIRASIA SDSN BHD">AIRASIA SDSN BHD</option>
  <option value="ROYAL AIR MAROCBIMAN BANGLADESH">ROYAL AIR MAROCBIMAN BANGLADESH</option>
  <option value="BIMAN BANGLADESH">BIMAN BANGLADESH</option>
  <option value="ROYAL BRUNEI">ROYAL BRUNEI</option>
  <option value="US BANGLA AIRLINES">US BANGLA AIRLINES</option>
  <option value="CATHAY PACIFICCHINA SOUTHERN">CATHAY PACIFICCHINA SOUTHERN</option>
  <option value="CHINA SOUTHERN">CHINA SOUTHERN</option>
  <option value="DELTA AIR LINES">DELTA AIR LINES</option>
  <option value="EMIRATES">EMIRATES</option>
  <option value="ETIHAD AIRWAYSFLYDUBAIGULF AIRAPG AIRLINESHIMALAYA AIRLIN"></option>
  <option value="FLYDUBAIGULF AIRAPG AIRLINESHIMALAYA AIRLIN">FLYDUBAIGULF AIRAPG AIRLINESHIMALAYA AIRLIN</option>
  <option value="GULF AIRAPG AIRLINESHIMALAYA AIRLIN">GULF AIRAPG AIRLINESHIMALAYA AIRLIN</option>
  <option value="APG AIRLINESHIMALAYA AIRLIN">APG AIRLINESHIMALAYA AIRLIN</option>
  <option value="HIMALAYA AIRLIN">HIMALAYA AIRLIN</option>
  <option value="JAZEERA AIRWAYS">JAZEERA AIRWAYS</option>
  <option value="KUWAIT AIRWAYSMALAYSIA AIRLINAIR MAURITIUS">KUWAIT AIRWAYSMALAYSIA AIRLINAIR MAURITIUS</option>
  <option value="MALAYSIA AIRLINAIR ">MALAYSIA AIRLINAIR </option>
  <option value="AIR MAURITIUS">AIR MAURITIUS</option>
  <option value="EGYPTAIR">EGYPTAIRCHINA EASTERN A</option>
  <option value="CHINA EASTERN A">CHINA EASTERN A</option>
  <option value="MALINDO AIRWAYS">MALINDO AIRWAYS</option>
  <option value="SALAM AIR">SALAM AIR</option>
  <option value="BANGKOK AIRWAYS">BANGKOK AIRWAYS</option>
  <option value="QATAR AIRWAYS">QATAR AIRWAYS</option>
  <option value="SPICE JET">SPICE JET</option>
  <option value="THAI LION AIR">THAI LION AIR</option>
  <option value="SINGAPORE AIRLI">SINGAPORE AIRLI</option>
  <option value="SAUDI ARABIAN A">SAUDI ARABIAN A</option>
  <option value="THAI AIRWAYS IN">THAI AIRWAYS IN</option>
  <option value="TURKISH AIRLINE">TURKISH AIRLINE</option>
  <option value="VISTARA">VISTARA</option>
  <option value="SRILANKAN AIRLI">SRILANKAN AIRLI</option>
  <option value="NOVO AIR">NOVO AIR</option>
  <option value="OMAN AIR">OMAN AIR</option>
                                                  </select>
                                      <script type="text/javascript">$(".chosent").chosen(); </script>
                                              </div>
                                            </div>
                                        </div><!--end--->       

                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Flight Code<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" class='optional' name="flight_code"  type="text"   />
                                              </div>
                                          </div>
                                        </div><!--end--->
                                        
                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">From <span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" class='optional' name="from_country"  type="text"   />
                                              </div>
                                          </div>
                                        </div><!--end--->  

                                      <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">To <span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" class='optional' name="to_country"  type="text"   />
                                              </div>
                                          </div>
                                        </div><!--end--->

                                         <div class="col-md-6">
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Issue Date<span class="required">*</span></label>
                                                  <div class="col-md-10 ">
                                                      <input type="date" class="form-control has-feedback-left" name="d_of_issue">
                                                    </div>
                                          </div>
                                        </div>

                                        <div class="col-md-6">
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Flight Date<span class="required">*</span></label>
                                                  <div class="col-md-10 ">
                                                      <input type="date" class="form-control has-feedback-left"  name="flight_date"  required="required" >
                                                    </div>
                                          </div>
                                        </div>
                                        
                                   
                                         <div class="col-md-6">
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Depart Date<span class="required">*</span></label>
                                                <div class="col-md-10 ">
                                                   <input type="text" class="form-control"  name="Depart"  >
                                               </div>
                                          </div>
                                        </div>

                                        <div class="col-md-6">
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Arrive Date<span class="required">*</span></label>
                                                  <div class="col-md-10 ">
                                                      <input type="text" class="form-control has-feedback-left"   name="Arrive"  required="required" >
                                                    </div>
                                          </div>
                                        </div>

                                        <div class="col-md-6"> 
                                          <div class="field item form-group">
                                           <label class="col-form-label col-md-2 col-sm-3  label-align">Baggage<span
                                        class="required">*</span></label>
                                         <div class="col-md-10 "> 
                                        <input type=""  class="form-control" name="baggage">
                                      </div> 
                                    </div> 
                                  </div> 

                                        <div class="col-md-6">
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Class<span class="required">*</span></label>
                                                  <div class="col-md-10 ">
                                                      <select class="form-control" name="class">
                                                        <option value="">Select Class </option>
                                                        <option value="First Class">First Class </option>
                                                        <option value="Business Class">Business Class </option>
                                                        <option value="Economy Class">Economy Class </option>
                                                      </select>
                                                    </div>
                                          </div>
                                        </div> 
                                        
                                        <div class="col-md-6">
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align" style="color:red">Duration<span class="required">*</span></label>
                                                  <div class="col-md-10 ">
                                                      <input type="text" class="form-control has-feedback-left"   name="duration"  required="required" >
                                                    </div>
                                          </div>
                                        </div> 
                                        
                                        <div class="col-md-6">
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align" style="color:red">Aircraft<span class="required">*</span></label>
                                                  <div class="col-md-10 ">
                                                      <input type="text" class="form-control has-feedback-left"  name="aircraft"  required="required" >
                                                    </div>
                                          </div>
                                        </div> <!--end--->
                                 
                                        
                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group" style="color:red">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align"  style="color:red"> Vendor Bill Amount<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" class='optional' name="bill_amount"  type="number"    required="required"  />
                                                </div>
                                          </div>
                                        </div><!--end---> 
                                        
                                         <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align"  style="color:red"> Customer Bill Amount <span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" class='optional' name="agent_bill"  type="number"  required="required" />
                                                </div>
                                          </div>
                                        </div><!--end--->

                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Issue & Reissue<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                              <select class="form-control" name="issue_reissue">
                                                  <option value="">Select Issue And Reissue</option>
                                                  <option value="Issue">Issue</option>
                                                  <option value="Reissue">Reissue</option>
                                                  <option value="Direct Passernger">Direct passernger</option>
                                                </select>
                                                </div>
                                          </div>
                                        </div><!--end--->   

                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Remark<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" class='optional' name="remark"  type="text"   />
                                                </div>
                                          </div>
                                        </div><!--end--->

                                      </div><!---ROW END-->
                            
                     
                                        <div class="ln_solid">
                                            <div class="form-group">
                                                <div class="col-md-6 offset-md-3">
                                                    <button type="submit" class="btn btn-info">Save</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <!-- /page content -->