    <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="clearfix"></div>
    <h2><?php echo $this->session->flashdata('smgdu');?></h2>
            <div class="row">
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2> All Ticket Passenger </h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="#">Settings 1</a>
                            <a class="dropdown-item" href="#">Settings 2</a>
                          </div>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      <div class="row">
                          <div class="col-sm-12">
                            <div class="card-box table-responsive">
                    <table id="datatable-buttons" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                        <tr>
                          <th>Id</th>
                          <th>Passenger Name</th>
                          <th>Passport No</th>
                          <th>Ticket No</th>
                          <th>Issue Date</th>
                          <th>Action</th>
                        </tr>
                      </thead>


                      <tbody>
                      <?php
                          $sl=0;
                        foreach ($AllPassengerData as $PassengerData) {
                          $sl++;
                      ?>

                        <tr>
                          <td><?php echo $sl;?></td>
                          <td><?php echo $PassengerData->first_name.$PassengerData->last_name;?></td>
                          <td><?php echo $PassengerData->passport_no;?></td>
                          <td><?php echo $PassengerData->ticket_no;?></td>
                          <td><?php echo $PassengerData->d_of_issue;?></td>
                          <td style="width:30%;">
                            <a href="" class="btn btn-round btn-primary btn-xs"  data-toggle="modal" data-target="#PassengerView<?php echo $PassengerData->id;?>"  >View</a>
                            <a href="" class="btn btn-round btn-warning btn-xs" data-toggle="modal" data-target="#PassengerEdit<?php echo $PassengerData->id;?>" >Edit</a>
                            <a href="" class="btn btn-round btn-danger btn-xs"  data-toggle="modal" data-target="#Remove<?php echo $PassengerData->id;?>">Remove</a>
                          </td>
                        </tr>



<!--- Passenger View  Completed  model  ---->
<div class="modal fade" id="PassengerView<?php echo $PassengerData->id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="myModalLabel"> Customer Name:##<?php echo $PassengerData->first_name;?> </h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body">
          <form action="<?php echo base_url('Customer/ProcessingALlCompleteCustomer/')?><?php echo $PassengerData->id;?>" method="post">

            <div class="field item form-group">
              <input class="form-control" value="<?php echo $PassengerData->first_name.$PassengerData->last_name; ?>" readonly>
           </div><!--end-->
            <div class="field item form-group">
              <input class="form-control" value="Passport No: <?php echo $PassengerData->passport_no; ?>" readonly>
           </div><!--end-->
            <div class="field item form-group">
              <input class="form-control" value="Ticket No :<?php echo $PassengerData->ticket_no; ?>" readonly>
           </div><!--end-->
            <div class="field item form-group">
              <input class="form-control" value="AirLine PNR :<?php echo $PassengerData->a_ticket_pnr; ?>" readonly>
           </div><!--end-->
            <div class="field item form-group">
              <input class="form-control" value="Galileo PNR :<?php echo $PassengerData->g_ticket_pnr; ?>" readonly>
           </div><!--end-->
            <div class="field item form-group">
              <input class="form-control" value="Issue Date :<?php echo $PassengerData->d_of_issue; ?>" readonly>
           </div><!--end-->
            <div class="field item form-group">
              <input class="form-control" value="Flight Date :<?php echo $PassengerData->flight_date; ?>" readonly>
           </div><!--end-->
            <div class="field item form-group">
              <input class="form-control" value="Flight Name :<?php echo $PassengerData->flight_name.$PassengerData->flight_code; ?>" readonly>
           </div><!--end-->
            <div class="field item form-group">
              <input class="form-control" value="Form :<?php echo $PassengerData->from_country; ?>" readonly>
           </div><!--end-->
            <div class="field item form-group">
              <input class="form-control" value="To : <?php echo $PassengerData->to_country; ?>" readonly>
           </div><!--end-->
            <div class="field item form-group">
              <input class="form-control" value="Depart : <?php echo $PassengerData->Depart; ?>" readonly>
           </div><!--end-->
            <div class="field item form-group">
              <input class="form-control" value="Arrive : <?php echo $PassengerData->Arrive; ?>" readonly>
           </div><!--end-->
            <div class="field item form-group">
              <input class="form-control" value="Baggage : <?php echo $PassengerData->baggage; ?>" readonly>
           </div><!--end-->
            <div class="field item form-group">
              <input class="form-control" value="Class : <?php echo $PassengerData->class; ?>" readonly>
           </div><!--end-->
            <div class="field item form-group">
              <input class="form-control" value="Duration : <?php echo $PassengerData->duration; ?>" readonly>
           </div><!--end-->
            <div class="field item form-group">
              <input class="form-control" value="Aircraft : <?php echo $PassengerData->aircraft; ?>" readonly>
           </div><!--end-->
         </form>
      </div>
    </div>
  </div>
</div>
<!--- model end ----->

<!--Ticket passenger Edit-->


<!--- Passenger View  Completed  model  ---->
<div class="modal fade" id="PassengerEdit<?php echo $PassengerData->id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="myModalLabel"> Ticket Name:##<?php echo $PassengerData->first_name;?> </h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body">
          <form action="<?php echo base_url('Ticket/TicketPassengerEdit/')?><?php echo $PassengerData->id;?>" method="post">

            <input class="form-control" type="hidden" value="<?php echo $PassengerData->id; ?>" name="id">

            <div class="field item form-group">
              <label>First Name</label>
              <input class="form-control" value="<?php echo $PassengerData->first_name.$PassengerData->last_name; ?>" name="first_name">
           </div><!--end-->

            <div class="field item form-group">
              <label>Last Name</label>
              <input class="form-control" name="last_name" value="<?php echo $PassengerData->last_name; ?>">
           </div><!--end-->

            <div class="field item form-group">
              <label> Passport No</label>
              <input class="form-control" value="<?php echo $PassengerData->passport_no; ?>" name="passport_no" >
           </div><!--end-->

            <div class="field item form-group">
              <label>Ticket No :</label>
              <input class="form-control" value="<?php echo $PassengerData->ticket_no; ?>" name="ticket_no">
           </div><!--end-->

            <div class="field item form-group">
              <label>AirLine PNR</label>
              <input class="form-control" value="<?php echo $PassengerData->a_ticket_pnr; ?>" name="a_ticket_pnr">
           </div><!--end-->

            <div class="field item form-group">
              <label>Galileo PNR</label>
              <input class="form-control" value="<?php echo $PassengerData->g_ticket_pnr; ?>" name="g_ticket_pnr">
           </div><!--end-->

            <div class="field item form-group">
              <label> Issue Date</label>
              <input class="form-control" value="<?php echo $PassengerData->d_of_issue; ?>" name="d_of_issue">
           </div><!--end-->

            <div class="field item form-group">
              <label> Flight Date</label>
              <input class="form-control" value="<?php echo $PassengerData->flight_date; ?>" name="flight_date">
           </div><!--end-->

            <div class="field item form-group">    
              <label> Flight name</label>
              <input class="form-control" value="<?php echo $PassengerData->flight_name; ?>" name="first_name">
           </div><!--end-->

            <div class="field item form-group">    
              <label> Flight name</label>
              <input class="form-control" value="<?php echo $PassengerData->flight_code; ?>" name="flight_code">
           </div><!--end-->

            <div class="field item form-group">
              <label>Form :</label>
              <input class="form-control" name="from_country" value="<?php echo $PassengerData->from_country; ?>">
           </div><!--end-->

            <div class="field item form-group">
              <label> Passport No</label>
              <input class="form-control" name="to_country" value="<?php echo $PassengerData->to_country; ?>">
           </div><!--end-->

            <div class="field item form-group">
              <label>Depart</label>
              <input class="form-control" value="<?php echo $PassengerData->Depart; ?>" name="Depart">
           </div><!--end-->

            <div class="field item form-group">
              <label>Arrive</label>
              <input class="form-control" value="<?php echo $PassengerData->Arrive; ?>" name="Arrive">
           </div><!--end-->

            <div class="field item form-group">
              <label>Baggage</label>
              <input class="form-control" value="<?php echo $PassengerData->baggage; ?>" name="baggage" >
           </div><!--end-->

            <div class="field item form-group">
              <label>Class </label>
              <input class="form-control" name="class" value="<?php echo $PassengerData->class; ?>" >
           </div><!--end-->

            <div class="field item form-group">
              <label>Duration</label>
              <input class="form-control" name="duration" value="<?php echo $PassengerData->duration; ?>" >
           </div><!--end-->

            <div class="field item form-group">
              <label >Aircraft</label>
              <input class="form-control" name="aircraft" value="<?php echo $PassengerData->aircraft; ?>" >
           </div><!--end-->
             <div class="ln_solid">
            <div class="form-group">
               <div class="col-md-6 offset-md-3">
                   <button type='submit' class="btn btn-primary">Yes</button>
                    <button type='reset' class="btn btn-success">No</button>
                 </div>
            </div>
          </div>
         </form>
      </div>
    </div>
  </div>
</div>
<!--- model end ----->






<!--- remove model  ---->
<div class="modal fade" id="Remove<?php echo $PassengerData->id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="myModalLabel"> Agent Name:##<?php echo $PassengerData->first_name.$PassengerData->last_name;?> </h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body">

<form action="<?php echo base_url('Ticket/PassengerRemove/')?><?php echo $PassengerData->id;?>" method="post">
          <div class="field item form-group">
            <label class="col-form-label col-md-12 col-sm-3  label-align" style="color:red;font-size: 1.3rem;font-weight: 900;text-align: center;">  Are You Sure ? Remove It. </label>
         </div>     

          <div class="ln_solid">
            <div class="form-group">
               <div class="col-md-6 offset-md-3">
                   <button type='submit' class="btn btn-primary">Yes</button>
                    <button type='reset' class="btn btn-success">No</button>
                 </div>
            </div>
          </div>
         </form>
      </div>
    </div>
  </div>
</div>
<!--- model end ----->

             <?php  } ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
                </div>
              </div>

            </div><!--end row-->
          </div>
        </div>
        <!-- /page content -->