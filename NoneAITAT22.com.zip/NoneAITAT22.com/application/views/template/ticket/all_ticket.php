    <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="clearfix"></div>
    <h2><?php echo $this->session->flashdata('smgdu');?></h2>
            <div class="row">
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>All Ticket</h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="#">Settings 1</a>
                            <a class="dropdown-item" href="#">Settings 2</a>
                          </div>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      <div class="row">
                          <div class="col-sm-12">
                            <div class="card-box table-responsive">
                    <table id="datatable-buttons" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                        <tr>
                          <th> Id</th>
                          <th>Type</th>
                          <th>Vendor Name</th>
                          <th>Customer Name</th>
                          <th>Passenger Descriptions </th>
                          <th>Issue Reissue </th>
                          <th>V B Amount</th>
                          <th>C B Amount</th>
                          <th>Payment Amount</th>
                          <th>Action</th>
                        </tr>
                      </thead>


                      <tbody>
                      <?php
                          $sl=0;
                        foreach ($AllTicketData as $TicketData) {
                          $sl++;

                      ?>

                        <tr>
                          <td><?php echo $sl;?></td>
                          <td style="width: 6%;"> <?php echo $TicketData->type;?></td>
                          <td>
                            <?php 
                            if ($TicketData->vendor_id == null) {
                            ?>

                            <?php 
                            }else{
                            ?>

                            <?php
                              $vendorname = $this->Payment_model->vendor_info_for_invoice($TicketData->vendor_id);
                                echo $vendorname->vendor_name;
                             ?>

                            <?php
                            }
                             ?>
                          </td>
                          <td>

                            <?php 
                            if ($TicketData->agent_id == null) {
                            ?>
                              
                            <?php 
                            }else{
                            ?>

                            <?php 
                              $AgentName = $this->Payment_model->Agent_info_for_invoice($TicketData->agent_id);
                              echo $AgentName->agent_name;
                             ?>
                           <?php }?>
                          </td>
                          <?php 
                              if ($TicketData->type == 'New Ticket') {
                           ?>

                          <td style="width: 35%;">
          <?php $PassengerData = $this->Ticket_model->PassengerDataGetById($TicketData->passenger_id); ?> 
                            <b>Passenger Name :</b>
                            <?php echo $PassengerData->first_name.$PassengerData->last_name; ?>
                            <b>P.P</b><?php echo $PassengerData->passport_no;?>
                            <b>Ticket No</b><?php echo $PassengerData->ticket_no;?>
                            <b>AirLine PNR</b><?php echo $PassengerData->a_ticket_pnr;?>
                            <b>Galileo PNR</b><?php echo $PassengerData->g_ticket_pnr;?>
                            <b>Issue Date </b> <?php echo $PassengerData->d_of_issue;?>
                            <br>
                            <?php if ($TicketData->remark) {echo '<b>Remark:</b>'.$TicketData->remark;}else{ echo '';} ?>

                          </td>

                           <?php
                              }else{
                          ?>
                          <td>

                           
<b>Date :</b> <?php echo date('dS M Y', strtotime($TicketData->payment_date));?>,<b> Payment Method :</b> <?php echo $TicketData->payment_method;?>,
<?php 
    if ($TicketData->bank_name) {echo '<b>Bank Name:</b>'.$TicketData->bank_name; echo '<b> Account Number : </b>'.$TicketData->account_number;}elseif ($TicketData->bkash_n) {echo  '<b>Bkash Number : </b>'. $TicketData->bkash_n;}elseif ($TicketData->rocket_n) {echo  '<b>Rocket Number : </b>'.$TicketData->rocket_n;}elseif ($TicketData->nogod_n) {echo  '<b>Nogod Number : </b>'. $TicketData->nogod_n;}
?>
                             
<?php   if ($TicketData->remark) {echo '<b>Remark:</b>'.$TicketData->remark;}else{ echo '';} ?>
                          </td> 
                          <?php
                              }
                          ?>


                          <td style="text-align: right;"><?php echo $TicketData->issue_reissue;?></td>  

                          <td style="text-align: right;"><?php echo $TicketData->bill_amount;?></td>
                          <td style="text-align: right;"><?php echo $TicketData->agent_bill;?></td>
                          <td style="text-align: right;"><?php echo $TicketData->payment_amount;?></td>
                          <td style="text-align: center;">
                          <!--  <a href="<?php echo base_url('Ticket/Updateprofille/')?><?php echo $TicketData->id;?>" class="btn btn-round btn-warning btn-xs">Edit</a>-->
                            <a href="" class="btn btn-round btn-danger btn-xs" data-toggle="modal" data-target="#Remove<?php echo $TicketData->id;?>" >Remove</a>
                          </td>
                        </tr>

<!--- remove model  ---->
<div class="modal fade" id="Remove<?php echo $TicketData->id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="myModalLabel">Passenger Name:<?php echo $TicketData->passenger_name;?> </h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body">

<form action="<?php echo base_url('Ticket/RemoveTicket/');?><?php echo $TicketData->id;?>" method="post">
          <div class="field item form-group">
            <label class="col-form-label col-md-12 col-sm-3  label-align" style="color:red;font-size: 1.3rem;font-weight: 900;text-align: center;">  Are You Sure ? Remove It. </label>
         </div>     

          <div class="ln_solid">
            <div class="form-group">
               <div class="col-md-6 offset-md-3">
                   <button type='submit' class="btn btn-primary">Yes</button>
                    <button type='reset' class="btn btn-success">No</button>
                 </div>
            </div>
          </div>
         </form>
      </div>
    </div>
  </div>
</div>
<!--- model end ----->
                      <?php
                        }
                      ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
                </div>
              </div>

            </div><!--end row-->
          </div>
        </div>
        <!-- /page content -->