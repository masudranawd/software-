
            <!-- page content -->
            <div class="right_col" role="main">
                <div class="">
                    <!--<div class="page-title">
                        <div class="title_left">
                            <h3>Form Validation</h3>
                        </div>

                        <div class="title_right">
                            <div class="col-md-5 col-sm-5 form-group pull-right top_search">
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search for...">
                                    <span class="input-group-btn">
                                        <button class="btn btn-default" type="button">Go!</button>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>-->
                    <div class="clearfix"></div>

  <?php echo $this->session->flashdata('smg');?>
                    <div class="row">

                        <div class="col-md-12 col-sm-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>Customer<small>Search</small></h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                        </li>
                                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content">
                                    <form class="" action="<?php echo base_url('Accounts/CustomerSearch');?>" method="post" novalidate>
                                  
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-3 col-sm-3  label-align"><?php echo "Serail Number"?><span class="required">*</span></label>
                                              <div class="col-md-5 col-sm-6">
                                                  <input class="form-control" data-validate-length-range="6" data-validate-words="2" name="serial_no" required="required" />
                                              </div>

                                        <div class="col-md-4 col-sm-6">
                                            <div class="form-group">
                                                <div class="col-md-4 offset-md-3">
                                                    <button type='submit' class="btn btn-secondary sourc">Submit</button>
                                                </div>
                                            </div>
                                           
                                        </div>
                                          </div>

                                    </form>
                                </div>
                            </div>
</div>

  <?php 
   if($CustomerAccounts == !null){
  ?>
  <div class="col-md-12 col-sm-12">
                          <!---table----->
                <div class="x_panel">
                  <div class="x_title">
                    <h2> Customer Information<small></small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>

                  <div class="x_content">
                    <div class="table-responsive">
                      <table class="table table-striped jambo_table bulk_action">
                        <thead>
                          <tr class="headings">
                            <th class="column-title" style="display: table-cell;">SL </th>
                            <th class="column-title" style="display: table-cell;">Name</th>
                            <th class="column-title" style="display: table-cell;">Visa No</th>
                            <th class="column-title" style="display: table-cell;">Passport No</th>
                            <th class="column-title" style="display: table-cell;">ID No </th>
                            <th class="column-title" style="display: table-cell;">Kapil No </th>
                          </tr>
                        </thead>

                        <tbody>

                      <?php 
                          // var_dump($AllvisaCategory);
                          $sl = 0;
                            foreach ($CustomerAccounts as $CustomerInfo) {
                              $sl++;
                             // var_dump($CustomerAccounts);die();
                          ?>
                          <tr class="even pointer">
                            <td class="a-center ">
                            <?php 
                              if($CustomerInfo->customer_image ==null){
                              ?>
                              <img src="<?php echo base_url();?>images/img.jpg" alt="..." class="img-circle profile_img" style="width:40px;margin:0px;" >
                            <?php
                              }elseif($CustomerInfo->customer_image){
                            ?>
                              <img src="<?php echo base_url();?>images/customer/<?php echo $CustomerInfo->customer_image ;?>" alt="..." class="img-circle profile_img" style="width:40px;margin:0px;" >
                            <?php
                              }
                            ?>
                              </td>
                            <td class=" "><?php echo $CustomerInfo->fullname;?></td>
                            <td class=" "><?php echo $CustomerInfo->visa_no;?></td>
                            <td class=" "><?php echo $CustomerInfo->passport_no;?></td>
                            <td class=" "><?php echo $CustomerInfo->id_no;?></td>
                            <td class=" "><?php echo $CustomerInfo->kapil_no;?></td>
                            </td>
                          </tr>
                          <?php
                            }
                          ?>

                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
          </div><!-- end col-md-6-->

<?php  
  if(empty($Voucherdata->id)){
    $voucher_no = 'INV000001';
  }else{
    $voucher_no = 'INV'.sprintf("%06d",$Voucherdata->id+1);
  }
?>

                        <div class="col-md-12 col-sm-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>Payment<small>ADD</small> &nbsp;&nbsp;<b>##<?php echo $voucher_no;?></b></h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                        </li>
                                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content">
                                    <form class="" action="<?php echo base_url('Accounts/AddNewPayment');?>" method="post" novalidate target="-blank">
                                  <input type="hidden" name="customer_id" value="<?php echo $CustomerInfo->id;?>">
                                  <input type="hidden" name="voucher_no" value="<?php echo $voucher_no;?>">
                                        
                                         <div class="col-md-3">
                                          <div class="field item form-group">
                                                  <div class="col-md-12">
                                                      <input type="text" class="form-control has-feedback-left" id="single_cal4" placeholder="First Name" name="payment_date" aria-describedby="inputSuccess2Status4">
                                                      <span class="fa fa-calendar-o form-control-feedback left" aria-hidden="true"></span>
                                                      <span id="inputSuccess2Status4" class="sr-only">(success)</span>
                                                    </div>
                                          </div>
                                        </div>

                                         <div class="col-md-3">
                                          <div class="field item form-group">
                                                  <div class="col-md-12">
                                                    <select class="form-control" name="payment_type" required>
                                                        <option>Select Deposit Or Expenses </option>
                                                        <option value="Deposit">Deposit</option>
                                                        <option value="Expense">Expenses</option>
                                                    </select>
                                                    </div>
                                          </div>
                                        </div>

                                      <div class="col-md-3"><!--start--->
                                          <div class="field item form-group">
                                              <div class="col-md-12 col-sm-6" style="margin-top: -8px;">
                                                 <select class="chosen form-control" name="for_payment" required>
                                                    <option>Select CashIn Category</option> 
                                                    <?php 
                                                        foreach($AllCashInCatData as $CashInCatData){
                                                    ?>
                                                    <option value="<?php echo $CashInCatData->name;?>"><?php echo $CashInCatData->name;?></option>
                                                    <?php
                                                        }
                                                    ?>
                                                  </select>
                                              </div>
                          <script type="text/javascript">$(".chosen").chosen(); </script>
                                          </div>
                                        </div><!--end--->

                                      <div class="col-md-3"><!--start--->
                                          <div class="field item form-group">
                                              <div class="col-md-12 col-sm-6" style="margin-top: -8px;">
                                                 <select class="chosen form-control" name="method" required>
                                                    <option style="background-color: #000;">Select Payment method</option>
                                                    <option value="Cash In">Cash In</option>
                                                    <option value="Bkash">Bkash</option>
                                                    <option value="Rocket">Rocket</option>
                                                    <option value="Nogod">Nogod</option>
                                                    <option value="PayOrder">Pay Order</option>
                                                    <option value="Bank Check">Bank check</option>
                                                  </select>
                                              </div>
                          <script type="text/javascript">$(".chosen").chosen(); </script>
                                          </div>
                                        </div><!--end--->

                                        <div class="col-md-12"><!--start--->
                                          <div class="field item form-group" >
                                              <div class="col-md-12 col-sm-6" >
                                                  <input class="form-control" class='optional' name="payment"  type="number"    required="required" placeholder="Enter Amount" style="background-color: #000;color:#fff;"/>
                                                </div>
                                          </div>
                                        </div><!--end--->
                                      </div>
                                        <div class="">
                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <div class="col-md-12 col-sm-6">
                                                  <input class="form-control" class='optional' name="bank_name"  type="text"   placeholder="optional Bank name" />
                                                </div>
                                          </div>
                                        </div><!--end--->

                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <div class="col-md-12 col-sm-6">
                                                  <input class="form-control" class='optional' name="bank_recepit_n"  type="text"   placeholder="bank receipt number" />
                                                </div>
                                          </div>
                                        </div><!--end--->
                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <div class="col-md-12 col-sm-6">
                                                  <input class="form-control" class='optional' name="bkash_n"  type="text"   placeholder="optional Bkash number" />
                                                </div>
                                          </div>
                                        </div><!--end--->
                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <div class="col-md-12 col-sm-6">
                                                  <input class="form-control" class='optional' name="rocket_n"  type="text"   placeholder=" Optional Rocket number" />
                                                </div>
                                          </div>
                                        </div><!--end--->

                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <div class="col-md-12 col-sm-6">
                                                  <input class="form-control" class='optional' name="details"  type="text"   placeholder=" Optional Details" />
                                                </div>
                                          </div>
                                        </div><!--end--->

                                        <div class="col-md-3">
                                          <div class="field item form-group">
                                              <div class="col-md-12 col-sm-6">
                                                  <button type='submit' class="btn btn-success  sourc">Save</button>
                                                  <button type='reset' class="btn btn-secondary">Reset</button>
                                              </div> 
                                          </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
  <?php echo $this->session->flashdata('smg');?>
                          <!---table----->
      <?php
          }else{
      ?>
    
<?php  
  if(empty($Voucherdata->id)){
    $voucher_no = 'INV000001';
  }else{
    $voucher_no = 'INV'.sprintf("%06d",$Voucherdata->id+1);
  }
?>

                        <div class="col-md-12 col-sm-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>Old Customer Payment<small>ADD</small> &nbsp;&nbsp;<b>##<?php echo $voucher_no;?></b></h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                        </li>
                                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content">
                                    <form class="" action="<?php echo base_url('Accounts/AddOlcustomerNewPayment');?>" method="post" novalidate target="-blank">
                                  <input type="hidden" name="voucher_no" value="<?php echo $voucher_no;?>">
                                        
                                         <div class="col-md-6">
                                          <div class="field item form-group">
                                                  <div class="col-md-12">
                                                      <input type="text" class="form-control " value="<?php echo $serial_no;?>" name="serial_no" readonly>
                                                   
                                                    </div>
                                          </div>
                                        </div>
                                    
                                         <div class="col-md-6">
                                          <div class="field item form-group">
                                                  <div class="col-md-12">
                                                      <input type="text" class="form-control has-feedback-left" id="single_cal4" placeholder="First Name" name="payment_date" aria-describedby="inputSuccess2Status4">
                                                      <span class="fa fa-calendar-o form-control-feedback left" aria-hidden="true"></span>
                                                      <span id="inputSuccess2Status4" class="sr-only">(success)</span>
                                                    </div>
                                          </div>
                                        </div>

                                         <div class="col-md-6">
                                          <div class="field item form-group">
                                                  <div class="col-md-12">
                                                    <select class="form-control" name="payment_type" required>
                                                        <option>Select Deposit Or Expenses </option>
                                                        <option value="Deposit">Deposit</option>
                                                        <option value="Expense">Expenses</option>
                                                    </select>
                                                    </div>
                                          </div>
                                        </div>

                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group" >
                                              <div class="col-md-12 col-sm-6" >
                                                  <input class="form-control" class='optional' name="payment"  type="number"    required="required" placeholder="Enter Amount" style="background-color: #000;color:#fff;"/>
                                                </div>
                                          </div>
                                        </div><!--end--->
                                        
                                      <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <div class="col-md-12 col-sm-6" >
                                                 <select class="chosen form-control" name="for_payment" required>
                                                    <option>Select CashIn Category</option> 
                                                    <?php 
                                                        foreach($AllCashInCatData as $CashInCatData){
                                                    ?>
                                                    <option value="<?php echo $CashInCatData->name;?>"><?php echo $CashInCatData->name;?></option>
                                                    <?php
                                                        }
                                                    ?>
                                                  </select>
                                              </div>
                          <script type="text/javascript">$(".chosen").chosen(); </script>
                                          </div>
                                        </div><!--end--->

                                      <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <div class="col-md-12 col-sm-6" style="margin-top: px;">
                                                 <select class="chosen form-control" name="method" required>
                                                    <option style="background-color: #000;">Select Payment method</option>
                                                    <option value="Cash In">Cash In</option>
                                                    <option value="Bkash">Bkash</option>
                                                    <option value="Rocket">Rocket</option>
                                                    <option value="Nogod">Nogod</option>
                                                    <option value="PayOrder">Pay Order</option>
                                                    <option value="Bank Check">Bank check</option>
                                                  </select>
                                              </div>
                          <script type="text/javascript">$(".chosen").chosen(); </script>
                                          </div>
                                        </div><!--end--->

                                      </div>
                                        <div class="">
                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <div class="col-md-12 col-sm-6">
                                                  <input class="form-control" class='optional' name="bank_name"  type="text"   placeholder="optional Bank name" />
                                                </div>
                                          </div>
                                        </div><!--end--->

                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <div class="col-md-12 col-sm-6">
                                                  <input class="form-control" class='optional' name="bank_recepit_n"  type="text"   placeholder="bank receipt number" />
                                                </div>
                                          </div>
                                        </div><!--end--->
                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <div class="col-md-12 col-sm-6">
                                                  <input class="form-control" class='optional' name="bkash_n"  type="text"   placeholder="optional Bkash number" />
                                                </div>
                                          </div>
                                        </div><!--end--->
                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <div class="col-md-12 col-sm-6">
                                                  <input class="form-control" class='optional' name="rocket_n"  type="text"   placeholder=" Optional Rocket number" />
                                                </div>
                                          </div>
                                        </div><!--end--->

                                        <div class="col-md-6"><!--start--->
                                          <div class="field item form-group">
                                              <div class="col-md-12 col-sm-6">
                                                  <input class="form-control" class='optional' name="details"  type="text"   placeholder=" Optional Details" />
                                                </div>
                                          </div>
                                        </div><!--end--->

                                        <div class="col-md-3">
                                          <div class="field item form-group">
                                              <div class="col-md-12 col-sm-6">
                                                  <button type='submit' class="btn btn-success  sourc">Save</button>
                                                  <button type='reset' class="btn btn-secondary">Reset</button>
                                              </div> 
                                          </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
      <?php
          }
      ?>
                                       
            
                    </div><!-- end row---->
                </div>
            </div>
            <!-- /page content -->



