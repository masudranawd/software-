<!-- page content -->
        <div class="right_col" role="main">
         <!--  top tiles -->
          <div class="row">
            <div class="col-md-4 col-sm-4  tile_stats_count btn-info" style="padding:30px; text-align:center" >
              <span class="count_top"><i class="fa fa-user"></i> Total Vendor</span>
              <div class="count"><?php if($TotalVendor){echo $TotalVendor;}else{echo '0';}?></div>
            </div>
            <div class="col-md-4 col-sm-4  tile_stats_count btn-success" style="padding:30px; text-align:center" >
              <span class="count_top"><i class="fa fa-user"></i> Total Customer </span>
              <div class="count"><?php if($TotalAgent){echo $TotalAgent;}else{echo '0';}?></div>
            </div>
            
            <div class="col-md-4 col-sm-4  tile_stats_count btn-info" style="padding:30px; text-align:center" >
              <span class="count_top"><i class="fa fa-user"></i> Total User</span>
              <div class="count "><?php if($TotalUser){echo $TotalUser;}else{echo '0';}?></div>
            </div>
            
            
          </div>
        </div>
          <!-- /top tiles -->


                </div>
                <!-- end of weather widget -->
              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->
