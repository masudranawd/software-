    <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="clearfix"></div>

            <div class="row">
              <div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2> All Customer List <?php echo $this->session->flashdata('smgdu');?></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      <div class="row">
                          <div class="col-sm-12">
                            <div class="card-box table-responsive">
                    <table id="datatable-buttons" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                        <tr>
                          <th style="text-align:center;">Id</th>
                          <th style="text-align:center;">C-Sl</th>
                          <th style="text-align:center;">Visa No</th>   
                          <th style="text-align:center;">Passport No</th>                         
                          <th style="text-align:center;">Customer Name</th>   
                          <th style="text-align:center;">Action</th>
                        </tr>
                      </thead>


                      <tbody>
                      <?php
                          $sl=0;
                        foreach ($AllCustomerList as $CustomerData) {
                          $sl++;
                          if($CustomerData->permission == '0'){
                      ?>

                        <tr>
                          <td style="width:2%;text-align:center;"><?php echo $sl;?></td>
                          <td style="width:8%;text-align:center;"><?php echo $CustomerData->serial_no;?></td>
                          <td style="width:8%;text-align:center;"><?php echo $CustomerData->visa_no;?></td>
                          <td style="width:14%;text-align:center;"><?php echo $CustomerData->passport_no;?></td>
                          <td style="width:14%;text-align:center;"><?php echo $CustomerData->fullname;?></td>

                          <td  style="text-align:center;">
                            <a href="#" class="btn btn-round btn-warning btn-xs"  data-toggle="modal" data-target="#visacat<?php echo $CustomerData->id;?>" >Add Status</a>

                            <a href="<?php echo base_url('Customer/Customer_profile/')?><?php echo $CustomerData->id;?>" class="btn btn-round btn-primary btn-xs" target="_blank">Profile View</a>
                           
                            <a href="#" class="btn btn-round btn-info btn-xs" data-toggle="modal" data-target="#Statusview<?php echo $CustomerData->id;?>" >Status View </a>
                          
                            <a href="#" class="btn btn-round btn-secondary btn-xs" data-toggle="modal" data-target="#processingcomplete<?php echo $CustomerData->id;?>">Completed</a>

                          </td>
                        </tr>


<!--- Processing Completed  model  ---->
<div class="modal fade" id="processingcomplete<?php echo $CustomerData->id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="myModalLabel"> Customer Name:##<?php echo $CustomerData->fullname;?> </h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body">

<form action="<?php echo base_url('Customer/ProcessingCompleteCustomer/')?><?php echo $CustomerData->id;?>" method="post">
          <div class="field item form-group">
            <label class="col-form-label col-md-12 col-sm-3  label-align" style="color:green;font-size: 1.3rem;font-weight: 900;text-align: center;">  Are You Sure ? Your Processing All Completed. </label>
         </div>     

          <div class="ln_solid">
            <div class="form-group">
               <div class="col-md-6 offset-md-3">
                   <button type='submit' class="btn btn-primary">Yes</button>
                    <button type='reset' class="btn btn-success">No</button>
                 </div>
            </div>
          </div>
         </form>
      </div>
    </div>
  </div>
</div>
<!--- model end ----->

          <!-- Customer status View Modal -->
          <div class="modal fade" id="Statusview<?php echo $CustomerData->id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h4 class="modal-title" id="myModalLabel">Customer status View ## <?php echo $CustomerData->fullname;?></h4>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">

                         <?php 
                             $CustomerStatusView = $this->Customer_model->GetDataCustomerStatus($CustomerData->id);
                               $sl = 0;
                              foreach ($CustomerStatusView as $StatusView) {
//var_dump($total_pay);die();
                                $sl++;
                          ?>

                          <ul  style="background-color: #fff; display: flex;">
                            <li style=" display: flex; font-size: 1rem;font-weight: 500;color:green;"><?php echo $sl;?>&nbsp;| &nbsp;</li>
                            <li style="display: flex; font-size: 1rem;font-weight: 500;"><?php echo $StatusView->date;?> / </li>
                            <li style="display: flex; font-size: 1rem;font-weight: 500;"><?php echo $StatusView->customer_status;?></li>
                        
                          </ul>
                          <ul>
                           <li style="list-style: none;text-align: right;"><a  href="<?php echo base_url('Customer/RemoveStatusCustomer/');?><?php echo $StatusView->id;?>" type="button" class="btn btn-danger">Remove</a>
                            </li>
                          </ul>
                          <?php 
                              }
                            ?>


                        <div class="modal-footer">
                          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                       
                        </div>                 
                </div>
              </div>
            </div>
          </div>
          <!-- Customer Status View model---->
          <!-- Modal -->
          <div class="modal fade" id="visacat<?php echo $CustomerData->id;?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h4 class="modal-title" id="myModalLabel">Customer status Change</h4>
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">

                        <form class="" action="<?php echo base_url('Customer/AddCustomerStatus');?>" method="post" novalidate>
                        <input type="hidden" name="customer_id" value="<?php echo $CustomerData->id;?>">
                        <input type="hidden" name="serial_no" value="<?php echo $CustomerData->serial_no;?>">
                         <div class="field item form-group">
                              <label class="col-form-label col-md-2 col-sm-3  label-align">
                                <?php echo "Name"?><span class="required">*</span>
                              </label>
                              <div class="col-md-10 col-sm-6">
                                <input class="form-control" name="cat_name" value="<?php echo $CustomerData->fullname;?>" readonly/>
                              </div>
                        </div>
                            <div class="field item form-group">
                              <label class="col-form-label col-md-2 col-sm-3  label-align">
                                <?php echo "Name"?><span class="required">*</span>
                              </label>
                              <div class="col-md-10">
                                  <select class="form-control" name="customer_status">
                                    <option> Select Customer Status </option>
                                    <option value="Medical">Medical</option>
                                    <option value="Medical-fit">Medical-fit</option>
                                    <option value="Medical-unfit">Medical-unfit</option>
                                    <option value="Update ok">Update ok</option>
                                    <option value="Police Clearance Receive">Police Clearance Receive</option>
                                    <option value="Driving License">Driving License</option>
                                    <option value="Embacey Submit">Embacey Submit</option>
                                    <option value="Visa Stuping">Visa Stuping</option>
                                    <option value="Finger print">Finger print</option>
                                    <option value="Training ok">Training ok</option>
                                    <option value="Manpower Submit">Manpower Submit</option>
                                    <option value="Manpower Complete">Manpower Complete</option>
                                    <option value="Air Ticketing Completed">Air Ticketing Completed</option>
                                    <option value="Flight">Flight</option>
                                    <option value="All Completed">All Completed</option>
                                  </select>
                              </div>
                              </div>

                               


                <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                  <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
                    </form>                  
                </div>
              </div>
            </div>
          </div>
          <!-- visa category model---->
                      <?php
                      }
                    }
                    ?>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
                </div>
              </div>

            </div><!--end row-->
          </div>
        </div>
        <!-- /page content -->