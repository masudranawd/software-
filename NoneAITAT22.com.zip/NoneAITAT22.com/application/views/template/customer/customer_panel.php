
            <!-- page content -->
            <div class="right_col" role="main">
                <div class="">
                    <!--<div class="page-title">
                        <div class="title_left">
                            <h3>Form Validation</h3>
                        </div>

                        <div class="title_right">
                            <div class="col-md-5 col-sm-5 form-group pull-right top_search">
                                <div class="input-group">
                                    <input type="text" class="form-control" placeholder="Search for...">
                                    <span class="input-group-btn">
                                        <button class="btn btn-default" type="button">Go!</button>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>-->
                    <div class="clearfix"></div>

  <?php echo $this->session->flashdata('smg');?>
                    <div class="row">
                        
                                                <div class="col-md-12 col-sm-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>Customer<small>Search</small></h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                        </li>
                                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content">
                                  <form class="" action="<?php echo base_url('Customer/customerPanel');?>" method="post" novalidate>
                                  
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align"><?php echo "Customer"?><span class="required">*</span></label>
                                             
                                                <div class="col-md-8 col-sm-6" style="margin-top: -10px;">
                                                 <select class="chosent form-control" name="serial_no" >
                                                    <option value="" >Select Customer</option> 
                                                  <?php 
                                                    foreach ($AllCustomerList as $CustomerData) {
                                                  ?>
                                                    <option value="<?php echo $CustomerData->serial_no;?>"><?php echo $CustomerData->fullname;?> / <?php echo $CustomerData->serial_no;?> / <?php echo $CustomerData->passport_no;?> /  <?php echo $CustomerData->visa_no;?> /   <?php echo $CustomerData->id_no;?> / <?php echo $CustomerData->mobile_no;?> / </option>
                                                  <?php
                                                      }  
                                                  ?>
                                                  </select>
                                              <script type="text/javascript">$(".chosent").chosen(); </script>
                                              </div>
                                              
                                        <div class="col-md-2 col-sm-6">
                                            <div class="form-group">
                                                <div class="col-md-4 offset-md-3">
                                                    <button type='submit' class="btn btn-info sourc">Search</button>
                                                </div>
                                            </div>
                                           
                                        </div>
                                          </div>

                                    </form>
                                </div>
                            </div>
</div>
                     

  <?php 
   if($CustomerAccounts == !null){
  ?>
  <div class="col-md-12 col-sm-12">
      
                  <?php 

                   foreach ($CustomerAccounts as $Customerview) {
                   ?>
                          <!---table----->
                <div class="x_panel">
                  <div class="x_title">
                    <h2> Customer Information<big style="color:red;"> <?php echo $Customerview->serial_no;?></big></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>

<?php //echo var_dump($Customerview);die();?>
                    <div class="col-md-5 col-sm-9 ">
                            <!-- start user projects -->
                            <table class="data table table-striped no-margin">
                              <thead>
                                <tr  class="btn-success">
                                  <th>Antry Date</th>
                                  <th>:&nbsp;&nbsp;<?php echo $Customerview->entry_date;?></th>
                                </tr>
                                <tr class="btn-secondary">
                                  <th>Name</th>
                                  <th>:&nbsp;&nbsp;<?php echo $Customerview->fullname;?></th>
                                </tr>
                                <tr  class="btn-success">
                                  <th>Profession</th>
                                  <th>:&nbsp;&nbsp;<?php echo $Customerview->profession;?></th>
                                </tr>
                                <tr class="btn-secondary">
                                  <th>Father's Name</th>
                                  <th>:&nbsp;&nbsp;<?php echo $Customerview->father_name;?></th>
                                </tr>
                                <tr  class="btn-success">
                                  <th>Serial Number</th>
                                  <th>:&nbsp;&nbsp;<?php echo $Customerview->serial_no;?></th>
                                </tr>
                                <tr class="btn-secondary">
                                  <th>Nation ID</th>
                                  <th>:&nbsp;&nbsp;<?php echo $Customerview->id_no;?></th>
                                </tr>
                                <tr class="btn-success">
                                  <th>Country</th>
                                  <th>:&nbsp;&nbsp;<?php echo $Customerview->pesent_nationality;?></th>
                                </tr>
                                
                                <tr class="btn-secondary">
                                  <th>Note</th>
                                  <th>:&nbsp;&nbsp;<?php echo $Customerview->note;?></th>
                                </tr>

                              </thead>
                            </table>
                            <!-- end user projects -->
                    </div>


                    <div class="col-md-5 col-sm-9 ">
                            <!-- start user projects -->
                            <table class="data table table-striped no-margin">
                              <thead>
                             
                                <tr  class="btn-secondary">
                                  <th>Visa Number </th>
                                  <th>:&nbsp;&nbsp;<?php echo $Customerview->visa_no;?></th>
                                </tr>
                                <tr class="btn-success">
                                  <th>Passport Number </th>
                                  <th>:&nbsp;&nbsp;<?php echo $Customerview->passport_no;?></th>
                                </tr>


                                <tr  class="btn-secondary">
                                  <th style="width: 30%;">Contact No</th>
                                  <th>:&nbsp;&nbsp;<?php echo $Customerview->mobile_no;?></th>
                                </tr>
                                <tr class="btn-success">
                                  <th style="width: 30%;">Address</th>
                                  <th>:&nbsp;&nbsp;<?php echo $Customerview->address;?></th>
                                </tr>
                                <tr  class="btn-secondary">
                                  <th style="width: 30%;">Reference Name</th>
                                  <th>:&nbsp;&nbsp;<?php echo $Customerview->reference_name;?></th>
                                </tr>
                                <tr class="btn-success">
                                  <th style="width: 30%;">Reference number</th>
                                  <th>:&nbsp;&nbsp;<?php echo $Customerview->reference_no;?></th>
                                </tr>
                                <tr  class="btn-secondary">
                                  <th style="width: 30%;">Agent Name</th>
                                  <th>:&nbsp;&nbsp;

                         <?php 
                           if($Customerview->agent_name){  $AgentName = $this->Customer_model->AgentNameById($Customerview->agent_name);
                           echo $AgentName->agent_name;
                           }else{ echo '';}
                         ?>
                                    
                                  </th>
                                </tr>

                              </thead>
                            </table>
                            <!-- end user projects -->
                    </div>

                    <div class="col-md-2 col-sm-3  profile_left">
                      <div class="profile_img">
                        <div id="crop-avatar" style="text-align:center">
                          <!-- Current avatar -->
                          <?php 
                            if($Customerview->customer_image == null){
                          ?>
                          <img class="img-responsive avatar-view" src="<?php echo base_url();?>images/user.png" alt="Avatar" title="Change the avatar" style="width: 100px;height: 100px;">
                          <?php    
                            }else{
                          ?>
                          <img class="img-responsive avatar-view" src="<?php echo base_url();?>images/customer/<?php echo $Customerview->customer_image;?>" alt="Avatar" title="Change the avatar" style="height: 150px;width: 150px;">
                          <?php
                            }
                          ?>


                        </div>
                      </div>
                   <center><h4><?php if($Customerview->fullname){echo $Customerview->fullname;}else{ echo 'Name not fonud!';}?></h4></center>

                            <table class="data table table-striped no-margin">
                              <thead>

                               <tr class="btn-warning">
                                  <th style="width: 50%;">Rate</th>
                                  <th>: <?php if($Customerview->rate){echo $Customerview->rate;}else{ echo '0.0';}?></th>
                                </tr>
                                <!-- <tr>
                                  <th style="width: 50%;">Discount</th>
                                  <th>: <?php if($Customerview->discount){echo $Customerview->discount;}else{ echo '0.0';}?></th>
                                </tr>
                                <tr>
                                  <th style="width: 50%;">ticket Cost</th>
                                  <th>: <?php if($Customerview->ticketing_cost){echo $Customerview->ticketing_cost;}else{ echo '0.0';}?></th>
                                </tr>
                                <tr>
                                  <th style="width:50%;">Extra charge </th>
                                  <th>: <?php if($Customerview->extra_charge){echo $Customerview->extra_charge;}else{ echo '0.0';}?></th>
                                </tr>
                                <tr>
                                  <th style="width:50%;">Total Payment</th>
                                  <th>: <?php if($Customerview->extra_charge){echo $Customerview->extra_charge;}else{ echo '0.0';}?></th>
                                </tr>-->

                              </thead>
                            </table>
                    </div>
                  
<!--end-->
<div class="col-md-12">  <!---table----->
                <div class="x_panel" style="background-color: #000;color:#fff; margin-top:20px;">
                  <div class="x_title">
                    <h2> Customer Status  Information <small></small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>

                  <div class="x_content">
                    <div class="table-responsive">
                      <table class="table table-striped jambo_table bulk_action">
                        <thead>
                          <tr class="headings">
                            <th class="column-title" style="display: table-cell;">sl</th>
                            <th class="column-title" style="display: table-cell;">Date</th>
                            <th class="column-title" style="display: table-cell;">Status</th>
                          </tr>
                        </thead>

                        <tbody>
                         <?php 
                             $CustomerStatusView = $this->Customer_model->GetDataCustomerStatus($Customerview->id);
                               $sl = 0;
                              foreach ($CustomerStatusView as $StatusView) {

                                  //var_dump($total_pay);die();
                                $sl++;
                          ?>
                          <tr class="even pointer" style="background-color: #fff;">
                            <td class="a-center "><?php echo $sl;?></td>
                            <td class="a-center "><?php echo $StatusView->date;?></td>
                            <td class="a-center "><?php echo $StatusView->customer_status;?></td>
                          </tr>
                          <?php 
                              }
                            ?>
                        </tbody>
                      </table>
                    </div>
                </div>
</div>
</div>
<!--end-->


<div class="col-md-6">  <!---table----->
                <div class="x_panel" style="background-color: #000;color:#fff; margin-top:20px;">
                  <div class="x_title">
                    <h2> Deposit Information <small></small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>

                  <div class="x_content">
                    <div class="table-responsive">
                      <table class="table table-striped jambo_table bulk_action">
                        <thead>
                          <tr class="headings">
                            <th class="column-title" style="display: table-cell;">sl</th>
                            <th class="column-title" style="display: table-cell;">Date</th>
                            <th class="column-title" style="display: table-cell;">Details</th>
                            <th class="column-title" style="display: table-cell;">Method</th>
                            <th class="column-title" style="display: table-cell;">Amount</th>
                          </tr>
                        </thead>

                        <tbody>
                         <?php 
                             $CustomnerPaymentView = $this->Customer_model->GetDatapayment($Customerview->id);
                               $sl = 0;
                               $detotal = 0; 
                              foreach ($CustomnerPaymentView as $PaymentView) {
                             
                           if($PaymentView->payment_type == 'Deposit'){
                                 $detotal = (int)$detotal+(int)$PaymentView->payment;
                                 $sl++;
                          ?>
                          <tr class="even pointer" style="background-color: #fff;">
                            <td class="a-center "><?php echo $sl;?></td>
                            <td class="a-center "><?php echo $PaymentView->payment_date;?></td>
                            <td class="a-center "><?php echo $PaymentView->for_payment;?></td>
                            <td class="a-center "><?php echo $PaymentView->method;?>
                            <?php 
                                if ($PaymentView->bank_name){ 
                                  echo '('.$PaymentView->bank_name.')';
                                }elseif ($PaymentView->bank_recepit_n) {
                                  echo '('.$PaymentView->bank_recepit_n.')';
                                }elseif ($PaymentView->bkash_n) {
                                  echo '('.$PaymentView->bkash_n.')';
                                }elseif ($PaymentView->rocket_n) {
                                  echo '('.$PaymentView->rocket_n.')';
                                }else{
                                  echo '';
                                }
                            ?></td>
                            <td class="a-center "><?php echo $PaymentView->payment;?></td>
                            </td>
                          </tr>
                          <?php 
                              }
                            }
                            ?>
                            <tr>
                              <td colspan="4" style="text-align: right;color:#fff;"> Total Deposit  = </td>
                              <td colspan="" style="color:#fff;"><?php echo $detotal;?></td>
                            </tr>

                        </tbody>
                      </table>
                    </div>
                </div>
</div>
</div>
<!--end-->

<div class="col-md-6">  <!---table----->
                <div class="x_panel" style="background-color: #000;color:#fff; margin-top:20px;">
                  <div class="x_title">
                    <h2> Expenses Information <small></small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>

                  <div class="x_content">
                    <div class="table-responsive">
                      <table class="table table-striped jambo_table bulk_action">
                        <thead>
                          <tr class="headings">
                            <th class="column-title" style="display: table-cell;">sl</th>
                            <th class="column-title" style="display: table-cell;">Date</th>
                            <th class="column-title" style="display: table-cell;">Details</th>
                            <th class="column-title" style="display: table-cell;">Method</th>
                            <th class="column-title" style="display: table-cell;">Amount</th>
                          </tr>
                        </thead>

                        <tbody>
                         <?php 
                             $CustomnerPaymentView = $this->Customer_model->GetDatapayment($Customerview->id);
                               $sl = 0;
                               $extotal = 0; 
                              foreach ($CustomnerPaymentView as $PaymentView) {
                                if($PaymentView->payment_type == 'Expense'){
                                 $extotal = (int)$extotal+(int)$PaymentView->payment; 
                                  //var_dump($total_pay);die();
                                $sl++;
                          ?>
                          <tr class="even pointer" style="background-color: #fff;">
                            <td class="a-center "><?php echo $sl;?></td>
                            <td class="a-center "><?php echo $PaymentView->payment_date;?></td>
                            <td class="a-center "><?php echo $PaymentView->for_payment;?></td>
                            <td class="a-center "><?php echo $PaymentView->method;?>
                            <?php 
                                if ($PaymentView->bank_name){ 
                                  echo '('.$PaymentView->bank_name.')';
                                }elseif ($PaymentView->bank_recepit_n) {
                                  echo '('.$PaymentView->bank_recepit_n.')';
                                }elseif ($PaymentView->bkash_n) {
                                  echo '('.$PaymentView->bkash_n.')';
                                }elseif ($PaymentView->rocket_n) {
                                  echo '('.$PaymentView->rocket_n.')';
                                }else{
                                  echo '';
                                }
                            ?></td>
                            <td class="a-center "><?php echo $PaymentView->payment;?></td>
                            </td>
                          </tr>
                          <?php 
                              }
                            }
                            ?>
                            <tr>
                              <td colspan="4" style="text-align: right;color:#fff;"> Total Expenses = </td>
                              <td colspan="" style="color:#fff;"><?php echo $extotal;?></td>
                            </tr>
                        </tbody>
                      </table>
                    </div>
                </div>
</div>
</div>
<!--end-->


<div class="col-md-3"> </div>
<div class="col-md-6">  <!---table----->
                <div class="x_panel" style="background-color: #000;color:#fff; margin-top:20px;">
                  <div class="x_title">
                    <h2> Total Deposit And Expenses Information <small></small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>

                  <div class="x_content">
                    <div class="table-responsive">
                      <table class="table table-striped jambo_table bulk_action">
                        <thead>
                        </thead>

                        <tbody>
                            <tr>
                              <td colspan="4" style="text-align: right;color:#fff;"> Total Due = </td>
                              <td colspan="" style="color:#fff;"><?php
                                $rate = $Customerview->rate;
                              echo (int)$rate -(int)$detotal; 
                              ?> .Tk</td>
                            </tr>
                            <!--<tr>
                              <td colspan="4" style="text-align: right;color:#fff;"> Total Credit = </td>
                              <td colspan="" style="color:#fff;"><?php echo $detotal - $extotal;?></td>
                            </tr>-->
                        </tbody>
                      </table>
                    </div>
                </div>
</div>
</div>
<!--end-->
      <?php
                   }
          }else{
      ?>
        <?php echo "Not"; ?>
      <?php
          }
      ?>
                                       
            
                    </div><!-- end row---->
                </div>
            </div>
            <!-- /page content -->



