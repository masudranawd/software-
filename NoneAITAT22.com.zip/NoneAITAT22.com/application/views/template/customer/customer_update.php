

            <!-- page content -->
            <div class="right_col" role="main">
                <div class="">
                    <div class="clearfix"></div>

                    <div class="row">
                        <div class="col-md-12 col-sm-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>Update Customer<small><?php echo $this->session->flashdata('sms');?></small></h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                        </li>
                                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
<?php  
  if(empty($SerialNo->id)){
    $serial_no = 'MB1';
  }else{
    $serial_no = 'MB'.sprintf("%01d",$SerialNo->id+1);
  }
?>
                                <div class="x_content">
                                  <?php echo form_open_multipart('Customer/UpdateCustomerprofile');?>
                                      <div class="row">
            <input type="hidden" name="id" value="<?php echo $CustomerDataInfo->id;?>"/>
            <input type="hidden" name="old_image" value="<?php echo $CustomerDataInfo->customer_image;?>"/>
                                        <!-- left--->
                                      <div class="col-md-6"  style="background-color: #eee;padding:10px;">
                                           <!--start--->
                                          <div class="field item form-group">
                                            <label class="col-form-label col-md-2 col-sm-3  label-align" >Entry Date<span class="required">*</span></label>
                                              <div class="col-md-10 ">
                                                <input type="text" class="form-control has-feedback-left" id="single_cal4" value="<?php echo $CustomerDataInfo->entry_date;?>" name="entry_date" aria-describedby="inputSuccess2Status4">
                                                <span class="fa fa-calendar-o form-control-feedback left" aria-hidden="true"></span>
                                                <span id="inputSuccess2Status4" class="sr-only">(success)</span>
                                              </div>
                                          </div>
                                            <!-- end --->

                                         <!--start -->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align" >Serial Number<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" name="serial_no" value="<?php echo $CustomerDataInfo->serial_no;?>"  />
                                              </div>
                                          </div>
                                          <!-- end--->

                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align" >Passenger Name<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" data-validate-length-range="6" data-validate-words="2" name="fullname" value="<?php echo $CustomerDataInfo->fullname;?>" />
                                              </div>
                                          </div>   


                                  <!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Mobile No <span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" class='optional' name="mobile_no"  type="text" value="<?php echo $CustomerDataInfo->mobile_no;?>" />
                                              </div>
                                          </div>
                                   <!--end--->


                                        </div>

            <!------------------------end left------------------------------------->

                                        <!-- center--->
                                        <div class="col-md-6"  style="background-color: #111;padding:10px;color:#fff;" >

                                     <!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Passport No.<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                <input class="form-control" class='optional' name="passport_no" type="text"    value="<?php echo $CustomerDataInfo->passport_no;?>"/>
                                              </div>
                                          </div>
                                      <!--end--->
                                        
                         
                                     <!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Gander<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                 <select class="form-control"  name="gender" required>
                                                  <?php if ($CustomerDataInfo->gender == 'MALE') {

                                                  ?>
                                                  <option value="MALE" selected=""> MALE</option>
                                                  <option value="FEMALE"> FEMALE</option>
                                                 <?php
                                                  }else{
                                                  ?>

                                                  <option value="MALE"> MALE</option>
                                                  <option value="FEMALE" selected=""> FEMALE</option>
                                                <?php } ?>
                                                  </select>
                                                </div>
                                          </div>
                                     <!--end---> 


                                        <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Note<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" class='optional' name="note"  type="text" value="<?php echo $CustomerDataInfo->note;?>"  />
                                              </div>
                                        </div>   

                                  
                                          <!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Customer Profile  <span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" class='optional' name="customer_image"  type="file"  />

                                                  <img src="<?php echo base_url();?>images/customer/<?php echo $CustomerDataInfo->customer_image;?>" style="width:100px; height: 100px;">
                                              </div>
                                          </div>
                                          <!--end--->


                                        </div>
<!----------------------------end Right--------------------------------------->

                                      </div><!---ROW END-->
                            
                     
                                            <div class="form-group">
                                                <div class="col-md-6 offset-md-3">
                                                  <button type='submit' class="btn btn-warning">Update</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /page content -->
