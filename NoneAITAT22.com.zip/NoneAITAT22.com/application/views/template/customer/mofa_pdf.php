<?php 
//include tcpdf/library 
//include 'tcpdf/tcpdf.php'; 
//make TCPDF Object
$pdf = new Pdf('p', 'mm', 'A4', true, 'UTF-8', false);

$lg = Array();
$lg['a_meta_charset'] = 'UTF-8';
$lg['a_meta_dir'] = 'rtl';
$lg['a_meta_language'] = 'fa';
$lg['w_page'] = 'page';

$pdf->SetFont('aefurat', '', 4, '', true);


//remove default header & footer. 
$pdf->setPrintHeader(false); 
$pdf->setPrintFooter(false); 

//add page
$pdf->AddPage(); 


// define barcode style
$style = array(
    //'position' => 'center',
    'align' => 'C',
    'stretch' => false,
    'fitwidth' => true,
    //'border' => true,
    'hpadding' => 'auto',
    'vpadding' => 'auto',
    'fgcolor' => array(0,0,0),
    'bgcolor' => false, //array(255,255,255),
    'text' => true,
    'font' => 'helvetica',
    'fontsize' => 14,
    'stretchtext' => 13,
);



$style['cellfitalign'] = 'C';
$n = 1; 
$To = $CustomerDataInfo->qty; 


while($n <= $To){
    $n ++; 
    $x = $pdf->GetX();
    $y = $pdf->GetY();

    $pdf->write1DBarcode($CustomerDataInfo->visa_no,  'C39', '', '8', '', 18, 0.3, $style, 'N');      
// Center alignment


$pdf->Ln();
}
//Bottom barcode 


// define barcode style
$style2 = array(
    //'position' => 'center',
    'align' => 'C',
    'stretch' => false,
    'fitwidth' => true,
    //'border' => true,
   // 'hpadding' => 'auto',
    //'vpadding' => 'auto',
    'fgcolor' => array(0,0,0),
    'bgcolor' => false, //array(255,255,255),
    'text' => true,
    'font' => 'helvetica',
    'fontsize' => 14,
    'stretchtext' => 13,
);



$style2['cellfitalign'] = 'C';
$n = 1; 
$To = $CustomerDataInfo->qty; 


while($n <= $To){
    $n ++; 
    $x = $pdf->GetX();
    $y = $pdf->GetY();

    $pdf->write1DBarcode($CustomerDataInfo->passport_no,  'C39', '', '258.9', '', 18, 0.3, $style, 'N');      

$pdf->Ln();
}



$pdf->writeHTMLCell(0,0,0,23,'',0,0); //HEADER.
$tbl = <<<EOD
<br/>

<table cellspacing="0" cellpadding="1" style="">
    <tr>
            <th style=" width:60mm;font-size:10.9;">PHOTO</th>
            <th style=" width:70mm;font-size:10.9;font-family:times;text-align:center;">
            <small style="font-size:16px;">Visa Date:</small><b>$CustomerDataInfo->visa_date_arabic<br>
            <img src="images/ar.png" style="height:50px;">
            </b></th>
            <th style=" width:60mm;text-align:center;font-size:11;">
                <strong style="font-size:16px;">$CustomerDataInfo->mofa_number</strong><br/>
             سفرة المملكة العربية السعودية
           <br/>
القسم القنصلي      <br> EMBASSY OF SAUDI ARABIA<br>
CONSULAR SECTION 
</th>
    </tr>
</table>

<table cellspacing="0" cellpadding="1" style="border-top:1px solid #000;border-left:1px solid #000;border-right:1px solid #000;" >
    <tr>
            <th style=" width:18mm;font-size:11.5;"><small>Full name:</small></th>
            <th style=" width:75mm;font-size:10.9;font-family:times;"><b>$CustomerDataInfo->fullname</b></th>
            <th style=" width:8mm;font-size:11.5;font-family:times;"><b>S/O</b></th>
            <th style=" width:73mm;font-size:10.9;font-family:times;"><b>$CustomerDataInfo->father_name</b></th>
            <th style=" width:16mm;text-align:right;font-size:11.5;"><small>السم الكامل:</small></th>
    </tr>
</table>


<table cellspacing="0" cellpadding="1" style="border-top:1px solid #000;border-left:1px solid #000;border-right:1px solid #000;">
    <tr>
            <th style=" width:30mm;font-size:11.5;"><small>Mother's name:</small></th>
            <th style=" width:140mm;font-size:10.9;font-family:times;"><b >$CustomerDataInfo->mother_name</b></th>
            <th style=" width:20mm;text-align:right;font-size:11.5;"><small>اسم الولادة:</small></th>
    </tr>
</table>
<table cellspacing="0" cellpadding="1" style="border-top:1px solid #000;border-left:1px solid #000;border-right:1px solid #000;">
    <tr>
            <th style=" width:30mm;font-size:11.5;"><small>Date of birth:</small></th>
            <th style=" width:36mm;font-size:10.9;font-family:times;"><b>$CustomerDataInfo->date_of_birth</b></th>
            <th style=" width:28mm;text-align:right;font-size:11.5;"><small>تاريخ الولادة: </small></th>
            <th style=" width:32mm;text-align:right;font-size:11.5;text-align:left;"><small>&nbsp;&nbsp;Place of birth:</small></th>

            <th style=" width:44mm;font-size:10.9;font-family:times;"><b>$CustomerDataInfo->place_of_birth</b></th>

            <th style=" width:20mm;font-size:11.5;text-align:right;"><small>محل الولادة: </small></th>
    </tr>
</table>
<table cellspacing="0" cellpadding="1" style="border-top:1px solid #000;border-left:1px solid #000;border-right:1px solid #000;">
    <tr>
            <th style=" width:30mm;font-size:11.5;"><small>Pervious nationality:</small></th>
            <th style=" width:36mm;font-size:10.9;font-family:times;"><b>$CustomerDataInfo->previous_nationality</b></th>
            <th style=" width:28mm;text-align:right;font-size:11.5;"><small>الجنسية السابقة: </small></th>
            <th style=" width:30mm;text-align:left;font-size:11.5;"><small>Present nationality:</small></th>
            <th style=" width:36mm;font-size:10.9;font-family:times;"><b>$CustomerDataInfo->pesent_nationality</b></th>

            <th style=" width:30mm;font-size:10.9;text-align:right;"><small> الجنسية الحالية: </small></th>
    </tr>
</table>

<table cellspacing="0" cellpadding="1" style="border-top:1px solid #000;border-left:1px solid #000;border-right:1px solid #000;">
    <tr>
            <th style=" width:30mm;font-size:11.5;"><small>Sex:</small></th>
            <th style=" width:36mm;font-size:10.9;font-family:times;"><b>$CustomerDataInfo->gender</b></th>
            <th style=" width:28mm;text-align:right;font-size:11.5;"><small>االجنس: </small></th>
            <th style=" width:30mm;text-align:left;font-size:11.5;"><small>&nbsp;&nbsp;Marital Status:</small></th>
            <th style=" width:36mm;font-size:10.9;font-family:times;"><b>$CustomerDataInfo->marital_status</b></th>
            <th style=" width:30mm;text-align:right;font-size:11.5;"><small>لحالة الاجتماعية:</small></th>
    </tr>
</table>

<table cellspacing="0" cellpadding="1" style="border-top:1px solid #000;border-left:1px solid #000;border-right:1px solid #000;">
    <tr>
            <th style=" width:30mm;font-size:11.5;"><small>Sect:</small></th>
            <th style=" width:36mm;font-size:10.9;"><b> </b></th>
            <th style=" width:28mm;text-align:right;font-size:11.5;"><small>المذهب: </small></th>
            <th style=" width:30mm;text-align:left;font-size:11.5;"><small>&nbsp;&nbsp;Religion:</small></th>
            <th style=" width:36mm;font-size:10.9;font-family:times;"><b>$CustomerDataInfo->religion</b></th>
            <th style=" width:30mm;text-align:right;font-size:11.5;"><small>الديـانة: </small></th>
    </tr>
</table>

<table cellspacing="0" cellpadding="1" style="border-top:1px solid #000;border-left:1px solid #000;border-right:1px solid #000; line-height:90%;">
    <tr>

            <th style=" width:59mm;font-size:11.5;"><small>مصدرة:</small></th>

            <th style=" width:50mm;font-size:11.5; text-align:center;"><small>المؤهل العلمي:</small></th>

            <th style=" width:61mm;font-size:14;text-align:right;font-weight:bold;"><b> $CustomerDataInfo->profession_arabic </b></th>

            <th style=" width:20mm;text-align:right;font-size:11.5;"><small>المهنة:</small></th>

    </tr>
    <tr>
            <th style=" width:48mm;font-size:11.5; text-align:center;"><small style="font-size:8;">Place of issue:</small><br> <b style="font-family:times;">$CustomerDataInfo->place_issue</b></th>
            <th style=" width:42mm;font-size:11.5;text-align:center"><small style="font-size:8;">Qualification:</small><br><b style="font-family:times;">$CustomerDataInfo->qulafication</b></th>
            <th style=" width:100mm;font-size:11.5;text-align:center;"><small style="font-size:8;">Profession :</small><br><b style="font-family:times;">$CustomerDataInfo->profession</b></th>
          
    </tr>
</table>

<table cellspacing="0" cellpadding="1" style="border-left:1px solid #000;border-right:1px solid #000;line-height:50%;">
    <tr>
            <th style=" width:190mm;font-size:11.5;"></th>
          
    </tr>
</table>

<table cellspacing="0" cellpadding="1" style="border-top:1px solid #000;border-left:1px solid #000;border-right:1px solid #000;line-height:6px;">
    <tr>
            <th style=" width:50mm;font-size:11.5;"><small>Home address and telephone No.</small></th>
            <th style=" width:100mm;font-size:10.9;font-family:times;"><b>$CustomerDataInfo->pesent_nationality $CustomerDataInfo->mobile_no </b></th>
            <th style=" width:40mm;text-align:right;font-size:11.5;"><small>عنوان المنزل ورقم التلفون: </small></th>
          
    </tr>
</table>

<table cellspacing="0" cellpadding="1" style="border-top:1px solid #000;border-left:1px solid #000;border-right:1px solid #000;">
    <tr>
            <th style=" width:30mm;font-size:12;"><small>Business address and telephone No.</small></th>
            <th style=" width:160mm;font-size:10.9;font-family:times; text-align:center;"><b>$SiteData->name
            <br>
             $SiteData->address
            </b></th>
           
          
    </tr>
</table>



<table cellspacing="0" cellpadding="1" style="border-top:1px solid #000;border-left:1px solid #000;border-right:1px solid #000;line-height:90%;">
    <tr>
            <th style=" width:30mm;font-size:10.9;"><small style="line-height:20px;">Purpose of travel:</small></th>

            <th style=" width:15mm;font-size:10;text-align:center;border:1px solid #000;">عمل  <br> Work </th>

            <th style=" width:20mm;font-size:10;text-align:center;border:1px solid #000;padding:5px;">مرور <br> Transit </th>
            <th style=" width:15mm;font-size:10;text-align:center;border:1px solid #000;padding:5px;">زيارة <br> Visit </th>

            <th style=" width:20mm;font-size:10;text-align:center;border:1px solid #000;padding:5px;">عمرة <br> Umrah </th>

            <th style=" width:25mm;font-size:10;text-align:center;border:1px solid #000;padding:5px;">للإقامة <br> Residence </th>

            <th style=" width:15mm;font-size:10;text-align:center;border:1px solid #000;padding:5px;">لحج <br> Hajj </th>

            <th style=" width:25mm;font-size:10;text-align:center;border:1px solid #000;padding:5px;">دبلوماسية <br> Diplomacy </th>
            <th style=" width:25mm;text-align:right;font-size:10.9;"><small style="line-height:20px;">الغاية من السفر: </small></th>
          
    </tr>
</table>
<table cellspacing="0" cellpadding="1" style="border-top:1px solid #000;border-left:1px solid #000;border-right:1px solid #000;line-height:90%;">
    <tr>
            <th style=" width:44mm;font-size:10;"><b> </b></th>

            <th style=" width:20mm;font-size:10;"><small>محل الاصدار: </small></th>

            <th style=" width:43mm;font-size:10;"><b> </b></th>

            <th style=" width:20mm;font-size:10;"><small>تاريخ الاصدار: </small></th>

            <th style=" width:43mm;font-size:10;text-align:right"><b> </b></th>

            <th style=" width:20mm;text-align:right;font-size:10;"><small>رقم الجواز:</small></th>

    </tr>
</table>


<table cellspacing="0" cellpadding="1" style="border-top:1px solid #000;border-left:1px solid #000;border-right:1px solid #000;">
    <tr>
            <th style=" width:23mm;font-size:11.5;"><small>Place of issue:</small></th>
            <th style=" width:32mm;font-size:10.9;font-family:times;"><b>$CustomerDataInfo->place_issue</b></th>
            <th style=" width:35mm;font-size:11.5;"><small>Date Of passport issue:</small></th> 
            <th style=" width:40mm;font-size:10.9;font-family:times;"><b>$CustomerDataInfo->D_of_passport_issue</b></th>
            <th style=" width:20mm;font-size:11.5;"><small>Passport No.:</small></th> 
            <th style=" width:40mm;font-size:10.9;font-family:times;"><b>$CustomerDataInfo->passport_no</b></th>
          
    </tr>
</table>

<table cellspacing="0" cellpadding="1" style="border-top:1px solid #000;border-left:1px solid #000;border-right:1px solid #000;">
    <tr>
            <th style=" width:50mm;font-size:11.5;"><small>Date of pasport's expiry:</small></th>
            <th style=" width:110mm;font-size:10.9;font-family:times;"><b>$CustomerDataInfo->D_passport_expiry </b></th>
            <th style=" width:30mm;text-align:right;font-size:10.9;"><small>تاريخ انتهاء صلاحية الجواز:</small></th>
          
    </tr>
</table>


<table cellspacing="0" cellpadding="1" style="border-top:1px solid #000;border-left:1px solid #000;border-right:1px solid #000;line-height:90%;">
    <tr>
            <th style=" width:34mm;font-size:10;"><b> </b></th>

            <th style=" width:30mm;font-size:10;"><small>مدة الاقامة بالمملكة: </small></th>

            <th style=" width:43mm;font-size:10;"><b> </b></th>

            <th style=" width:20mm;font-size:10;"><small>تاريخ الوصول: </small></th>

            <th style=" width:43mm;font-size:10;text-align:right"><b> </b></th>

            <th style=" width:20mm;text-align:right;font-size:10;"><small>رتاريخ المغادرة:</small></th>

    </tr>
    <tr>
            <th style=" width:50mm;font-size:11.5;"><small>Duration of stay in the Kingdom:</small></th>
            <th style=" width:30mm;font-size:10.9;font-family:times;"><b>  </b></th>
            <th style=" width:30mm;font-size:11.5;"><small>Date of arrival:</small></th> 
            <th style=" width:20mm;font-size:10.9;font-family:times;"><b></b></th>
            <th style=" width:60mm;font-size:11.5;"><small>Date of departure:</small></th> 
          
    </tr>
</table>

<table cellspacing="0" cellpadding="1" style="border-top:1px solid #000;border-left:1px solid #000;border-right:1px solid #000;line-height:90%;">
    <tr>
            <th style=" width:10mm;font-size:10.9;"><small> </small></th>

            <th style=" width:10mm;font-size:10.9;"><small>تاريخ: </small></th>

            <th style=" width:15mm;font-size:10.9;"><small> </small></th>
            <th style=" width:15mm;font-size:10.9;"><small> ايصال رقم: </small></th>

            <th style=" width:15mm;text-align:center;font-size:10.9;"><small>()</small></th>
            <th style=" width:10mm;font-size:10.9;"><small>ماريخ </small></th>

            <th style=" width:15mm;text-align:center;font-size:10.9;"><small></small></th>
            <th style=" width:15mm;font-size:10.9;"><small>مبشيك رقم:</small></th>

            <th style=" width:15mm;text-align:center;font-size:10.9;"><small>(&nbsp;&nbsp;&nbsp;)</small></th>
            <th style=" width:10mm;font-size:10.9;font-size:10.9;"><small>منقدا</small></th>

            <th style=" width:15mm;text-align:center;font-size:10.9;"><small>(&nbsp;&nbsp;&nbsp;)</small></th>
            <th style=" width:10mm;font-size:10.9;"><small> مجاملة </small></th>

            <th style=" width:15mm;text-align:right;font-size:10.9;"><small>(&nbsp;&nbsp;&nbsp;)</small></th>
            <th style=" width:20mm;font-size:10.9;"><small> مطريقة الدفع: </small></th>

    </tr>
</table>

<table cellspacing="0" cellpadding="1" style="border-top:1px solid #000;border-left:1px solid #000;border-right:1px solid #000;line-height:90%;">
    <tr>
            <th style=" width:40mm;font-size:11.5;"><small>Model of payment: </small></th>


            <th style=" width:30mm;font-size:11.5;"><small>Free</small></th>

            <th style=" width:25mm;text-align:center;font-size:11.5;"><small>Cash</small></th>

            <th style=" width:35mm;text-align:center;font-size:11.5;"><small>Check No.</small></th>

            <th style=" width:25mm;text-align:center;font-size:11.5;"><small>Date:</small></th>

            <th style=" width:35mm;text-align:center;font-size:11.5;"><small>No. Date:</small></th>


    </tr>
</table>


<table cellspacing="0" cellpadding="1" style="border-top:1px solid #000;border-left:1px solid #000;border-right:1px solid #000;line-height:90%;">
    <tr>
            <th style=" width:55mm;font-size:10.9;"><small> </small></th>

            <th style=" width:15mm;font-size:11;"><small> لتـه: </small></th>

            <th style=" width:100mm;font-size:10.9;"><small></small></th>
            <th style=" width:20mm; text-align:right;font-size:10.9;"><small>اسم المحرم: </small></th>

    </tr>
    <tr>
            <th style=" width:30mm;font-size:11.5;"><small>Relationship </small></th>

            <th style=" width:160mm;font-size:10.9;"><small> </small></th>

    </tr>
</table>

<table cellspacing="0" cellpadding="1" style="border-top:1px solid #000;border-left:1px solid #000;border-right:1px solid #000;line-height:85%;">
    <tr>
            <th style=" width:25mm;font-size:11.5;"><small> Destination</small></th>
            <th style=" width:45mm;font-size:11.5;"><small></small></th>
            <th style=" width:28mm;font-size:11.5;"><small> لجهة الوصول بالمملكة:  </small></th>

            <th style=" width:25mm;font-size:11.5;"><small>Carrier's name:</small></th>
            <th style=" width:40mm;font-size:11.5;"><small></small></th>
            <th style=" width:27mm;font-size:11.5; text-align:right;"><small>اسم الشركة الناقلة: </small></th>

    </tr>
</table>

<table cellspacing="0" cellpadding="1" style="border-top:1px solid #000;border-left:1px solid #000;border-right:1px solid #000;line-height:90%;">
    <tr>
            <th style=" width:90mm;font-size:11.5;"><small> Dependents traveling in the same passport:</small></th>
          
            <th style=" width:100mm;font-size:11.5; text-align:right;"><small> لايضاحات تخص افراد العائلة (المضافين) علي  نفس جواز السفر:</small></th>

    </tr>
</table>

<table cellspacing="0" cellpadding="1" style="border-top:1px solid #000;border-left:1px solid #000;border-right:1px solid #000;line-height:90%;">
    <tr>
            <th style=" width:20mm;font-size:10.9;"><small> </small></th>
            <th style=" width:30mm;font-size:11.5;"><small> نوع الصلة</small></th>
            <th style=" width:20mm;font-size:10.9;"><small> </small></th>

            <th style=" width:25mm;font-size:11.5;"><small>تاريخ الميلاد</small></th>
            <th style=" width:20mm;font-size:10.9;"><small></small></th>

            <th style=" width:25mm;font-size:11.5; text-align:right;"><small> الجنــــــــــس  </small></th>

            <th style=" width:20mm;font-size:11.5;"><small></small></th>

            <th style=" width:30mm; text-align:right;font-size:11.5;"><small> م بـالكـــــــامل</small></th>

    </tr>
</table>

<table cellspacing="0" cellpadding="1" style="border-top:1px solid #000;border-left:1px solid #000;border-right:1px solid #000;">
    <tr>
            <th style=" width:20mm;"><small> </small></th>
            <th style=" width:30mm;font-size:11.5;"><small>Relationship</small></th>
            <th style=" width:20mm;font-size:10.9;"><small> </small></th>

            <th style=" width:25mm;font-size:11.5;"><small>Date of birth</small></th>
            <th style=" width:20mm;font-size:10.9;"><small></small></th>

            <th style=" width:25mm; font-size:11.5;text-align:right;"><small>Sex</small></th>

            <th style=" width:20mm;font-size:10.9;"><small></small></th>

            <th style=" width:30mm; text-align:center;font-size:11.5;"><small>Full name</small></th>

    </tr>
</table>

<table cellspacing="0" cellpadding="1" style="border-top:1px solid #000;border-left:1px solid #000;border-right:1px solid #000;">
    <tr>
            <th style=" width:50mm; text-align:center;font-size:11.5;"><small>GROUP:</small></th>
            <th style=" width:140mm;font-size:10.9;"><small></small></th>

    </tr>
</table>

<table cellspacing="0" cellpadding="1" style="border-top:1px solid #000;border-left:1px solid #000;border-right:1px solid #000;line-height:9px;">
    <tr>
            <th style=" width:50mm; text-align:center;font-size:10.9;"></th>
            <th style=" width:140mm;font-size:10.9;"></th>

    </tr>
</table>

<table cellspacing="0" cellpadding="1" style="border-top:1px solid #000;border-left:1px solid #000;border-right:1px solid #000;line-height:90%;">
    <tr>
            <th style=" width:100mm;font-size:11.5;"><small>Name and address of company or individual in the kingdom:</small></th>
            <th style=" width:10mm;"><small></small></th>
            <th style=" width:80mm;text-align:right;font-size:11.5;"><small>اسم وعنوان الشركة او اسم الشخص وعنوان بالمملكة:</small></th>

    </tr>
</table>

<table cellspacing="0" cellpadding="1" style="border-top:1px solid #000;border-left:1px solid #000;border-right:1px solid #000;">
    <tr>
            <th style=" width:140mm;font-size:14;"><b>$CustomerDataInfo->Kofile_name_eng</b></th>
            <th style=" width:50mm;font-size:10.9;"><small></small></th>

    </tr>
</table>

<table cellspacing="0" cellpadding="1" style="border-top:1px solid #000;border-left:1px solid #000;border-right:1px solid #000;line-height:6px;">
    <tr>
            <th style=" width:125mm;font-size:10;font-family:times;">The undersigned hereby certify that all the information I have provided are correct.I will abide by the laws of the Kingdom during the period of my residence in it.
</th>
            <th style=" width:65mm;text-align:right;font-size:12;"><small>انا الموقع ادناه اقر بان كل المعلومات التي دونها <br>صحيحه.
وسيكون ملتزما بقوانين المملكة اثناء فترة وجودي بها
</small></th>

    </tr>
</table>

<table cellspacing="0" cellpadding="1" style="border-top:1px solid #000;border-left:1px solid #000;border-right:1px solid #000;line-height:90%;">
    <tr>
            <th style=" width:15mm;font-size:11.5;"><small>Date</small></th>
            <th style=" width:25mm;font-size:11.5;"><small> </small></th>
            <th style=" width:20mm;font-size:11.5;"><small>التأريخ:</small></th>

            <th style=" width:15mm;font-size:11.5;"><small>Signature</small></th>
            <th style=" width:25mm;font-size:11.5;"><small> </small></th>
            <th style=" width:20mm;font-size:11.5;"><small>التوقيع: :</small></th>

            <th style=" width:15mm;font-size:11.5;"><small>Name</small></th>
            <th style=" width:45mm;font-size:10.5;font-family:times;"><b>$CustomerDataInfo->fullname </b></th>
            <th style=" width:10mm;font-size:11.5;text-align:right;"><small>االسم:</small></th>



    </tr>
</table>

<table cellspacing="0" cellpadding="1" style="border-top:1px solid #000;border-left:1px solid #000;border-right:1px solid #000;line-height:90%;">
    <tr>
            <th style=" width:35mm;font-size:11.5;"><small>For official use only</small></th>
            <th style=" width:120mm;font-size:11.5;"><small> </small></th>
            <th style=" width:35mm;font-size:11.5;text-align:right;"><small>للاستعمال الرسمي فقط:</small></th>

    </tr>
</table>

<table cellspacing="0" cellpadding="1" style="border-top:1px solid #000;border-left:1px solid #000;border-right:1px solid #000;">
    <tr>
            <th style=" width:10mm;font-size:11.5;"><small>Date</small></th>
            <th style=" width:40mm;font-size:11.5;">هـ <b style="font-family:times;">$CustomerDataInfo->visa_date_arabic</b></th>
            <th style=" width:20mm;font-size:11.5;"><small>التأريخ:</small></th>

            <th style=" width:20mm;font-size:11.5;"><small>Authorization</small></th>
            <th style=" width:50mm;font-size:11.5;font-family:times;"><b>$CustomerDataInfo->visa_no</b></th>
            <th style=" width:50mm;font-size:11.5;text-align:right;"><small>رقم الامر المعتمد عليه اعطاء التأشيرة:</small>
            </th>
    </tr>
</table>

<table cellspacing="0" cellpadding="1" style="border-top:1px solid #000;border-left:1px solid #000;border-right:1px solid #000;">
    <tr>
            <th style=" width:35mm;font-size:11.5;"><small>Visit/Work for:</small></th>
            <th style=" width:110mm;font-size:14;text-align:right;"> <b>$CustomerDataInfo->kofil_name_ar</b></th>
            <th style=" width:45mm;text-align:right;font-size:11.5;"><small>لزيارة العمل لدي:</small></th>

    </tr>
</table>

<table cellspacing="0" cellpadding="1" style="border-top:1px solid #000;border-left:1px solid #000;border-right:1px solid #000;line-height:90%;">
    <tr>
            <th style=" width:20mm;font-size:11.5;"><small>Date:</small></th>
            <th style=" width:50mm;font-size:11.5;"><small></small></th>
            <th style=" width:25mm;font-size:11.5;"><small> وتاريخ: </small></th>
            <th style=" width:30mm;font-size:11.5;"><small>Visa No:</small></th>
            <th style=" width:45mm;"><small></small></th>
            <th style=" width:20mm;text-align:right;font-size:11.5;"><small>اشرله برقم: </small></th>

    </tr>
</table>

<table cellspacing="0" cellpadding="1" style="border-top:1px solid #000;border-left:1px solid #000;border-right:1px solid #000;border-bottom:1px solid #000;line-height:90%;">
    <tr>
            <th style=" width:25mm;font-size:11.5;"><small>FEE COLLECTED:</small></th>
            <th style=" width:30mm;"><small></small></th>
            <th style=" width:25mm;font-size:11.5;font-size:10.9;"><small> المبلع المحصل: </small></th>
            <th style=" width:15mm;font-size:11.5;"><small>Type:</small></th>
            <th style=" width:25mm;"><small></small></th>
            <th style=" width:20mm;text-align:right;font-size:11.5;"><small>انوعها: </small></th>
            <th style=" width:15mm;font-size:11.5;"><small>Duration:</small></th>
            <th style=" width:20mm;"><small></small></th>
            <th style=" width:15mm;text-align:right;font-size:10.9;"><small>امدتها:</small></th>

    </tr>
</table>
<br><br>
<table cellspacing="0" cellpadding="1" >
    <tr>
            <th style=" width:40mm;font-size:11.5;"><small> رئيس القسم القنصلي </small></th>
            <th style=" width:120mm;"><small></small></th>
            <th style=" width:30mm;text-align:right;font-size:11.5;"><small> مدقق البيانات </small></th>

    </tr>
    <tr>
            <th style=" width:50mm;font-size:11.5;font-family:times;"><b>Head of Consular section</b></th>
            <th style=" width:15mm;font-size:10.9;font-family:times;text-align:right;"><b>  </b></th>
            
            <th style=" width:65mm;font-size:15;font-family:times;text-align:center;"><b> </b></th>
            
            <th style=" width:55mm;font-size:11.5;text-align:right;font-family:times;"><b>CHECKED BY:</b></th>

    </tr>
</table>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>

<table cellspacing="0" cellpadding="1" >
    <tr>
           
            <th style=" width:190mm;font-size:15;font-family:times;text-align:center;"><b>EMPLOYMENT AGREEMENT</b></th>

    </tr>
    <br/>
    <br/>
    <br/>
    <tr>
            <th style=" width:60mm;font-size:10.9;font-family:times;">NAME OF COMPANY</th>
            <th style=" width:130mm;font-size:16;font-family:times;"> : &nbsp;&nbsp;&nbsp;<b>$CustomerDataInfo->Kofile_name_eng</b></th>

    </tr>

    <br/>
    <tr>
            <th style=" width:60mm;font-size:10.9;font-family:times;">HERE BY APPONTED</th>
            <th style=" width:130mm;font-size:16;font-family:times;"><b>:&nbsp;&nbsp;&nbsp; $CustomerDataInfo->fullname S/O $CustomerDataInfo->father_name</b></th>
            

    </tr>
    <br/>
    <tr>
            <th style=" width:90mm;font-size:10.9;font-family:times;">HOLDER OF BANGLADESH PASSPORT NO</th>
            <th style=" width:60mm;font-size:16;font-family:times;"><b>: &nbsp;&nbsp;&nbsp;$CustomerDataInfo->passport_no </b></th>
            <th style=" width:30mm;font-size:10.9;text-align:left;"> KSA</th>

    </tr>
    <br/>
    <tr>
            <th style=" width:60mm;font-size:10.9;font-family:times;">FOR THE OCCUPATION OF</th>
            <th style=" width:70mm;font-size:18;"><b> &nbsp;&nbsp;&nbsp;$CustomerDataInfo->profession_arabic :</b></th>
            <th style=" width:60mm;font-size:10.9;text-align:left;">UNDER THE FOLLOWING</th>

    </tr>



</table>

<br/>
<br/>
<br/>
<br/>
<br/>
<table cellspacing="0" cellpadding="1" >
    <br/>
    <br/>
    <tr>
            <th style=" width:190mm;font-size:15;font-family:times;text-align:center"><b>TERMS AND CONDITIONS:</b></th>

    </tr>

    <br/>
    <br/>
    <br/>
    <br/>
    <tr>
            <th style=" width:10mm;font-size:10.9;font-family:times;"><b>1.</b></th>
            <th style=" width:82mm;font-size:11px;text-align:justify;font-family:times;">MONTHLY SALARY
                
            </th>

            <th style=" width:6mm;font-size:10.9;">:</th>
            <th style=" width:82mm;font-size:10.9;text-align:left;">
                SR. 1000
            </th>

    </tr>
    <br/>
    <br/>
    <tr>
            <th style=" width:10mm;font-size:10.9;font-family:times;"><b>2.</b></th>
            <th style=" width:82mm;font-size:11px;text-align:justify;font-family:times;">
                FOOD AND ACCOMMODATION 
            </th>

            <th style=" width:6mm;font-size:10.9;">:</th>
            <th style=" width:82mm;font-size:10.9;text-align:left;">
                FREE
            </th>

    </tr>

    <br/>
    <br/>
    <tr>
            <th style=" width:10mm;font-size:10.9;font-family:times;"><b>3.</b></th>
            <th style=" width:82mm;font-size:11px;text-align:justify;font-family:times;">
                AIR PASSAGE
            </th>

            <th style=" width:6mm;font-size:10.9;">:</th>
            <th style=" width:82mm;font-size:10.9;text-align:left;">
                BRONE BY THE EMPLOYER
            </th>

    </tr>

    <br/>
    <br/>
    <tr>
            <th style=" width:10mm;font-size:10.9;font-family:times;"><b>4.</b></th>
            <th style=" width:82mm;font-size:11px;text-align:justify;font-family:times;">
                DUTY HOUR
            </th>

            <th style=" width:6mm;font-size:10.9;">:</th>
            <th style=" width:82mm;font-size:10.9;text-align:left;">
               8 HOURS DAILY
            </th>

    </tr>

    <br/>
    <br/>
    <tr>
            <th style=" width:10mm;font-size:10.9;font-family:times;"><b>5.</b></th>
            <th style=" width:82mm;font-size:11px;text-align:justify;font-family:times;">
                HOLIDAY
            </th>

            <th style=" width:6mm;font-size:10.9;">:</th>
            <th style=" width:82mm;font-size:10.9;text-align:left;">
                AS PER SOUDI LABOUR LAWS
            </th>

    </tr>

    <br/>
    <br/>
    <tr>
            <th style=" width:10mm;font-size:10.9;font-family:times;"><b>6.</b></th>
            <th style=" width:82mm;font-size:11px;text-align:justify;font-family:times;">
                LEAVE
            </th>

            <th style=" width:6mm;font-size:10.9;">:</th>
            <th style=" width:82mm;font-size:10.9;text-align:left;">
                AS OER SOUDI LABOUR LAWS
            </th>

    </tr>

    <br/>
    <br/>
    <tr>
            <th style=" width:10mm;font-size:10.9;font-family:times;"><b>7.</b></th>
            <th style=" width:82mm;font-size:11px;text-align:justify;font-family:times;">
                OVERTIME & OTHER BENEFT
            </th>

            <th style=" width:6mm;font-size:10.9;">:</th>
            <th style=" width:82mm;font-size:10.9;text-align:left;">
                AS PER SOUDI LABOUR LAWS
            </th>

    </tr>

    <br/>
    <br/>
    <tr>
            <th style=" width:10mm;font-size:10.9;font-family:times;"><b>8.</b></th>
            <th style=" width:82mm;font-size:11px;text-align:justify;font-family:times;">
                MEDICAL FACILITIES
            </th>

            <th style=" width:6mm;font-size:10.9;">:</th>
            <th style=" width:82mm;font-size:10.9;text-align:left;">
                FREE
            </th>

    </tr>

    <br/>
    <br/>
    <tr>
            <th style=" width:10mm;font-size:10.9;font-family:times;"><b>9.</b></th>
            <th style=" width:82mm;font-size:11px;text-align:justify;font-family:times;">
                PERIOD OF CONTRACT
            </th>

            <th style=" width:6mm;font-size:10.9;">:</th>
            <th style=" width:82mm;font-size:10.9;text-align:left;">
                2 YEARS
            </th>

    </tr>

    <br/>
    <br/>
    <tr>
            <th style=" width:10mm;font-size:10.9;font-family:times;"><b>10.</b></th>
            <th style=" width:82mm;font-size:11px;text-align:justify;font-family:times;">REPATRIATION ARRANGEMENT INCLUDING RETURN OF DEAD BODY & SERVICE BENEFIT TO THE LEGAL HEIR OF THE EMPLOYEE
            </th>

            <th style=" width:6mm;font-size:10.9;">:</th>
            <th style=" width:82mm;font-size:10.9;text-align:left;">
                RESPONSIBILY OF THE EMPLOYER 
            </th>

    </tr>

    <br/>
    <br/>
    <tr>
            <th style=" width:10mm;font-size:10.9;font-family:times;"><b>11.</b></th>
            <th style=" width:82mm;font-size:11px;text-align:justify;font-family:times;">OTHER TERMS &CONDITIONS NOT COVERED BY THIS AGREEMENT
            </th>

            <th style=" width:6mm;font-size:10.9;">:</th>
            <th style=" width:82mm;font-size:10.9;text-align:left;">
                AS PER SOUDI LABOUR LAWS
            </th>

    </tr>


    
</table>


<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>
<br/>

<table cellspacing="0" cellpadding="1" >
    <tr>
            <th style=" width:95mm;font-size:10.9; "><b>SINGNATURE OF THE SECOND PARTY</b></th>
            <th style=" width:95mm; font-size:10.9; text-align:right;"><b>SINGNATURE OF THE SECOND PARTY</b></th>

    </tr>
<br/>

</table>

    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
    <br/>
<table>
    <tr>
            <th style=" width:190mm;font-size:10.9;text-align:justify;font-family:times;">
TO <br>
THE CHIEF OF CONSULATE SECTION <br>
ROYAL EMBASSAY OF SAUDI ARABIA<br>
GULSHAN, DHAKA, BANGLADESH<br><br>

EXCELLENCY,<br><br>

WITH DUE RESPET WE ARE SUBMITTING ONE PASSPORT FOR WORK VISA WITH ALL NECESSARY DOCUMENTS AND PARTICULARS MENTIONED AS BELOW KNOWING ALL  INSTRUCTIONS AND REGULATIONS OF CONSULATE SECTION.


            </th>

    </tr>

    <br>
    <tr>
      <th style=" width:85mm;font-size:10.9;font-family:times;font-family:times;">1.&nbsp;&nbsp;&nbsp;&nbsp;NAME OF THE EMPLOYER IN <br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;SAUDI ARABIA</th>
      <th style=" width:5mm;font-size:10.9;text-align:left">:</th>
      <th style=" width:80mm;font-size:16;"><b>$CustomerDataInfo->kofil_name_ar</b></th>

    </tr>
    <br>
    <br>
    <tr>
      <th style=" width:85mm;font-size:10.9;font-family:times;">2.&nbsp;&nbsp;&nbsp;&nbsp;VISA NO AND DATE</th>
      <th style=" width:5mm;font-size:10.9;text-align:left">:</th>
      <th style=" width:40mm;font-size:16;font-family:times;"><b>$CustomerDataInfo->visa_no</b></th>
      <th style=" width:40mm;font-size:16;font-family:times;"><b>Date: $CustomerDataInfo->visa_date_arabic</b></th>

    </tr>

    <br>
    <tr>
      <th style=" width:85mm;font-size:10.9;font-family:times;">3.&nbsp;&nbsp;&nbsp;&nbsp;FULL NAME OF THE EMPLOYEE</th>
      <th style=" width:5mm;font-size:10.9;text-align:left">:</th>

    </tr>


    <br>
    <tr>
      <th style=" width:85mm;font-size:10.9;font-family:times;">4.&nbsp;&nbsp;&nbsp;&nbsp;PASSPORT NO. AND DATE</th>
      <th style=" width:5mm;font-size:10.9;text-align:left">:</th>
      <th style=" width:40mm;font-size:16;font-family:times;"><b>$CustomerDataInfo->passport_no</b></th>
      <th style=" width:40mm;font-size:16;font-family:times;"><b>Date:$CustomerDataInfo->D_of_passport_issue</b></th>

    </tr>


    <br>
    <tr>
      <th style=" width:85mm;font-size:10.9;font-family:times;">5.&nbsp;&nbsp;&nbsp;&nbsp; PROFESSION </th>
      <th style=" width:5mm;font-size:10.9;text-align:left">:</th>
      <th style=" width:80mm;font-size:16;"><b>$CustomerDataInfo->profession_arabic</b></th>

    </tr>
    <br>
    <tr>
      <th style=" width:85mm;font-size:10.9;font-family:times;">6.&nbsp;&nbsp;&nbsp;&nbsp;RELIGION</th>
      <th style=" width:5mm;font-size:10.9;text-align:left">:</th>
      <th style=" width:80mm;font-size:16;font-family:times;"><b>$CustomerDataInfo->religion</b></th>

    </tr>

    <br>
    <tr>
      <th style=" width:190mm;font-size:10.9;text-align:justify;font-family:times;">I DO HEREBY CONFIRM AND DECLARE THAT RELIGION STATED IN THE VISA FORM AND FORWARDING LETER IS FULLY CORRECT I ALSO<br/>

UNDERTAKE THE RESPONSIBILITY TO CANCEL THE VISA AND TO STOP FUNCTIONING WITH OUR OFFICE IF THE STATEMENT IS FOUND INCORRECT. 
<br/><br/>
<br/>
WE THEREFORE REQUEST YOUR EXCELLENCY TO KINDLY ISSUE WORK VISA OUT OF_________ VISAS AND OBLIGE THEREBY.


      </th>

    </tr>

    <br>
    <br>
    <br>
    <br>
    <br>
    <br>
    <tr>
      <th style=" width:190mm;font-size:11px;text-align:left;font-family:times;">

YOURS FAITHFULLY,

    <br>
    <br>
<b style="font-size:16;font-family:times;"><center>FOR,</center><br><br> $SiteData->name</b>

      </th>

    </tr>
</table>
EOD;

$pdf->writeHTML($tbl, true, false, false, false, '');

//$pdf->Image('1', 100, 100, 10 , 0, 'png', '', '', false, 300, '', false, false, 0, 'LB', false, false);

//$pdf->writeHTMLCell(0,140,10,30,'<P>Photo<P>'); //HEADER..



//$pdf->writeHTMLCell(190,0,10.9,40,'<b>From : '.$fromdate.'</b>',0,0); 
//$pdf->writeHTMLCell(190,0,10.9,45,'<b>To &nbsp; &nbsp; : '.$todate.'</b>',0,0); 

//$pdf->writeHTMLCell(190,0,10.9,00,$tbl,0,0); 
//$pdf->writeHTMLCell(190,0,10,225,'<P>FOOTER OF VOUCHAR<P>',1,1); //FOOTER..

//$pdf->Image('1.png',10,261,74,15);

//output / result..
$pdf->Output(); 
