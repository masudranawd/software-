    <!-- page content -->
        <div class="right_col" role="main">
          <div class="">

            <div class="clearfix"></div>

                      <div class="row no-print">
                        <div class=" ">
                          <button class="btn btn-default" onclick="printDiv('printMe')"><i class="fa fa-print"></i> Print</button>
                        </div>
                      </div>
                      
            <div class="row">
              <div class="col-md-12 col-sm-12 ">
                  <a href="<?php echo base_url();?>Customer" class="btn btn-info sourc">
       New Customer  Add </a>
                <div class="x_panel"  style="border:2px solid #000;">
                  <div class="x_title">
                    <h2>Customer  Details<small>Activity And pyement report</small></h2>
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                            <a class="dropdown-item" href="#">Settings 1</a>
                            <a class="dropdown-item" href="#">Settings 2</a>
                          </div>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content"  id="printMe">
<?php //echo var_dump($Customerview);die();?>
                    <div class="col-md-5 col-sm-9 ">
                            <!-- start user projects -->
                            <table class="data table table-striped no-margin">
                              <thead>
                                <tr  class="btn-success">
                                  <th>Antry Date</th>
                                  <th>:&nbsp;&nbsp;<?php echo $Customerview->entry_date;?></th>
                                </tr>
                                <tr class="btn-secondary">
                                  <th>Name</th>
                                  <th>:&nbsp;&nbsp;<?php echo $Customerview->fullname;?></th>
                                </tr>
                                <tr  class="btn-success">
                                  <th>Serial Number</th>
                                  <th>:&nbsp;&nbsp;<?php echo $Customerview->serial_no;?></th>
                                </tr>
                                <tr class="btn-success">
                                  <th>Note</th>
                                  <th>:&nbsp;&nbsp;<?php echo $Customerview->note;?></th>
                                </tr>

                              </thead>
                            </table>
                            <!-- end user projects -->
                    </div>


                    <div class="col-md-5 col-sm-9 ">
                            <!-- start user projects -->
                            <table class="data table table-striped no-margin">
                              <thead>
                           
                                <tr class="btn-success">
                                  <th>Passport Number </th>
                                  <th>:&nbsp;&nbsp;<?php echo $Customerview->passport_no;?></th>
                                </tr>


                                <tr  class="btn-secondary">
                                  <th style="width: 30%;">Contact No</th>
                                  <th>:&nbsp;&nbsp;<?php echo $Customerview->mobile_no;?></th>
                                </tr>

                              </thead>
                            </table>
                            <!-- end user projects -->
                    </div>

                    <div class="col-md-2 col-sm-3  profile_left">
                      <div class="profile_img">
                        <div id="crop-avatar" style="text-align:center">
                          <!-- Current avatar -->
                          <?php 
                            if($Customerview->customer_image == null){
                          ?>
                          <img class="img-responsive avatar-view" src="<?php echo base_url();?>images/user.png" alt="Avatar" title="Change the avatar" style="width: 100%;">
                          <?php    
                            }else{
                          ?>
                          <img class="img-responsive avatar-view" src="<?php echo base_url();?>images/customer/<?php echo $Customerview->customer_image;?>" alt="Avatar" title="Change the avatar" style="height: 200px;width:200px;">
                          <?php
                            }
                          ?>


                        </div>
                      </div>
                    </div>
                  
<!--end-->

              </div>
            </div>
          </div>
        </div>
        <!-- /page content -->
        
                <script>
    function printDiv(divName){
        var printContents = document.getElementById(divName).innerHTML;
        var originalContents = document.body.innerHTML;
        document.body.innerHTML = printContents;
        window.print();
        document.body.innerHTML = originalContents;
    }   
  </script>