

            <!-- page content -->
            <div class="right_col" role="main">
                <div class="">
                    <div class="clearfix"></div>

                    <div class="row">
                        <div class="col-md-12 col-sm-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>Add New Customer<small><?php echo $this->session->flashdata('sms');?></small></h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                        </li>
                                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
<?php  
  if(empty($SerialNo->id)){
    $serial_no = 'MB1';
  }else{
    $serial_no = 'MB'.sprintf("%01d",$SerialNo->id+1);
  }
?>
                                <div class="x_content">
                                      <?php echo form_open_multipart('Customer/AddNewCustomer');?>
                                      <div class="row">

                                        <!-- left--->
                                      <div class="col-md-6"  style="background-color: #eee;padding:10px;">
                                            <div class="field item form-group">
                                            <label class="col-form-label col-md-2 col-sm-3  label-align" style="color:red">Entry Date<span class="required">*</span></label>
                                              <div class="col-md-10 ">
                                                <input type="text" class="form-control has-feedback-left" id="single_cal1" placeholder="First Name" aria-describedby="inputSuccess2Status" name="entry_date">
                                                <span class="fa fa-calendar-o form-control-feedback left" aria-hidden="true"></span>
                                                <span id="inputSuccess2Status4" class="sr-only">(success)</span>
                                              </div>
                                          </div>
                                            <!-- end --->

                                         <!--start -->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align" style="color:red">Serial Number<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" name="serial_no" required="required"/>
                                              </div>
                                          </div>
                                          <!-- end--->

                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align" style="color:red">Passenger Name<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" data-validate-length-range="6" data-validate-words="2" name="fullname" required="required" />
                                              </div>
                                          </div>

                              
                                  <!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Mobile No <span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" class='optional' name="mobile_no"  type="text" />
                                              </div>
                                          </div>
                                   <!--end--->


                                        </div>

            <!------------------------end left------------------------------------->

                                        <!-- center--->
                                        <div class="col-md-6"  style="background-color: #111;padding:10px;color:#fff;" >

                                      <!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Passport No.<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                <input class="form-control" class='optional' name="passport_no" type="text"   />
                                              </div>
                                          </div>
                                      <!--end--->
                                      
                                         <!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Gander<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                 <select class="form-control"  name="gender" required>
                                                    <option value="MALE"> MALE</option>
                                                    <option value="FEMALE"> FEMALE</option>
                                                  </select>
                                                </div>
                                          </div>
                                          <!--end---> 

                                         <!--start---
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Type<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                <select class="form-control"  name="type" required>
                                                    <option value="Medical">Medical Customer</option>
                                                    <option value="Ticket">Ticket Customer</option>
                                                  </select>
                                                </div>
                                          </div>
                                          --end---> 

                                       <!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">Note<span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" class='optional' name="note"  type="text"     />
                                                </div>
                                          </div>
                                     <!--end--->

                                   <!--start---
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align" >
                                                If Agent Name  <span class="required">*</span>
                                              </label>
                                              <div class="col-md-10 col-sm-6">
                                                 <select class="chosent form-control" name="agent_name" >
                                                    <option value="" >Select Agent Name</option> 
                                                  <?php 
                                                    foreach ($AllAgentList as $AgentList) {
                                                  ?>
                                                    <option value="<?php echo $AgentList->id;?>"><?php echo $AgentList->agent_name;?></option>
                                                  <?php
                                                      }  
                                                  ?>
                                                  </select>
                                      <script type="text/javascript">$(".chosent").chosen(); </script>
                                              </div>
                                          </div>
                                     --end--->  

                                      <!--start--->
                                          <div class="field item form-group">
                                              <label class="col-form-label col-md-2 col-sm-3  label-align">profile Image <span class="required">*</span></label>
                                              <div class="col-md-10 col-sm-6">
                                                  <input class="form-control" class='optional' name="customer_image"  type="file"  />
                                              </div>
                                          </div>
                                       <!--end--->



                                        </div>
<!----------------------------end Right--------------------------------------->

                                      </div><!---ROW END-->
                            
                     
                                            <div class="form-group">
                                                <div class="col-md-6 offset-md-3">
                                                 <button type="submit" class="btn btn-primary">Save</button>
                                                <button type="reset" class="btn btn-secondary">Cancel</button>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /page content -->