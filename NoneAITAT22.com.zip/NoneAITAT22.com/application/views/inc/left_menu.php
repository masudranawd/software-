<!-- header asset.php---->
<?php include('asset.php');?>
<!-- header asset.php---->
  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
              <a href="<?php echo base_url();?>" class="site_title"><i class="fa fa-paw"></i> <span><?php echo $SiteData->title;?></span></a>
            </div>
            <div class="clearfix"></div>
            <!-- menu profile quick info -->
            <div class="profile clearfix">
              <div class="profile_pic">
                <img src="<?php echo base_url();?>images/<?php echo $SiteData->logo;?>" alt="..." class="img-circle profile_img">
              </div>
              <div class="profile_info">
                <span>Welcome,</span>
                <h2><?php echo $pData->fullname;?></h2>
              </div>
            </div>
            <!-- /menu profile quick info -->
    <?php 
        if ($pData->types == 'Admin') {
    ?>
          <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3>General</h3>
                <ul class="nav side-menu">
                  <li>
                    <a href="<?php echo base_url();?>"><i class="fa fa-home"></i> Home</a>
                  </li>

                  <!--start ticket-->
                  <li>
                    <a><span class=" glyphicon glyphicon-plane" aria-hidden="true"></span>Ticket Panel<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li>
                        <a href="<?php echo base_url();?>Ticket">Ticket Booking</a>
                      </li>
                      <li>
                        <a href="<?php echo base_url();?>AllTicket">All  Booking Ticket</a>
                      </li>
                      <li><a href="<?php echo base_url();?>TicketPasenger">All Ticket Passenger</a></li>
                    </ul>
                  </li>
                  <!--end ticket -->


                  <!-- start payment -->
                  <li>
                    <a><i class="fa fa-shopping-cart" aria-hidden="true"></i>Ticket Payment Panel<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">

                      <li><a href="<?php echo base_url();?>Pay_Date">Payment</a></li>

                      <!--<li><a href="<?php echo base_url();?>Payment">Vendor Payment</a></li>
                      <li><a href="<?php echo base_url();?>AgentPayment">Customer Payment</a></li>-->
                      <li><a href="<?php echo base_url();?>AllPayment">All Payment List</a></li>
                      <li><a href="<?php echo base_url();?>PaymentReport">Payment Report</a></li>
                    </ul>
                  </li>
                  <!-- end payment -->


                  <!-- start vendor-->
                 <li>
                    <a><span class="glyphicon glyphicon-user"></span> Vendor Panel<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo base_url();?>Vendor">Add New Vendor</a></li>
                      <li><a href="<?php echo base_url();?>AllVendor">All Vendor </a></li>
                      <li><a href="<?php echo base_url();?>VendorReport">Vendor Report </a></li>
                    </ul>
                  </li>
                  <!--end vendor --->

                  <li><a><i class="fa fa-edit"></i> Customer Panel<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo base_url();?>Agent">Add New Customer</a></li>
                      <li><a href="<?php echo base_url();?>AllAgent">All Customer </a></li>
                      <li><a href="<?php echo base_url();?>AgentReport">Customer Report </a></li>
                    </ul>
                  </li>


             <!--start Medical-->
                  <li>
                    <a><i class="fa fa-user-md" aria-hidden="true"></i>Medical Panel<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo base_url();?>Medical">Add Medical</a></li>
                      <li><a href="<?php echo base_url();?>AllMedical">All Medical Passenger</a></li>
                      <li><a href="<?php echo base_url();?>MedicalPayDate">Medical Payment</a></li>
                     <!-- <li><a href="<?php echo base_url();?>AllMedicalPayment">All Medical Paid C</a></li>-->
                      <li>
                        <a href="<?php echo base_url();?>MedicalReport">Report</a>
                      </li>
                    </ul>
                  </li>
                  <!--end Medical -->


                  <!--start Passenger Name-->
                  <li>
                    <a><i class="fa fa-users" aria-hidden="true"></i>Passenger Panel<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo base_url();?>Customer">Add New Passenger</a></li>
                      <li><a href="<?php echo base_url();?>AllCustomer">All Passenger</a></li>
                      <li><a href="<?php echo base_url();?>EmbassyFile"> Embassy File </a></li>
                      <li><a href="<?php echo base_url();?>CustomerAttachFile">Passenger File Attach </a></li>
                    </ul>
                  </li>
                  <!--end Passenger Name-->
                  
                  <!-- start setting -->
                  <li><a><i class="glyphicon glyphicon-cog" style="font-size: 17px;"></i>&nbsp;Genarel Setting<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo base_url();?>Genarel">Genarel </a></li>
                      <li><a href="<?php echo base_url();?>ExpensesCatgory">Expenses Category</a></li>
                    </ul>
                  </li>
                  <!-- end setting -->

                  <!-- start system -->
                  <li>
                    <a><i class="fa fa-cogs" aria-hidden="true"></i> System Administration <span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo base_url();?>AddUser">Add User</a></li>
                      <li><a href="<?php echo base_url();?>AllUser">All User </a></li>
                    </ul>
                  </li>
                  <!-- end system -->
                  
              </div>
            </div>
            <!-- /sidebar menu -->

    <?php
        }if ($pData->types == 'Manager') {
    ?>

            <br />
            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3>General</h3>
                <ul class="nav side-menu">
                  <li>
                    <a href="<?php echo base_url();?>"><i class="fa fa-home"></i> Home</a>
                  </li>
                  <li>
                    <a href="<?php echo base_url();?>Ticket"> <span class=" glyphicon glyphicon-plane" aria-hidden="true"></span> Ticket Booking</a>
                  </li>
                  <li>
                    <a href="<?php echo base_url();?>AllTicket"> <span class=" glyphicon glyphicon-plane" aria-hidden="true"></span> All  Booking Ticket</a>
                  </li>

                 <li><a><span class="glyphicon glyphicon-user"></span> Vendor Panel<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo base_url();?>Vendor">Add New Vendor</a></li>
                      <li><a href="<?php echo base_url();?>AllVendor">All Vendor </a></li>
                      <li><a href="<?php echo base_url();?>VendorReport">Vendor Report </a></li>
                    </ul>
                  </li>

                  <li><a><i class="fa fa-edit"></i> Customer Panel<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo base_url();?>Agent">Add New Customer</a></li>
                      <li><a href="<?php echo base_url();?>AllAgent">All Customer </a></li>
                      <li><a href="<?php echo base_url();?>AgentReport">Customer Report </a></li>
                    </ul>
                  </li>

                  <li><a><i class="fa fa-edit"></i>Payment Panel<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo base_url();?>Payment">Vendor Payment</a></li>
                      <li><a href="<?php echo base_url();?>AgentPayment">Customer Payment</a></li>
                      <li><a href="<?php echo base_url();?>AllPayment">All Payment List</a></li>
                      <li><a href="<?php echo base_url();?>PaymentReport">Payment Report</a></li>
                    </ul>
                  </li>


                  <li><a><i class="fa fa-edit"></i>Office Expenses<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo base_url();?>Expenses">Add Expenses</a></li>
                      <li><a href="<?php echo base_url();?>AllExpenses">All Expenses </a></li>
                      <li><a href="<?php echo base_url();?>ExpensesReport">Expense Report</a></li>
                    </ul>
                  </li>
                  <li><a  href="<?php echo base_url();?>AllReport"><i class="fa fa-table"></i>Report</a>
                  </li>
                  
              </div>
            </div>
            <!-- /sidebar menu -->

    <?php
        }if ($pData->types == 'Operator') {
    ?>
            <br />
            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3>General</h3>
                <ul class="nav side-menu">
                  <li>
                    <a href="<?php echo base_url();?>"><i class="fa fa-home"></i> Home</a>
                  </li>
                  <li>
                    <a href="<?php echo base_url();?>Ticket"> <span class=" glyphicon glyphicon-plane" aria-hidden="true"></span> Ticket Booking</a>
                  </li>

                 <li><a><span class="glyphicon glyphicon-user"></span> Vendor Panel<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo base_url();?>Vendor">Add New Vendor</a></li>
                      <li><a href="<?php echo base_url();?>AllVendor">All Vendor </a></li>
                      <li><a href="<?php echo base_url();?>VendorReport">Vendor Report </a></li>
                    </ul>
                  </li>

                  <li><a><i class="fa fa-edit"></i> Customer Panel<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo base_url();?>Agent">Add New Customer</a></li>
                      <li><a href="<?php echo base_url();?>AllAgent">All Customer </a></li>
                      <li><a href="<?php echo base_url();?>AgentReport">Customer Report </a></li>
                    </ul>
                  </li>

                  <li><a><i class="fa fa-edit"></i>Payment Panel<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo base_url();?>Payment">Vendor Payment</a></li>
                      <li><a href="<?php echo base_url();?>AgentPayment">Customer Payment</a></li>
                      <li><a href="<?php echo base_url();?>AllPayment">All Payment List</a></li>
                      <li><a href="<?php echo base_url();?>PaymentReport">Payment Report</a></li>
                    </ul>
                  </li>

                  <li><a  href="<?php echo base_url();?>AllReport"><i class="fa fa-table"></i>Report</a>
                  </li>
              </div>
            </div>
            <!-- /sidebar menu -->
    <?php
        }if ($pData->types == 'Editor') {
    ?>

        

            <br />
            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3>General</h3>
                <ul class="nav side-menu">
                  <li>
                    <a href="<?php echo base_url();?>"><i class="fa fa-home"></i> Home</a>
                  </li>
                  <li>
                    <a href="<?php echo base_url();?>Ticket"> <span class=" glyphicon glyphicon-plane" aria-hidden="true"></span> Ticket Booking</a>
                  </li>
                  <li>
                    <a href="<?php echo base_url();?>AllTicket"> <span class=" glyphicon glyphicon-plane" aria-hidden="true"></span> All  Booking Ticket</a>
                  </li>

                 <li><a><span class="glyphicon glyphicon-user"></span> Vendor Panel<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo base_url();?>Vendor">Add New Vendor</a></li>
                      <li><a href="<?php echo base_url();?>AllVendor">All Vendor </a></li>
                    </ul>
                  </li>

                  <li><a><i class="fa fa-edit"></i> Customer Panel<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo base_url();?>Agent">Add New Customer</a></li>
                      <li><a href="<?php echo base_url();?>AllAgent">All Customer </a></li>
                    </ul>
                  </li>

                  <li><a><i class="fa fa-edit"></i>Payment Panel<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo base_url();?>Payment">Vendor Payment</a></li>
                      <li><a href="<?php echo base_url();?>AgentPayment">Customer Payment</a></li>
                    </ul>
                  </li>


                  <li><a><i class="fa fa-edit"></i>Office Expenses<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo base_url();?>Expenses">Add Expenses</a></li>
                      <li><a href="<?php echo base_url();?>AllExpenses">All Expenses </a></li>
                    </ul>
                  </li>
                  
              </div>
            </div>
            <!-- /sidebar menu -->
     <?php
        }if ($pData->types == 'Accounts') {
    ?>
              

            <br />
            <!-- sidebar menu -->
            <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
              <div class="menu_section">
                <h3>General</h3>
                <ul class="nav side-menu">
                  <li>
                    <a href="<?php echo base_url();?>"><i class="fa fa-home"></i> Home</a>
                  </li>
                  <li><a><i class="fa fa-edit"></i>Payment Panel<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo base_url();?>Payment">Vendor Payment</a></li>
                      <li><a href="<?php echo base_url();?>AgentPayment">Customer Payment</a></li>
                      <li><a href="<?php echo base_url();?>AllPayment">All Payment List</a></li>
                      <li><a href="<?php echo base_url();?>PaymentReport">Payment Report</a></li>
                    </ul>
                  </li>


                  <li><a><i class="fa fa-edit"></i>Office Expenses<span class="fa fa-chevron-down"></span></a>
                    <ul class="nav child_menu">
                      <li><a href="<?php echo base_url();?>Expenses">Add Expenses</a></li>
                      <li><a href="<?php echo base_url();?>AllExpenses">All Expenses </a></li>
                      <li><a href="<?php echo base_url();?>ExpensesReport">Expense Report</a></li>
                    </ul>
                  </li>
                  <li>
                    <a  href="<?php echo base_url();?>AllReport"><i class="fa fa-table"></i>Report</a>
                  </li>

              </div>
            </div>
            <!-- /sidebar menu -->
    <?php    
        }
        
    ?>


            <!-- /menu footer buttons -->
            <div class="sidebar-footer hidden-small">
              <a data-toggle="tooltip" data-placement="top" title="Settings">
                <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Lock">
                <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
              </a>
              <a data-toggle="tooltip" data-placement="top" title="Logout" href="<?php echo base_url('User/Logout/'); ?>">
                <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
              </a>
            </div>
            <!-- /menu footer buttons -->
          </div>
        </div>
