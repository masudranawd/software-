<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'User';

/*Dashboard controller*/
$route['Dashboard']		 	='Dashboard/index';
$route['Activity']		 	='Dashboard/Activity';

/*Customer controller*/
$route['Customer']		 	='Customer/index';
$route['AllCustomer'] 		='Customer/AllCustomer';
$route['Customer-proile']	='Customer/Customer_profile';
$route['CustomerStatus']	='Customer/CustomerStatus';
$route['customerPanel']		='Customer/customerPanel';
$route['EmbassyFile']		='Customer/EmbassyFile';
$route['EmbassyFilePDF']	='Customer/EmbassyFilePDF';
$route['CustomerTrainingFinger'] = 'Customer/CustomerTrainingFinger';
$route['CustomerTrainingFingerprint'] = 'Customer/CustomerTrainingFingerprint';
$route['CustomerAttachFile'] ='Customer/CustomerAttachFile';

/*Agent controller*/
$route['AddAgent'] = 'AddAgent/index';
$route['AgentReport'] = 'Agent/AgentReport';
$route['AllAgent'] 	  = 'Agent/AllAgent';

/*Setting controller*/
$route['Genarel'] = 'Setting/Genarel';
$route['Category'] = 'Setting/Category';
$route['ExpensesCatgory'] = 'Setting/ExpensesCatgory';
$route['CashINOutCategory'] = 'Setting/CashINOutCategory';


/*User Controller*/
$route['AddUser'] ='User/AddUser';
$route['AllUser'] ='User/AllUser';

/*Accounts Controller*/
$route['CustomerPayment'] ='Accounts';
$route['AgentPayment'] 	= 'Accounts/AgentPayment';
$route['CashReport'] 	= 'Accounts/CashReport';
$route['CustomerPaymentReport'] ='Accounts/CustomerPaymentReport';

/*Expenses Controller*/
$route['Expenses'] = 'Expenses/index';
$route['AllExpenses'] = 'Expenses/AllExpenses';
$route['ExpensesReport'] = 'Expenses/ExpensesReport';

/*Expenses Controller*/
$route['Ticket'] 				= 'Ticket/index';
$route['TicketBookingVendor'] 	= 'Ticket/TicketBookingVendor';
$route['AllTicket']		 		= 'Ticket/AllTicket';
$route['TicketReport'] 			= 'Ticket/TicketReport';
$route['FlightReport'] 			= 'Ticket/FlightReport';
$route['TicketPasenger'] 		= 'Ticket/TicketPasenger';

/*vendor*/
$route['Vendor'] = 'Vendor/index';
$route['AllVendor'] = 'Vendor/AllVendor';
$route['VendorReport'] = 'Vendor/VendorReport';


/*Payment*/
$route['Payment'] = 'Payment/index';
$route['Pay_Date'] = 'Payment/Pay_Date';
$route['AgentPayment'] = 'Payment/AgentPayment';
$route['AllPayment'] 	='Payment/AllPayment';
$route['PaymentReport'] ='Payment/PaymentReport';
$route['AllReport'] 	='Payment/AllReport';

// Medical 
$route['Medical']			= 'Medical/index';
$route['AllMedical']		= 'Medical/AllMedical';
$route['MedicalPayment']	= 'Medical/MedicalPayment';
$route['AllMedicalPayment'] = 'Medical/AllMedicalPayment';
$route['MedicalReport']		= 'Medical/MedicalReport';
$route['MedicalPayDate']	= 'Medical/MedicalPayDate';

$route['DailyMedicalReportSearch']		= 'Medical/DailyMedicalReportSearch';
$route['WMMedicalReportSearch']		= 'Medical/WMMedicalReportSearch';
$route['MedicalReport']		= 'Medical/MedicalReport';
$route['MedicalReport']		= 'Medical/MedicalReport';

$route['404_override'] = 'Setting/Error';
$route['translate_uri_dashes'] = FALSE;
